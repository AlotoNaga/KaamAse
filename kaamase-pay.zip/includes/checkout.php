<?php
/**
 * Checkout.
 *
 * The plans people see, and the round trip from pressing a button to
 * having the allowance.
 *
 * The shape of it
 * ---------------
 * Plain form posts, not a page that talks to the API from JavaScript.
 * An employer on a two bar connection in a half built house is the
 * person buying this, and a checkout that depends on several successful
 * background requests is one that fails silently for exactly that
 * person. A form post either works or shows an error.
 *
 * The one piece that has to be JavaScript is Razorpay's own checkout,
 * which is loaded on a small page of its own and opened immediately.
 *
 * Nothing the browser sends back is trusted. Access is only ever given
 * after the signature has been recomputed here with the key secret, or
 * after a webhook that carries its own. A person who edits the form and
 * posts an invented payment ID gets nothing.
 *
 * @package KaamasePay
 * @version 1.0.2
 * @since   1.0.0
 */

defined( 'ABSPATH' ) || exit;


/**
 * The plans, for a page.
 *
 * @since 1.0.0
 * @return string
 */
function kaamase_pay_plans_shortcode() {

	if ( ! kaamase_pay_is_live() ) {
		return '<div class="ka-notice ka-notice--info"><div><p>'
			. esc_html__( 'Everything on Kaam Ase is free at the moment. There is nothing to buy.', 'kaamase-pay' )
			. '</p></div></div>';
	}

	/*
	 * A visitor who is not signed in still sees everything.
	 *
	 * This used to show one line asking them to sign in, which is the
	 * wrong way round: somebody who has not decided to join is exactly
	 * the person who needs to see what it costs and what it gives.
	 * Asking them to sign in first is asking them to commit before they
	 * have been told anything.
	 *
	 * The prices are public on the website in any case, so there is
	 * nothing here worth hiding. Signing in is asked for at the moment
	 * of paying, which is the only moment it is actually needed.
	 */
	$signed_in = is_user_logged_in();

	/*
	 * A worker is never shown a price.
	 *
	 * Said plainly rather than by quietly hiding the page, because a
	 * worker who reached here followed a link and deserves an answer.
	 * The answer is the promise the rest of the site makes, repeated
	 * where it counts most: at the moment somebody wondered whether
	 * they were about to be charged.
	 */
	if ( $signed_in && ! kaamase_pay_can_buy() ) {
		return '<div class="ka-notice ka-notice--ok"><div><span class="ka-notice__title">'
			. esc_html__( 'There is nothing for you to pay', 'kaamase-pay' )
			. '</span><p>'
			. esc_html__( 'Kaam Ase is free for workers and always will be. Making a profile, being found, being called and getting hired all cost nothing, and nobody from Kaam Ase will ever ask you for money. If anyone does, report it.', 'kaamase-pay' )
			. '</p></div></div>';
	}

	/*
	 * Said at the top of the page, before any price.
	 *
	 * Somebody arriving here has just been told they cannot do
	 * something, and the next thing they see is a payment form. Without
	 * this line the honest reading is that the platform has started
	 * charging. It has not, and the sentence that says so belongs above
	 * the prices rather than in small print under them.
	 */
	$free_note = '<div class="ka-notice ka-notice--ok ka-mb-4"><div><span class="ka-notice__title">'
		. esc_html__( 'Kaam Ase stays free', 'kaamase-pay' )
		. '</span><p>'
		. esc_html__( 'Making a profile, being found, calling somebody, posting a job and getting hired all cost nothing, for everybody, always. Nothing below changes that. It is one optional extra for people who post urgent work often and want us to ring them and put a tick on their profile.', 'kaamase-pay' )
		. '</p></div></div>';

	$plans = kaamase_pay_active_plans();

	if ( empty( $plans ) ) {
		return '<p>' . esc_html__( 'Nothing is on offer just now.', 'kaamase-pay' ) . '</p>';
	}

	/*
	 * Note where this is, so a person who hits a limit anywhere on the
	 * site can be sent here rather than told to go and find it.
	 */
	$page_id = (int) get_the_ID();

	if ( $page_id && (int) get_option( 'kaamase_pay_plans_page', 0 ) !== $page_id ) {
		update_option( 'kaamase_pay_plans_page', $page_id, false );
	}

	$user_id  = get_current_user_id();
	$current  = $signed_in ? kaamase_pay_user_plan( $user_id ) : null;
	$currency = (string) kaamase_pay_setting( 'currency', 'INR' );
	$meters   = kaamase_meters();

	ob_start();

	// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Read only banner.
	$stopped = isset( $_GET['pay'] ) ? sanitize_key( wp_unslash( $_GET['pay'] ) ) : '';

	if ( $stopped ) {
		echo kaamase_pay_stop_notice( $stopped ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
	}

	echo $free_note; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped

	if ( $current ) {
		printf(
			'<div class="ka-notice ka-notice--ok ka-mb-4"><div><span class="ka-notice__title">%1$s</span><p>%2$s</p></div></div>',
			esc_html( sprintf( /* translators: %s: plan name */ __( 'You are on %s', 'kaamase-pay' ), (string) $current['name'] ) ),
			esc_html(
				sprintf(
					/* translators: %s: date */
					__( 'It runs until %s. Buying again adds to what you have rather than replacing it.', 'kaamase-pay' ),
					date_i18n( get_option( 'date_format' ), kaamase_pay_expires( $user_id ) )
				)
			)
		);
	}

	printf(
		'<div class="kp-plans%s">',
		count( $plans ) > 1 ? ' kp-plans--many' : ''
	);

	foreach ( $plans as $id => $plan ) {

		$gives = array();

		foreach ( (array) ( $plan['grants'] ?? array() ) as $key => $amount ) {

			if ( (int) $amount > 0 && isset( $meters[ $key ] ) ) {
				$gives[] = sprintf(
					/* translators: 1: how many more, 2: what of */
					__( '%1$d more %2$s', 'kaamase-pay' ),
					(int) $amount,
					strtolower( (string) $meters[ $key ]['label'] )
				);
			}
		}

		echo '<div class="kp-plan">';

		printf( '<h3 class="kp-plan__name">%s</h3>', esc_html( (string) $plan['name'] ) );

		if ( ! empty( $plan['note'] ) ) {
			printf( '<p class="kp-plan__note">%s</p>', esc_html( (string) $plan['note'] ) );
		}

		if ( $gives ) {

			echo '<ul class="kp-plan__gives">';

			foreach ( $gives as $give ) {
				printf( '<li>%s</li>', esc_html( $give ) );
			}

			echo '</ul>';
		}

		foreach ( array( 'once', 'monthly', 'yearly', 'lifetime' ) as $period ) {

			$price = kaamase_pay_price( $plan, $period );

			if ( $price <= 0 ) {
				continue;
			}

			/*
			 * A subscription cannot be sold without a plan at Razorpay
			 * behind it. Lifetime is not a subscription: it is a single
			 * payment that never repeats, so it goes through the same
			 * order flow as a one time pack and needs no Razorpay plan.
			 */
			if ( ! in_array( $period, array( 'once', 'lifetime' ), true )
				&& empty( $plan[ 'rzp_plan_' . $period ] ) ) {
				continue;
			}

			echo '<div class="kp-buy"><span class="kp-price">';

			printf(
				'<span class="kp-price__amount">%s</span>',
				esc_html( kaamase_pay_money( $price ) )
			);

			if ( 'monthly' === $period ) {
				$per = __( 'every month', 'kaamase-pay' );
			} elseif ( 'yearly' === $period ) {
				$per = __( 'every year', 'kaamase-pay' );
			} elseif ( 'lifetime' === $period ) {
				$per = __( 'once, and it never ends', 'kaamase-pay' );
			} else {
				$per = sprintf(
					/* translators: %d: number of days */
					__( 'for %d days', 'kaamase-pay' ),
					kaamase_pay_days( $plan, 'once' )
				);
			}

			printf( '<span class="kp-price__per">%s</span>', esc_html( $per ) );

			/*
			 * The saving on paying yearly, in rupees rather than as a
			 * percentage, because somebody choosing between two numbers
			 * wants the amount rather than the arithmetic. Only shown
			 * when both periods exist and yearly is genuinely cheaper.
			 */
			if ( 'yearly' === $period ) {

				$monthly = kaamase_pay_price( $plan, 'monthly' );
				$saving  = ( $monthly * 12 ) - $price;

				if ( $monthly > 0 && $saving > 0 ) {
					printf(
						'<span class="kp-price__save">%s</span>',
						esc_html(
							sprintf(
								/* translators: %s: amount saved */
								__( 'Saves %s a year', 'kaamase-pay' ),
								kaamase_pay_money( $saving )
							)
						)
					);
				}
			}

			echo '</span>';

			/*
			 * Signed out, so the button asks them to sign in and comes
			 * straight back here rather than dropping them somewhere
			 * else and making them find this page again.
			 */
			if ( ! $signed_in ) {

				printf(
					'<a class="ka-btn ka-btn--action" href="%1$s">%2$s</a>',
					esc_url( wp_login_url( kaamase_pay_here() ) ),
					esc_html__( 'Sign in to choose', 'kaamase-pay' )
				);

				echo '</div>';

				continue;
			}

			/*
			 * Posts to the page it is on, not to wp-admin.
			 *
			 * It used to post to admin-post.php, and something between
			 * the button and the handler was swallowing it: the person
			 * landed on their account page having pressed a button that
			 * never reached any of our code, so not one of the six
			 * reasons we can report was ever printed.
			 *
			 * Rather than keep hunting for what sits in front of
			 * wp-admin on this host, the request no longer goes there.
			 * A normal front end page, a normal template_redirect
			 * handler, nothing between the two.
			 */
			printf(
				'<form method="post" action="%1$s">%2$s'
				. '<input type="hidden" name="action" value="kaamase_pay_start">'
				. '<input type="hidden" name="plan" value="%3$s">'
				. '<input type="hidden" name="period" value="%4$s">'
				. '<input type="hidden" name="return_to" value="%6$s">'
				. '<button type="submit" class="ka-btn ka-btn--action">%5$s</button>'
				. '</form>',
				esc_url( kaamase_pay_here() ),
				wp_nonce_field( 'kaamase_pay_start', 'kaamase_pay_nonce', true, false ),
				esc_attr( (string) $id ),
				esc_attr( $period ),
				esc_html__( 'Choose', 'kaamase-pay' ),
				esc_url( kaamase_pay_here() )
			);

			echo '</div>';
		}

		echo '</div>';
	}

	echo '</div>';

	printf(
		'<p class="ka-small ka-soft ka-mt-6">%s</p>',
		esc_html__( 'Kaam Ase never charges a worker. Nothing here affects finding work, being found, or being hired. Paying only ever raises limits for an employer who is hiring a lot.', 'kaamase-pay' )
	);

	return (string) ob_get_clean();
}
add_shortcode( 'kaamase_plans', 'kaamase_pay_plans_shortcode' );

/**
 * An amount as somebody would write it.
 *
 * The rupee sign rather than the letters INR, and grouped the Indian
 * way by number_format_i18n, so 150000 reads as 1,50,000 rather than
 * 150,000. Getting that wrong is small but it is the kind of small that
 * tells a person the thing was not built for them.
 *
 * @since 1.0.2
 * @param float $amount Amount.
 * @return string
 */
function kaamase_pay_money( $amount ) {

	$currency = (string) kaamase_pay_setting( 'currency', 'INR' );
	$symbol   = 'INR' === $currency ? '₹' : $currency . ' ';

	return $symbol . number_format_i18n( (float) $amount );
}

/**
 * Load the plans stylesheet, on the plans page only.
 *
 * @since 1.0.2
 * @return void
 */
function kaamase_pay_styles() {

	if ( ! is_singular() || ! has_shortcode( (string) get_post_field( 'post_content', get_the_ID() ), 'kaamase_plans' ) ) {
		return;
	}

	wp_enqueue_style(
		'kaamase-pay',
		plugins_url( 'assets/plans.css', KAAMASE_PAY_FILE ),
		array(),
		KAAMASE_PAY_VERSION
	);
}
add_action( 'wp_enqueue_scripts', 'kaamase_pay_styles', 20 );


/**
 * The page somebody is on right now.
 *
 * Used so a form can say where to come back to rather than leaving the
 * server to work it out.
 *
 * @since 1.3.0
 * @return string
 */
function kaamase_pay_here() {

	$id = (int) get_the_ID();

	if ( $id ) {

		$url = get_permalink( $id );

		if ( $url ) {
			return $url;
		}
	}

	return home_url( '/' );
}

/**
 * Stop, and say why on the way back.
 *
 * @since 1.3.0
 * @param string $back   Where to send them.
 * @param string $reason A short code the plans page turns into a sentence.
 * @return void
 */
function kaamase_pay_stop( $back, $reason ) {

	/*
	 * Where the person actually was, if the form said so.
	 *
	 * The fallback works out the plans page from a remembered page id,
	 * and a remembered id goes stale: it was landing people on the
	 * dashboard, which is a page they did not press anything on and
	 * carries no explanation. The form knows the answer for certain, so
	 * it now carries it, and this only guesses when it has to.
	 *
	 * Passed through wp_validate_redirect so a crafted form cannot turn
	 * this into an open redirect off the site.
	 */
	// phpcs:ignore WordPress.Security.NonceVerification.Missing -- Only used as a destination, and validated.
	$asked = isset( $_POST['return_to'] ) ? esc_url_raw( wp_unslash( $_POST['return_to'] ) ) : '';

	if ( $asked ) {
		$back = wp_validate_redirect( $asked, $back );
	}

	wp_safe_redirect( add_query_arg( 'pay', sanitize_key( $reason ), $back ) );
	exit;
}

/**
 * Turn a stop code into something a person can act on.
 *
 * Two audiences, deliberately. Most of these are things the customer
 * can fix by trying again. Two of them are things only the owner can
 * fix, and those say so plainly rather than blaming the customer for a
 * plan that was never switched on.
 *
 * @since 1.3.0
 * @param string $reason The code.
 * @return string Markup, or an empty string.
 */
function kaamase_pay_stop_notice( $reason ) {

	$notes = array(
		'signin'  => __( 'Sign in first, then choose again.', 'kaamase-pay' ),
		'expired' => __( 'That page had been open a while and the form had expired. Please choose again.', 'kaamase-pay' ),
		'notyou'  => __( 'This account cannot buy that.', 'kaamase-pay' ),
		'off'     => __( 'Payments are not switched on yet. Add the Razorpay keys on the Payments screen and tick Charge people.', 'kaamase-pay' ),
		'noplan'  => __( 'That plan is not switched on. Open Plans and prices and tick Offer this plan to people.', 'kaamase-pay' ),
		'noprice' => __( 'That option has no price set. Open Plans and prices and put a number against it.', 'kaamase-pay' ),
		'failed'  => __( 'That payment did not go through. Nothing has been taken from you.', 'kaamase-pay' ),
	);

	if ( empty( $notes[ $reason ] ) ) {
		return '';
	}

	// The two only an administrator can fix are worth marking as such.
	$owner = in_array( $reason, array( 'off', 'noplan', 'noprice' ), true );

	return sprintf(
		'<div class="ka-notice ka-notice--warn ka-mb-4"><div><span class="ka-notice__title">%1$s</span><p>%2$s</p></div></div>',
		esc_html( $owner ? __( 'Not set up yet', 'kaamase-pay' ) : __( 'That did not work', 'kaamase-pay' ) ),
		esc_html( $notes[ $reason ] )
	);
}


/* ==========================================================================
   STARTING A PAYMENT
   ========================================================================== */

/**
 * Create the order or subscription and hand off to Razorpay.
 *
 * @since 1.0.0
 * @return void
 */
function kaamase_pay_start() {

	$back = kaamase_pay_plans_url() ? kaamase_pay_plans_url() : home_url( '/' );

	// Checked again here, because a form can be posted from anywhere.
	/*
	 * Every refusal below says why.
	 *
	 * All six used to redirect in silence, so pressing Choose and
	 * landing back where you started was the only symptom, whether the
	 * cause was an expired form, a plan switched off, or a price nobody
	 * had filled in. Nothing in the logs either, because nothing had
	 * gone wrong as far as the code was concerned. A person cannot fix
	 * what they cannot see, and neither can the person who built it.
	 */
	if ( ! is_user_logged_in() ) {
		kaamase_pay_stop( $back, 'signin' );
	}

	if ( ! kaamase_pay_is_live() ) {
		kaamase_pay_stop( $back, 'off' );
	}

	if ( $signed_in && ! kaamase_pay_can_buy() ) {
		kaamase_pay_stop( $back, 'notyou' );
	}

	if ( ! isset( $_POST['kaamase_pay_nonce'] )
		|| ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['kaamase_pay_nonce'] ) ), 'kaamase_pay_start' ) ) {
		kaamase_pay_stop( $back, 'expired' );
	}

	$plan_id = sanitize_key( wp_unslash( $_POST['plan'] ?? '' ) );
	$period  = sanitize_key( wp_unslash( $_POST['period'] ?? 'once' ) );
	$period  = in_array( $period, array( 'once', 'monthly', 'yearly', 'lifetime' ), true ) ? $period : 'once';
	$plan    = kaamase_pay_plan( $plan_id );

	if ( ! $plan || empty( $plan['active'] ) ) {
		kaamase_pay_stop( $back, 'noplan' );
	}

	$price = kaamase_pay_price( $plan, $period );

	if ( $price <= 0 ) {
		kaamase_pay_stop( $back, 'noprice' );
	}

	$user_id = get_current_user_id();

	/*
	 * Lifetime is a single payment, so it takes the order path rather
	 * than the subscription path. Creating a Razorpay subscription for
	 * something that never renews would charge somebody every month for
	 * a thing they bought once.
	 */
	if ( in_array( $period, array( 'once', 'lifetime' ), true ) ) {

		$order = kaamase_pay_create_order( $price, 'ka-' . $user_id . '-' . time() );

		if ( is_wp_error( $order ) ) {
			kaamase_pay_fail_page( $order->get_error_message() );
		}

		kaamase_pay_record(
			array(
				'user_id'  => $user_id,
				'plan'     => $plan_id,
				'period'   => $period,
				'amount'   => $price,
				'status'   => 'created',
				'order_id' => (string) ( $order['id'] ?? '' ),
			)
		);

		kaamase_pay_checkout_page( $plan, $period, $price, (string) ( $order['id'] ?? '' ), '' );
	}

	$subscription = kaamase_pay_create_subscription(
		(string) $plan[ 'rzp_plan_' . $period ],
		$period,
		array(
			'user_id' => (string) $user_id,
			'plan'    => $plan_id,
		)
	);

	if ( is_wp_error( $subscription ) ) {
		kaamase_pay_fail_page( $subscription->get_error_message() );
	}

	kaamase_pay_record(
		array(
			'user_id'         => $user_id,
			'plan'            => $plan_id,
			'period'          => $period,
			'amount'          => $price,
			'status'          => 'created',
			'subscription_id' => (string) ( $subscription['id'] ?? '' ),
		)
	);

	kaamase_pay_checkout_page( $plan, $period, $price, '', (string) ( $subscription['id'] ?? '' ) );
}
add_action( 'admin_post_kaamase_pay_start', 'kaamase_pay_start' );

/**
 * Catch the buy form on the page it was pressed on.
 *
 * Runs before anything is printed, so the redirect to Razorpay still
 * works. Kept alongside the wp-admin hook rather than replacing it, so
 * any older page still in somebody's browser keeps working.
 *
 * @since 1.3.0
 * @return void
 */
function kaamase_pay_catch_start() {

	if ( is_admin() ) {
		return;
	}

	// phpcs:ignore WordPress.Security.NonceVerification.Missing -- Checked inside the handler.
	$action = isset( $_POST['action'] ) ? sanitize_key( wp_unslash( $_POST['action'] ) ) : '';

	if ( 'kaamase_pay_start' !== $action ) {
		return;
	}

	kaamase_pay_start();
}
add_action( 'template_redirect', 'kaamase_pay_catch_start' );

/**
 * The small page that opens Razorpay.
 *
 * Ends the request. Nothing runs after it.
 *
 * @since 1.0.0
 * @param array  $plan            The plan.
 * @param string $period          Period being bought.
 * @param float  $price           Rupees.
 * @param string $order_id        Razorpay order, for a one time payment.
 * @param string $subscription_id Razorpay subscription, for a subscription.
 * @return void
 */
function kaamase_pay_checkout_page( $plan, $period, $price, $order_id, $subscription_id ) {

	$user = wp_get_current_user();

	$options = array(
		'key'         => (string) kaamase_pay_setting( 'key_id' ),
		'name'        => get_bloginfo( 'name' ),
		'description' => (string) $plan['name'],
		'prefill'     => array(
			'name'  => $user->display_name,
			'email' => $user->user_email,
		),
		'theme'       => array( 'color' => '#0b4527' ),
	);

	// Razorpay wants one or the other, never both.
	if ( $subscription_id ) {
		$options['subscription_id'] = $subscription_id;
	} else {
		$options['order_id'] = $order_id;
		$options['amount']   = kaamase_pay_paise( $price );
		$options['currency'] = (string) kaamase_pay_setting( 'currency', 'INR' );
	}

	?><!doctype html>
	<html <?php language_attributes(); ?>>
	<head>
		<meta charset="<?php bloginfo( 'charset' ); ?>">
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<title><?php esc_html_e( 'Paying', 'kaamase-pay' ); ?></title>
		<style>
			body { font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
				background: #faf9f6; color: #17150f; padding: 40px 20px; text-align: center; }
			.k { max-width: 380px; margin: 0 auto; }
			a { color: #10603a; }
		</style>
	</head>
	<body>
		<div class="k">
			<p><?php esc_html_e( 'Opening the payment window.', 'kaamase-pay' ); ?></p>
			<p id="kaamase-pay-note"></p>
			<p><a href="<?php echo esc_url( kaamase_pay_plans_url() ? kaamase_pay_plans_url() : home_url( '/' ) ); ?>"><?php esc_html_e( 'Go back without paying', 'kaamase-pay' ); ?></a></p>

			<?php
			/*
			 * Also posts to the front end rather than to wp-admin.
			 *
			 * This is the return leg, after the money has moved. If it
			 * were swallowed the way the start leg was, somebody would
			 * have paid and been granted nothing, with no error to show
			 * for it. The webhook would eventually put it right, which
			 * is exactly the sort of eventually nobody should have to
			 * rely on while staring at a blank screen.
			 */
			$kaamase_return = kaamase_pay_plans_url() ? kaamase_pay_plans_url() : home_url( '/' );
			?>
			<form id="kaamase-pay-return" method="post" action="<?php echo esc_url( $kaamase_return ); ?>">
				<input type="hidden" name="action" value="kaamase_pay_verify">
				<?php wp_nonce_field( 'kaamase_pay_verify', 'kaamase_pay_verify_nonce' ); ?>
				<input type="hidden" name="plan" value="<?php echo esc_attr( (string) $plan['id'] ); ?>">
				<input type="hidden" name="period" value="<?php echo esc_attr( (string) $period ); ?>">
				<input type="hidden" name="razorpay_payment_id" value="">
				<input type="hidden" name="razorpay_order_id" value="<?php echo esc_attr( $order_id ); ?>">
				<input type="hidden" name="razorpay_subscription_id" value="<?php echo esc_attr( $subscription_id ); ?>">
				<input type="hidden" name="razorpay_signature" value="">
			</form>
		</div>

		<script src="https://checkout.razorpay.com/v1/checkout.js"></script>
		<script>
			( function () {
				var form    = document.getElementById( 'kaamase-pay-return' );
				var options = <?php echo wp_json_encode( $options, JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT ); ?>;

				/*
				 * Razorpay's own failures, shown rather than swallowed.
				 *
				 * When its window sticks on the loading shield the cause
				 * is almost never this site: it is the account, the
				 * keys, or a feature not switched on at their end. None
				 * of that reaches the page unless it is asked for, so a
				 * person sits looking at a spinner and concludes the
				 * platform is broken.
				 */
				options.modal = {
					ondismiss: function () {
						document.getElementById( 'kaamase-pay-note' ).textContent =
							'Payment window closed. Nothing has been charged.';
					}
				};

				options.handler = function ( response ) {
					form.razorpay_payment_id.value = response.razorpay_payment_id || '';
					form.razorpay_signature.value  = response.razorpay_signature || '';

					if ( response.razorpay_order_id ) {
						form.razorpay_order_id.value = response.razorpay_order_id;
					}

					if ( response.razorpay_subscription_id ) {
						form.razorpay_subscription_id.value = response.razorpay_subscription_id;
					}

					form.submit();
				};

				var rzp = new Razorpay( options );

				rzp.on( 'payment.failed', function ( response ) {
					var reason = ( response && response.error && response.error.description )
						? response.error.description
						: 'The payment did not go through.';

					document.getElementById( 'kaamase-pay-note' ).textContent = reason;
				} );

				rzp.open();
			}() );
		</script>
	</body>
	</html>
	<?php
	exit;
}

/**
 * Say something went wrong, and stop.
 *
 * @since 1.0.0
 * @param string $reason What Razorpay said.
 * @return void
 */
function kaamase_pay_fail_page( $reason ) {

	wp_die(
		esc_html__( 'The payment could not be started. Nothing has been charged.', 'kaamase-pay' )
			. ' ' . esc_html( $reason ),
		esc_html__( 'Payment', 'kaamase-pay' ),
		array( 'back_link' => true )
	);
}


/* ==========================================================================
   FINISHING A PAYMENT
   ========================================================================== */

/**
 * Check what came back and give the access.
 *
 * @since 1.0.0
 * @return void
 */
function kaamase_pay_verify() {

	$back = kaamase_pay_plans_url() ? kaamase_pay_plans_url() : home_url( '/' );

	if ( ! is_user_logged_in()
		|| ! isset( $_POST['kaamase_pay_verify_nonce'] )
		|| ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['kaamase_pay_verify_nonce'] ) ), 'kaamase_pay_verify' ) ) {
		wp_safe_redirect( $back );
		exit;
	}

	$user_id   = get_current_user_id();
	$payment   = sanitize_text_field( wp_unslash( $_POST['razorpay_payment_id'] ?? '' ) );
	$order     = sanitize_text_field( wp_unslash( $_POST['razorpay_order_id'] ?? '' ) );
	$subscript = sanitize_text_field( wp_unslash( $_POST['razorpay_subscription_id'] ?? '' ) );
	$signature = sanitize_text_field( wp_unslash( $_POST['razorpay_signature'] ?? '' ) );

	/*
	 * Which plan was bought is read from our own record of the order,
	 * never from the form.
	 *
	 * The signature proves that this payment ID belongs to this order
	 * ID. It proves nothing about which plan the order was for, because
	 * the plan is not part of what is signed. So a person who edits the
	 * hidden plan field, pays two hundred rupees for the cheapest pack
	 * and posts back the name of the largest one would pass the
	 * signature check and be granted the largest one. The row written
	 * when the order was created is the only trustworthy statement of
	 * what was actually being sold.
	 */
	$row = kaamase_pay_find_row( $order, $subscript );

	if ( ! $row || (int) $row->user_id !== $user_id ) {
		wp_safe_redirect( add_query_arg( 'paid', 'failed', $back ) );
		exit;
	}

	/*
	 * Already counted. Somebody pressing back, refreshing the result, or
	 * arriving after the webhook has already dealt with it should be
	 * told it worked, not given a second month for one payment.
	 */
	if ( 'paid' === $row->status || kaamase_pay_payment_seen( $payment ) ) {
		wp_safe_redirect( add_query_arg( 'paid', 'ok', $back ) );
		exit;
	}

	$genuine = $subscript
		? kaamase_pay_verify_subscription( $payment, (string) $row->subscription_id, $signature )
		: kaamase_pay_verify_payment( (string) $row->order_id, $payment, $signature );

	if ( ! $genuine ) {

		kaamase_pay_update_by_id(
			(int) $row->id,
			array(
				'status'     => 'failed',
				'payment_id' => $payment,
				'note'       => 'signature mismatch',
			)
		);

		wp_safe_redirect( add_query_arg( 'paid', 'failed', $back ) );
		exit;
	}

	kaamase_pay_update_by_id(
		(int) $row->id,
		array(
			'status'     => 'paid',
			'payment_id' => $payment,
		)
	);

	kaamase_pay_grant( $user_id, (string) $row->plan, (string) $row->period, $subscript );

	wp_safe_redirect( add_query_arg( 'paid', 'ok', $back ) );
	exit;
}
add_action( 'admin_post_kaamase_pay_verify', 'kaamase_pay_verify' );

/**
 * Catch the return from Razorpay on the front end.
 *
 * @since 1.3.0
 * @return void
 */
function kaamase_pay_catch_verify() {

	if ( is_admin() ) {
		return;
	}

	// phpcs:ignore WordPress.Security.NonceVerification.Missing -- Checked inside the handler.
	$action = isset( $_POST['action'] ) ? sanitize_key( wp_unslash( $_POST['action'] ) ) : '';

	if ( 'kaamase_pay_verify' !== $action ) {
		return;
	}

	kaamase_pay_verify();
}
add_action( 'template_redirect', 'kaamase_pay_catch_verify' );

/**
 * Say how it went, above the plans.
 *
 * @since 1.0.0
 * @param string $content Page content.
 * @return string
 */
function kaamase_pay_result_notice( $content ) {

	// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Read only banner.
	$result = isset( $_GET['paid'] ) ? sanitize_key( wp_unslash( $_GET['paid'] ) ) : '';

	if ( ! $result || ! is_page() || ! in_the_loop() || ! is_main_query() ) {
		return $content;
	}

	if ( 'ok' === $result ) {
		return '<div class="ka-notice ka-notice--ok"><div><span class="ka-notice__title">'
			. esc_html__( 'Paid, and it is on your account already', 'kaamase-pay' )
			. '</span><p>' . esc_html__( 'Your higher limits are working now. A receipt is on its way from Razorpay.', 'kaamase-pay' )
			. '</p></div></div>' . $content;
	}

	return '<div class="ka-notice ka-notice--warn"><div><span class="ka-notice__title">'
		. esc_html__( 'That payment did not go through', 'kaamase-pay' )
		. '</span><p>' . esc_html__( 'Nothing has been taken from you. If money did leave your account, send us the payment reference and we will sort it out.', 'kaamase-pay' )
		. '</p></div></div>' . $content;
}
add_filter( 'the_content', 'kaamase_pay_result_notice', 5 );
