<?php
/**
 * Who is paying.
 *
 * One screen showing every account that has ever paid: what they hold,
 * when it ends, whether it renews, and whether they have had their
 * call.
 *
 * Why this is separate from the payments list
 * -------------------------------------------
 * The payments list answers "did money arrive", which is an accounting
 * question and is answered per transaction. This answers "who has what
 * right now", which is the question actually asked in practice, and no
 * list of transactions answers it: somebody who paid in March and let
 * it lapse looks identical to somebody who paid in March and renewed.
 *
 * Lapsed accounts are shown rather than filtered out, and shown last.
 * Somebody whose plan ran out three days ago is the single most useful
 * person on this page: they have already decided the thing was worth
 * paying for once, and a phone call at that moment is worth more than
 * any amount of advertising to somebody who never has.
 *
 * @package KaamasePay
 * @version 1.0.0
 * @since   1.4.0
 */

defined( 'ABSPATH' ) || exit;


/**
 * Add the screen under Kaam Ase.
 *
 * @since 1.4.0
 * @return void
 */
function kaamase_pay_subscribers_menu() {

	add_submenu_page(
		'kaamase',
		__( 'Subscribers', 'kaamase-pay' ),
		__( 'Subscribers', 'kaamase-pay' ),
		'promote_users',
		'kaamase-subscribers',
		'kaamase_pay_subscribers_page'
	);
}
add_action( 'admin_menu', 'kaamase_pay_subscribers_menu', 22 );

/**
 * Everybody who has ever held a plan.
 *
 * Sorted by expiry, furthest away first, so anybody about to lapse sits
 * near the bottom of the running list where it is worth looking.
 *
 * @since 1.4.0
 * @return WP_User[]
 */
function kaamase_pay_subscribers() {

	$users = get_users(
		array(
			'meta_key' => KAAMASE_PAY_EXPIRES_KEY, // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_key
			'orderby'  => 'meta_value_num',
			'order'    => 'DESC',
			'number'   => 500,
		)
	);

	return is_array( $users ) ? $users : array();
}

/**
 * What one subscriber is holding, in words.
 *
 * @since 1.4.0
 * @param int $user_id User ID.
 * @return array{plan: string, period: string, ends: string, renews: bool, active: bool, called: bool}
 */
function kaamase_pay_subscriber_row( $user_id ) {

	$user_id = (int) $user_id;
	$expires = kaamase_pay_expires( $user_id );
	$active  = kaamase_pay_is_active( $user_id );
	$plan_id = (string) get_user_meta( $user_id, KAAMASE_PAY_PLAN_KEY, true );
	$plan    = kaamase_pay_plan( $plan_id );
	$sub     = (string) get_user_meta( $user_id, KAAMASE_PAY_SUB_KEY, true );

	/*
	 * The period is read from what they actually bought rather than
	 * guessed from the plan, because one plan is sold three ways and
	 * the plan record cannot tell you which of them somebody chose.
	 */
	$period = kaamase_pay_subscriber_period( $user_id );

	if ( kaamase_pay_is_endless( $expires ) ) {
		$ends = __( 'Never', 'kaamase-pay' );
	} elseif ( $expires ) {
		$ends = date_i18n( get_option( 'date_format' ), $expires );
	} else {
		$ends = '—';
	}

	return array(
		'plan'    => $plan ? (string) $plan['name'] : $plan_id,
		'period'  => $period,
		'ends'    => $ends,
		'renews'  => '' !== $sub,
		'active'  => (bool) $active,
		'called'  => function_exists( 'kaamase_has_been_called' ) && (int) get_user_meta( $user_id, KAAMASE_CALLED_AT_KEY, true ) > 0,
		'expires' => (int) $expires,
	);
}

/**
 * Which of the three they bought, from the last payment recorded.
 *
 * @since 1.4.0
 * @param int $user_id User ID.
 * @return string
 */
function kaamase_pay_subscriber_period( $user_id ) {

	global $wpdb;

	// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.InterpolatedNotPrepared
	$period = $wpdb->get_var(
		$wpdb->prepare(
			'SELECT period FROM ' . kaamase_pay_table() . " WHERE user_id = %d AND status = 'paid' ORDER BY id DESC LIMIT 1",
			(int) $user_id
		)
	);

	$words = array(
		'monthly'  => __( 'Monthly', 'kaamase-pay' ),
		'yearly'   => __( 'Yearly', 'kaamase-pay' ),
		'lifetime' => __( 'Lifetime', 'kaamase-pay' ),
		'once'     => __( 'One off', 'kaamase-pay' ),
	);

	return $words[ (string) $period ] ?? '—';
}

/**
 * Render the screen.
 *
 * @since 1.4.0
 * @return void
 */
function kaamase_pay_subscribers_page() {

	if ( ! current_user_can( 'promote_users' ) ) {
		wp_die( esc_html__( 'You cannot do that.', 'kaamase-pay' ) );
	}

	$all     = kaamase_pay_subscribers();
	$running = array();
	$lapsed  = array();

	foreach ( $all as $user ) {

		$row = kaamase_pay_subscriber_row( $user->ID );

		if ( $row['active'] ) {
			$running[] = array( $user, $row );
		} else {
			$lapsed[] = array( $user, $row );
		}
	}

	/*
	 * Lapsed sorted most recent first, which is the opposite of the
	 * running list. The person who lapsed yesterday is worth a call; the
	 * one who lapsed last year is not.
	 */
	usort(
		$lapsed,
		static function ( $a, $b ) {
			return $b[1]['expires'] <=> $a[1]['expires'];
		}
	);
	?>
	<div class="wrap">

		<h1><?php esc_html_e( 'Subscribers', 'kaamase-pay' ); ?></h1>

		<p class="description" style="max-width:44em">
			<?php esc_html_e( 'Everybody who has ever paid, what they hold, and when it ends. The tick column says whether you have made your call yet: no tick means they have paid and are still waiting on the Calls to make screen.', 'kaamase-pay' ); ?>
		</p>

		<?php
		kaamase_pay_subscriber_table(
			/* translators: %d: how many */
			sprintf( __( 'Running now (%d)', 'kaamase-pay' ), count( $running ) ),
			$running,
			__( 'Nobody is on a plan at the moment.', 'kaamase-pay' )
		);

		kaamase_pay_subscriber_table(
			/* translators: %d: how many */
			sprintf( __( 'Lapsed (%d)', 'kaamase-pay' ), count( $lapsed ) ),
			$lapsed,
			__( 'Nobody has lapsed.', 'kaamase-pay' ),
			__( 'These have run out. Somebody who lapsed in the last week or two is worth a call: they already decided it was worth paying for once.', 'kaamase-pay' )
		);
		?>

	</div>
	<?php
}

/**
 * One table of subscribers.
 *
 * @since 1.4.0
 * @param string  $heading Table heading.
 * @param array[] $rows    Pairs of user and row data.
 * @param string  $empty   What to say when there are none.
 * @param string  $note    Optional line under the heading.
 * @return void
 */
function kaamase_pay_subscriber_table( $heading, $rows, $empty, $note = '' ) {
	?>
	<h2 class="ka-mt-6"><?php echo esc_html( $heading ); ?></h2>

	<?php if ( $note ) : ?>
		<p class="description" style="max-width:44em"><?php echo esc_html( $note ); ?></p>
	<?php endif; ?>

	<?php if ( empty( $rows ) ) : ?>

		<p><?php echo esc_html( $empty ); ?></p>

	<?php else : ?>

		<table class="wp-list-table widefat fixed striped">
			<thead>
				<tr>
					<th scope="col"><?php esc_html_e( 'Person', 'kaamase-pay' ); ?></th>
					<th scope="col"><?php esc_html_e( 'Ring', 'kaamase-pay' ); ?></th>
					<th scope="col"><?php esc_html_e( 'Plan', 'kaamase-pay' ); ?></th>
					<th scope="col"><?php esc_html_e( 'Ends', 'kaamase-pay' ); ?></th>
					<th scope="col"><?php esc_html_e( 'Renews', 'kaamase-pay' ); ?></th>
					<th scope="col"><?php esc_html_e( 'Tick', 'kaamase-pay' ); ?></th>
				</tr>
			</thead>
			<tbody>

			<?php foreach ( $rows as $pair ) : ?>
				<?php
				list( $user, $row ) = $pair;

				$phone = function_exists( 'kaamase_user_phone' ) ? kaamase_user_phone( $user->ID ) : '';
				?>
				<tr>
					<td>
						<strong><?php echo esc_html( $user->display_name ); ?></strong><br>
						<span class="description"><?php echo esc_html( $user->user_email ); ?></span>
					</td>

					<td>
						<?php if ( $phone ) : ?>
							<a href="<?php echo esc_url( 'tel:' . $phone ); ?>"><?php echo esc_html( $phone ); ?></a>
						<?php else : ?>
							&mdash;
						<?php endif; ?>
					</td>

					<td>
						<?php echo esc_html( $row['plan'] ); ?><br>
						<span class="description"><?php echo esc_html( $row['period'] ); ?></span>
					</td>

					<td><?php echo esc_html( $row['ends'] ); ?></td>

					<td>
						<?php
						echo esc_html(
							$row['renews']
								? __( 'Yes', 'kaamase-pay' )
								: __( 'No', 'kaamase-pay' )
						);
						?>
					</td>

					<td>
						<?php if ( $row['called'] && $row['active'] ) : ?>
							<span style="color:#0f8a3c">&#10003; <?php esc_html_e( 'Showing', 'kaamase-pay' ); ?></span>
						<?php elseif ( $row['called'] ) : ?>
							<span class="description"><?php esc_html_e( 'Called, hidden while lapsed', 'kaamase-pay' ); ?></span>
						<?php else : ?>
							<span style="color:#b32d2e"><?php esc_html_e( 'Not called yet', 'kaamase-pay' ); ?></span>
						<?php endif; ?>
					</td>
				</tr>
			<?php endforeach; ?>

			</tbody>
		</table>

	<?php endif; ?>
	<?php
}
