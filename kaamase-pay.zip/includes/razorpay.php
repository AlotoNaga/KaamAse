<?php
/**
 * Razorpay.
 *
 * Everything that talks to their API, and the three signature checks
 * that decide whether a message really came from them.
 *
 * On the signatures
 * -----------------
 * These are the only thing standing between a working payment system and
 * one where anybody who can read a URL can grant themselves a year of
 * access by posting a made up payment ID. The browser is never trusted:
 * a payment is only ever confirmed by recomputing the signature here
 * with the key secret, or by a webhook that carries its own.
 *
 * Compared with hash_equals rather than with a plain comparison, so the
 * time taken to fail does not reveal how much of the guess was right.
 *
 * @package KaamasePay
 * @version 1.0.0
 * @since   1.0.0
 */

defined( 'ABSPATH' ) || exit;


/** Where their API lives. */
define( 'KAAMASE_PAY_API', 'https://api.razorpay.com/v1/' );


/**
 * Call the Razorpay API.
 *
 * @since 1.0.0
 * @param string $path   Endpoint after the version, such as orders.
 * @param array  $body   Body for a POST. Empty means GET.
 * @param string $method HTTP method.
 * @return array|WP_Error Decoded response.
 */
function kaamase_pay_api( $path, $body = array(), $method = 'POST' ) {

	if ( ! kaamase_pay_is_configured() ) {
		return new WP_Error( 'kaamase_pay_no_keys', __( 'Payments are not set up.', 'kaamase-pay' ) );
	}

	$auth = base64_encode( kaamase_pay_setting( 'key_id' ) . ':' . kaamase_pay_setting( 'key_secret' ) ); // phpcs:ignore WordPress.PHP.DiscouragedPHPFunctions.obfuscation_base64_encode

	$args = array(
		'method'  => $method,
		'timeout' => 30,
		'headers' => array(
			'Authorization' => 'Basic ' . $auth,
			'Content-Type'  => 'application/json',
		),
	);

	if ( ! empty( $body ) ) {
		$args['body'] = wp_json_encode( $body );
	}

	$response = wp_remote_request( KAAMASE_PAY_API . ltrim( $path, '/' ), $args );

	if ( is_wp_error( $response ) ) {
		return $response;
	}

	$code    = (int) wp_remote_retrieve_response_code( $response );
	$decoded = json_decode( (string) wp_remote_retrieve_body( $response ), true );

	if ( $code < 200 || $code >= 300 ) {

		$message = $decoded['error']['description'] ?? __( 'Razorpay refused that.', 'kaamase-pay' );

		return new WP_Error( 'kaamase_pay_api', (string) $message, array( 'status' => $code ) );
	}

	return is_array( $decoded ) ? $decoded : array();
}

/**
 * Turn rupees into the paise Razorpay counts in.
 *
 * Rounded rather than cast, because 199.00 arrives from a form as a
 * float that can be 198.99999 by the time it is multiplied, and casting
 * would quietly charge a rupee less.
 *
 * @since 1.0.0
 * @param float $rupees Amount in rupees.
 * @return int Amount in paise.
 */
function kaamase_pay_paise( $rupees ) {
	return (int) round( ( (float) $rupees ) * 100 );
}


/* ==========================================================================
   SIGNATURES
   ========================================================================== */

/**
 * Check a one time payment came back genuine.
 *
 * @since 1.0.0
 * @param string $order_id   Razorpay order ID.
 * @param string $payment_id Razorpay payment ID.
 * @param string $signature  Signature returned by checkout.
 * @return bool
 */
function kaamase_pay_verify_payment( $order_id, $payment_id, $signature ) {

	$expected = hash_hmac(
		'sha256',
		$order_id . '|' . $payment_id,
		(string) kaamase_pay_setting( 'key_secret' )
	);

	return hash_equals( $expected, (string) $signature );
}

/**
 * Check a subscription payment came back genuine.
 *
 * Note the order is the other way round from a one time payment. It is
 * payment then subscription here, and order then payment there. Getting
 * that backwards produces a signature check that fails every time and
 * looks exactly like a wrong key secret.
 *
 * @since 1.0.0
 * @param string $payment_id      Razorpay payment ID.
 * @param string $subscription_id Razorpay subscription ID.
 * @param string $signature       Signature returned by checkout.
 * @return bool
 */
function kaamase_pay_verify_subscription( $payment_id, $subscription_id, $signature ) {

	$expected = hash_hmac(
		'sha256',
		$payment_id . '|' . $subscription_id,
		(string) kaamase_pay_setting( 'key_secret' )
	);

	return hash_equals( $expected, (string) $signature );
}

/**
 * Check a webhook came from Razorpay.
 *
 * Signed with the webhook secret over the raw body, so the body must be
 * the exact bytes received. Decoding and re encoding it changes the
 * signature and the check fails for no visible reason.
 *
 * @since 1.0.0
 * @param string $body      Raw request body.
 * @param string $signature Value of the X-Razorpay-Signature header.
 * @return bool
 */
function kaamase_pay_verify_webhook( $body, $signature ) {

	$secret = (string) kaamase_pay_setting( 'webhook_secret' );

	if ( '' === $secret || '' === (string) $signature ) {
		return false;
	}

	return hash_equals( hash_hmac( 'sha256', $body, $secret ), (string) $signature );
}


/* ==========================================================================
   CREATING THINGS
   ========================================================================== */

/**
 * Create an order for a one time payment.
 *
 * @since 1.0.0
 * @param float  $amount  Amount in rupees.
 * @param string $receipt Your own reference.
 * @return array|WP_Error
 */
function kaamase_pay_create_order( $amount, $receipt ) {

	return kaamase_pay_api(
		'orders',
		array(
			'amount'   => kaamase_pay_paise( $amount ),
			'currency' => (string) kaamase_pay_setting( 'currency', 'INR' ),
			'receipt'  => substr( (string) $receipt, 0, 40 ),
		)
	);
}

/**
 * Create a Razorpay plan.
 *
 * Called when a price is saved rather than kept in code, which is the
 * whole point of the plans screen. Razorpay plans cannot be edited once
 * made, so changing a price creates a new one and the old ID stays on
 * anybody already subscribed to it. That is correct: somebody who signed
 * up at two hundred keeps paying two hundred until they choose otherwise,
 * and a price rise does not reach into existing subscriptions.
 *
 * @since 1.0.0
 * @param string $name   Shown on the Razorpay side.
 * @param float  $amount Amount in rupees.
 * @param string $period Either monthly or yearly.
 * @return array|WP_Error
 */
function kaamase_pay_create_plan( $name, $amount, $period ) {

	$period = 'yearly' === $period ? 'yearly' : 'monthly';

	return kaamase_pay_api(
		'plans',
		array(
			'period'   => $period,
			'interval' => 1,
			'item'     => array(
				'name'     => substr( (string) $name, 0, 60 ),
				'amount'   => kaamase_pay_paise( $amount ),
				'currency' => (string) kaamase_pay_setting( 'currency', 'INR' ),
			),
		)
	);
}

/**
 * Start a subscription.
 *
 * total_count is how many times it may ever charge. Razorpay requires a
 * number, so this is a long one rather than an unlimited one: ten years
 * of months, or ten years of years.
 *
 * @since 1.0.0
 * @param string $plan_id Razorpay plan ID.
 * @param string $period  Either monthly or yearly.
 * @param array  $notes   Anything to keep against it.
 * @return array|WP_Error
 */
function kaamase_pay_create_subscription( $plan_id, $period, $notes = array() ) {

	return kaamase_pay_api(
		'subscriptions',
		array(
			'plan_id'         => (string) $plan_id,
			'total_count'     => 'yearly' === $period ? 10 : 120,
			'customer_notify' => 1,
			'notes'           => $notes,
		)
	);
}

/**
 * Cancel a subscription.
 *
 * At the end of the paid period, never immediately. Somebody who cancels
 * on day two of a month they paid for keeps the rest of that month,
 * which is both fair and the thing that stops a cancellation turning
 * into a refund request.
 *
 * @since 1.0.0
 * @param string $subscription_id Razorpay subscription ID.
 * @return array|WP_Error
 */
function kaamase_pay_cancel_subscription( $subscription_id ) {

	return kaamase_pay_api(
		'subscriptions/' . rawurlencode( (string) $subscription_id ) . '/cancel',
		array( 'cancel_at_cycle_end' => 1 )
	);
}

/**
 * What Razorpay currently says about a subscription.
 *
 * Used to check rather than assume after a cancel appears to fail.
 * Razorpay refuses to cancel a subscription that is already cancelled,
 * and that refusal arrives looking exactly like a real failure, so the
 * only way to tell them apart is to ask.
 *
 * @since 1.4.2
 * @param string $subscription_id The subscription.
 * @return array|WP_Error
 */
function kaamase_pay_fetch_subscription( $subscription_id ) {

	$subscription_id = trim( (string) $subscription_id );

	if ( '' === $subscription_id ) {
		return new WP_Error( 'kaamase_pay_no_subscription', __( 'No subscription given.', 'kaamase-pay' ) );
	}

	return kaamase_pay_api( 'subscriptions/' . rawurlencode( $subscription_id ), array(), 'GET' );
}

/**
 * Whether a subscription has stopped, whatever the reason.
 *
 * Anything that is not still charging counts as stopped, because from
 * this site's point of view the only question is whether more money
 * will be taken.
 *
 * @since 1.4.2
 * @param array $subscription A subscription from Razorpay.
 * @return bool
 */
function kaamase_pay_subscription_stopped( $subscription ) {

	$status = isset( $subscription['status'] ) ? strtolower( (string) $subscription['status'] ) : '';

	return in_array( $status, array( 'cancelled', 'completed', 'expired', 'halted' ), true );
}
