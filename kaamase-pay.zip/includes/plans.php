<?php
/**
 * Plans and prices.
 *
 * Every plan lives in the database and is created on the admin screen.
 * Nothing about what you sell or what it costs is written in a file.
 *
 * Why that matters more than it sounds
 * ------------------------------------
 * A price in code is a price that needs a developer, a deployment and a
 * moment of nerve to change. So it does not get changed. It gets guessed
 * once, at the point when you know least about what people will pay, and
 * then left. Pricing a new marketplace is something you have to be able
 * to get wrong twice before you get it right, and that only happens if
 * changing it takes a minute.
 *
 * A plan grants extra allowance on the meters the core plugin defines,
 * for a number of days. That is the only shape there is, and both things
 * you sell fit it: a one time pack sets the date once, a subscription
 * pushes it forward every time Razorpay charges.
 *
 * @package KaamasePay
 * @version 1.0.0
 * @since   1.0.0
 */

defined( 'ABSPATH' ) || exit;


/**
 * All plans, as stored.
 *
 * @since 1.0.0
 * @return array[] Keyed by plan ID.
 */
function kaamase_pay_plans() {

	$plans = (array) get_option( KAAMASE_PAY_PLANS, array() );

	return array_filter( $plans, 'is_array' );
}

/**
 * One plan.
 *
 * @since 1.0.0
 * @param string $id Plan ID.
 * @return array|null
 */
function kaamase_pay_plan( $id ) {

	$plans = kaamase_pay_plans();

	return $plans[ $id ] ?? null;
}

/**
 * Plans a person can actually buy right now.
 *
 * @since 1.0.0
 * @return array[]
 */
function kaamase_pay_active_plans() {

	return array_filter(
		kaamase_pay_plans(),
		static function ( $plan ) {
			return ! empty( $plan['active'] );
		}
	);
}

/**
 * A blank plan.
 *
 * @since 1.0.0
 * @return array
 */
function kaamase_pay_blank_plan() {

	return array(
		'id'                => '',
		'name'              => '',
		'note'              => '',
		'active'            => 0,
		'kind'              => 'pack',
		'price_once'        => 0,
		'days'              => 30,
		'price_monthly'     => 0,
		'price_yearly'      => 0,
		'price_lifetime'    => 0,
		'rzp_plan_monthly'  => '',
		'rzp_plan_yearly'   => '',
		'grants'            => array(),
	);
}

/**
 * What a plan costs for a given period.
 *
 * @since 1.0.0
 * @param array  $plan   The plan.
 * @param string $period once, monthly or yearly.
 * @return float Rupees.
 */
function kaamase_pay_price( $plan, $period ) {

	if ( 'monthly' === $period ) {
		return (float) ( $plan['price_monthly'] ?? 0 );
	}

	if ( 'yearly' === $period ) {
		return (float) ( $plan['price_yearly'] ?? 0 );
	}

	if ( 'lifetime' === $period ) {
		return (float) ( $plan['price_lifetime'] ?? 0 );
	}

	return (float) ( $plan['price_once'] ?? 0 );
}

/**
 * How many days a period buys.
 *
 * @since 1.0.0
 * @param array  $plan   The plan.
 * @param string $period once, monthly or yearly.
 * @return int
 */
function kaamase_pay_days( $plan, $period ) {

	if ( 'monthly' === $period ) {
		return 30;
	}

	if ( 'yearly' === $period ) {
		return 365;
	}

	if ( 'lifetime' === $period ) {
		return KAAMASE_PAY_LIFETIME_DAYS;
	}

	return max( 1, (int) ( $plan['days'] ?? 30 ) );
}

/**
 * How long "lifetime" lasts, in days.
 *
 * A hundred years, because access here is a date rather than a flag and
 * a date is what everything downstream already reads. Giving lifetime
 * its own kind of record would mean every check that asks "is this
 * still running" needing a second branch, and the branch nobody
 * remembers is the one that lets access lapse on somebody who paid for
 * it once.
 *
 * A date this far out is also what the wording keys off: anything
 * beyond fifty years reads as "does not end" rather than printing a
 * date in the next century at somebody.
 */
if ( ! defined( 'KAAMASE_PAY_LIFETIME_DAYS' ) ) {
	define( 'KAAMASE_PAY_LIFETIME_DAYS', 36500 );
}

if ( ! function_exists( 'kaamase_pay_is_endless' ) ) {
	/**
	 * Whether an expiry is far enough out to be treated as never.
	 *
	 * @since 1.3.0
	 * @param int $expires Unix seconds.
	 * @return bool
	 */
	function kaamase_pay_is_endless( $expires ) {
		return (int) $expires > time() + ( 50 * YEAR_IN_SECONDS );
	}
}


/* ==========================================================================
   THE SCREEN
   ========================================================================== */

/**
 * Render the plans screen.
 *
 * @since 1.0.0
 * @return void
 */
function kaamase_pay_plans_page() {

	if ( ! current_user_can( 'manage_options' ) ) {
		return;
	}

	// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Read only view selection.
	$editing = isset( $_GET['plan'] ) ? sanitize_key( wp_unslash( $_GET['plan'] ) ) : '';
	$plan    = $editing ? kaamase_pay_plan( $editing ) : null;
	$plan    = $plan ? array_merge( kaamase_pay_blank_plan(), $plan ) : kaamase_pay_blank_plan();
	?>
	<div class="wrap">

		<h1><?php esc_html_e( 'Plans and prices', 'kaamase-pay' ); ?></h1>

		<p class="description" style="max-width:44em">
			<?php esc_html_e( 'A plan gives somebody extra allowance on top of the free numbers, for a number of days. Change a price here whenever you like. Nothing needs a code change and nobody who has already paid is affected by it.', 'kaamase-pay' ); ?>
		</p>

		<h2><?php esc_html_e( 'Existing plans', 'kaamase-pay' ); ?></h2>

		<?php kaamase_pay_render_plan_list(); ?>

		<hr>

		<h2>
			<?php
			echo $editing
				? esc_html__( 'Edit plan', 'kaamase-pay' )
				: esc_html__( 'Add a plan', 'kaamase-pay' );
			?>
		</h2>

		<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">

			<input type="hidden" name="action" value="kaamase_pay_save_plan">
			<input type="hidden" name="original_id" value="<?php echo esc_attr( (string) $editing ); ?>">
			<?php wp_nonce_field( 'kaamase_pay_save_plan', 'kaamase_pay_plan_nonce' ); ?>

			<table class="form-table" role="presentation">

				<tr>
					<th scope="row"><label for="kp_name"><?php esc_html_e( 'Name', 'kaamase-pay' ); ?></label></th>
					<td>
						<input type="text" class="regular-text" id="kp_name" name="name" required
							value="<?php echo esc_attr( (string) $plan['name'] ); ?>">
						<p class="description"><?php esc_html_e( 'What the employer sees. Plain words, for example Contractor or Busy month.', 'kaamase-pay' ); ?></p>
					</td>
				</tr>

				<tr>
					<th scope="row"><label for="kp_note"><?php esc_html_e( 'One line about it', 'kaamase-pay' ); ?></label></th>
					<td>
						<input type="text" class="large-text" id="kp_note" name="note"
							value="<?php echo esc_attr( (string) $plan['note'] ); ?>">
					</td>
				</tr>

				<tr>
					<th scope="row"><?php esc_html_e( 'Kind', 'kaamase-pay' ); ?></th>
					<td>
						<label>
							<input type="radio" name="kind" value="pack" <?php checked( $plan['kind'], 'pack' ); ?>>
							<?php esc_html_e( 'Paid once, lasts a set number of days', 'kaamase-pay' ); ?>
						</label><br>
						<label>
							<input type="radio" name="kind" value="subscription" <?php checked( $plan['kind'], 'subscription' ); ?>>
							<?php esc_html_e( 'Subscription, renews on its own', 'kaamase-pay' ); ?>
						</label>
						<p class="description"><?php esc_html_e( 'A one time pack is the easier sell to somebody who has never paid for anything online. A subscription is worth more to you. Having both is usually right.', 'kaamase-pay' ); ?></p>
					</td>
				</tr>

				<tr>
					<th scope="row"><label for="kp_once"><?php esc_html_e( 'One time price', 'kaamase-pay' ); ?></label></th>
					<td>
						<input type="number" min="0" step="1" class="small-text" id="kp_once" name="price_once"
							value="<?php echo esc_attr( (string) $plan['price_once'] ); ?>">
						<?php esc_html_e( 'for', 'kaamase-pay' ); ?>
						<input type="number" min="1" step="1" class="small-text" id="kp_days" name="days"
							value="<?php echo esc_attr( (string) $plan['days'] ); ?>">
						<?php esc_html_e( 'days', 'kaamase-pay' ); ?>
					</td>
				</tr>

				<tr>
					<th scope="row"><label for="kp_monthly"><?php esc_html_e( 'Monthly price', 'kaamase-pay' ); ?></label></th>
					<td>
						<input type="number" min="0" step="1" class="small-text" id="kp_monthly" name="price_monthly"
							value="<?php echo esc_attr( (string) $plan['price_monthly'] ); ?>">
						<?php if ( $plan['rzp_plan_monthly'] ) : ?>
							<code><?php echo esc_html( (string) $plan['rzp_plan_monthly'] ); ?></code>
						<?php endif; ?>
					</td>
				</tr>

				<tr>
					<th scope="row"><label for="kp_yearly"><?php esc_html_e( 'Yearly price', 'kaamase-pay' ); ?></label></th>
					<td>
						<input type="number" min="0" step="1" class="small-text" id="kp_yearly" name="price_yearly"
							value="<?php echo esc_attr( (string) $plan['price_yearly'] ); ?>">
						<?php if ( $plan['rzp_plan_yearly'] ) : ?>
							<code><?php echo esc_html( (string) $plan['rzp_plan_yearly'] ); ?></code>
						<?php endif; ?>
						<p class="description"><?php esc_html_e( 'Leave a price at zero to not offer that period. Saving a subscription price creates the matching plan at Razorpay automatically, so you never open their dashboard to change a price.', 'kaamase-pay' ); ?></p>
					</td>
				</tr>

				<tr>
					<th scope="row"><label for="kp_lifetime"><?php esc_html_e( 'Lifetime price', 'kaamase-pay' ); ?></label></th>
					<td>
						<input type="number" min="0" step="1" class="small-text" id="kp_lifetime" name="price_lifetime"
							value="<?php echo esc_attr( (string) $plan['price_lifetime'] ); ?>">
						<p class="description" style="max-width:40em">
							<?php esc_html_e( 'Paid once, never expires, never renews. Worth thinking about before you offer it: the people who buy it are usually the ones who would have paid every year, and you cannot take it back later without breaking a promise. Leave at zero to not offer it.', 'kaamase-pay' ); ?>
						</p>
					</td>
				</tr>

				<tr>
					<th scope="row"><?php esc_html_e( 'What it gives', 'kaamase-pay' ); ?></th>
					<td>
						<?php foreach ( kaamase_meters() as $key => $meter ) : ?>
							<p>
								<label>
									<input type="number" min="0" step="1" class="small-text"
										name="grants[<?php echo esc_attr( $key ); ?>]"
										value="<?php echo esc_attr( (string) ( $plan['grants'][ $key ] ?? 0 ) ); ?>">
									<?php
									printf(
										/* translators: %s: meter label */
										esc_html__( 'extra %s', 'kaamase-pay' ),
										esc_html( strtolower( $meter['label'] ) )
									);
									?>
								</label>
							</p>
						<?php endforeach; ?>

						<p class="description" style="max-width:40em">
							<?php esc_html_e( 'These are added on top of the free allowance, not instead of it. Somebody who buys this gets the free number plus this number.', 'kaamase-pay' ); ?>
						</p>
					</td>
				</tr>

				<tr>
					<th scope="row"><?php esc_html_e( 'Show it', 'kaamase-pay' ); ?></th>
					<td>
						<label>
							<input type="checkbox" name="active" value="1" <?php checked( (int) $plan['active'], 1 ); ?>>
							<?php esc_html_e( 'Offer this plan to people', 'kaamase-pay' ); ?>
						</label>
					</td>
				</tr>

			</table>

			<?php submit_button( $editing ? __( 'Save plan', 'kaamase-pay' ) : __( 'Add plan', 'kaamase-pay' ) ); ?>

		</form>

	</div>
	<?php
}

/**
 * The list of plans.
 *
 * @since 1.0.0
 * @return void
 */
function kaamase_pay_render_plan_list() {

	$plans = kaamase_pay_plans();

	if ( empty( $plans ) ) {
		echo '<p>' . esc_html__( 'No plans yet. Add one below.', 'kaamase-pay' ) . '</p>';

		return;
	}

	$currency = (string) kaamase_pay_setting( 'currency', 'INR' );

	echo '<table class="wp-list-table widefat fixed striped"><thead><tr>'
		. '<th>' . esc_html__( 'Plan', 'kaamase-pay' ) . '</th>'
		. '<th>' . esc_html__( 'Prices', 'kaamase-pay' ) . '</th>'
		. '<th>' . esc_html__( 'Gives', 'kaamase-pay' ) . '</th>'
		. '<th>' . esc_html__( 'Shown', 'kaamase-pay' ) . '</th>'
		. '<th></th></tr></thead><tbody>';

	$meters = kaamase_meters();

	foreach ( $plans as $id => $plan ) {

		$prices = array();

		if ( ! empty( $plan['price_once'] ) ) {
			$prices[] = sprintf( '%s %s / %d days', $currency, $plan['price_once'], (int) $plan['days'] );
		}

		if ( ! empty( $plan['price_monthly'] ) ) {
			$prices[] = sprintf( '%s %s / month', $currency, $plan['price_monthly'] );
		}

		if ( ! empty( $plan['price_yearly'] ) ) {
			$prices[] = sprintf( '%s %s / year', $currency, $plan['price_yearly'] );
		}

		if ( ! empty( $plan['price_lifetime'] ) ) {
			$prices[] = sprintf( '%s %s lifetime', $currency, $plan['price_lifetime'] );
		}

		$gives = array();

		foreach ( (array) ( $plan['grants'] ?? array() ) as $key => $amount ) {

			if ( (int) $amount > 0 && isset( $meters[ $key ] ) ) {
				$gives[] = '+' . (int) $amount . ' ' . strtolower( $meters[ $key ]['label'] );
			}
		}

		printf(
			'<tr><td><strong>%1$s</strong><br><span class="description">%2$s</span></td>'
			. '<td>%3$s</td><td>%4$s</td><td>%5$s</td>'
			. '<td><a href="%6$s">%7$s</a></td></tr>',
			esc_html( (string) $plan['name'] ),
			esc_html( (string) ( $plan['note'] ?? '' ) ),
			esc_html( $prices ? implode( ', ', $prices ) : '—' ),
			esc_html( $gives ? implode( ', ', $gives ) : '—' ),
			empty( $plan['active'] ) ? esc_html__( 'No', 'kaamase-pay' ) : esc_html__( 'Yes', 'kaamase-pay' ),
			esc_url( admin_url( 'admin.php?page=kaamase-pay-plans&plan=' . rawurlencode( (string) $id ) ) ),
			esc_html__( 'Edit', 'kaamase-pay' )
		);
	}

	echo '</tbody></table>';
}

/**
 * Save a plan.
 *
 * @since 1.0.0
 * @return void
 */
function kaamase_pay_save_plan() {

	$back = admin_url( 'admin.php?page=kaamase-pay-plans' );

	if ( ! current_user_can( 'manage_options' ) ) {
		wp_safe_redirect( $back );
		exit;
	}

	if ( ! isset( $_POST['kaamase_pay_plan_nonce'] )
		|| ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['kaamase_pay_plan_nonce'] ) ), 'kaamase_pay_save_plan' ) ) {
		wp_safe_redirect( $back );
		exit;
	}

	$plans    = kaamase_pay_plans();
	$original = isset( $_POST['original_id'] ) ? sanitize_key( wp_unslash( $_POST['original_id'] ) ) : '';
	$name     = sanitize_text_field( wp_unslash( $_POST['name'] ?? '' ) );

	if ( '' === $name ) {
		wp_safe_redirect( $back );
		exit;
	}

	$id      = $original ? $original : sanitize_key( substr( sanitize_title( $name ), 0, 32 ) );
	$id      = $id ? $id : 'plan' . time();
	$current = $plans[ $id ] ?? kaamase_pay_blank_plan();

	$grants = array();

	foreach ( kaamase_meters() as $key => $meter ) {

		unset( $meter );

		// phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- Cast below.
		$raw = $_POST['grants'][ $key ] ?? 0;

		$grants[ $key ] = max( 0, (int) $raw );
	}

	$plan = array_merge(
		$current,
		array(
			'id'            => $id,
			'name'          => $name,
			'note'          => sanitize_text_field( wp_unslash( $_POST['note'] ?? '' ) ),
			'kind'          => 'subscription' === ( $_POST['kind'] ?? 'pack' ) ? 'subscription' : 'pack',
			'price_once'    => max( 0, (int) ( $_POST['price_once'] ?? 0 ) ),
			'days'          => max( 1, (int) ( $_POST['days'] ?? 30 ) ),
			'price_monthly' => max( 0, (int) ( $_POST['price_monthly'] ?? 0 ) ),
			'price_yearly'  => max( 0, (int) ( $_POST['price_yearly'] ?? 0 ) ),
			'price_lifetime' => max( 0, (int) ( $_POST['price_lifetime'] ?? 0 ) ),
			'grants'        => $grants,
			'active'        => empty( $_POST['active'] ) ? 0 : 1,
		)
	);

	/*
	 * A Razorpay plan is made when a subscription price is set or
	 * changed, so a price is never typed twice in two places.
	 *
	 * Their plans cannot be edited once created, so a changed price
	 * makes a new one. The old ID stays on anybody already subscribed
	 * to it, which is the behaviour you want: somebody who signed up at
	 * two hundred keeps paying two hundred, and a price rise never
	 * reaches into a subscription somebody already agreed to.
	 */
	foreach ( array( 'monthly', 'yearly' ) as $period ) {

		$price_key = 'price_' . $period;
		$rzp_key   = 'rzp_plan_' . $period;
		$price     = (float) $plan[ $price_key ];

		if ( $price <= 0 ) {
			$plan[ $rzp_key ] = '';

			continue;
		}

		$unchanged = (float) ( $current[ $price_key ] ?? 0 ) === $price && ! empty( $current[ $rzp_key ] );

		if ( $unchanged ) {
			continue;
		}

		$created = kaamase_pay_create_plan( $name . ' ' . $period, $price, $period );

		if ( is_wp_error( $created ) ) {

			set_transient(
				'kaamase_pay_plan_error',
				$created->get_error_message(),
				60
			);

			$plan[ $rzp_key ] = '';

			continue;
		}

		$plan[ $rzp_key ] = (string) ( $created['id'] ?? '' );
	}

	$plans[ $id ] = $plan;

	update_option( KAAMASE_PAY_PLANS, $plans, false );

	wp_safe_redirect( add_query_arg( 'plan', $id, $back ) );
	exit;
}
add_action( 'admin_post_kaamase_pay_save_plan', 'kaamase_pay_save_plan' );

/**
 * Show anything Razorpay refused.
 *
 * @since 1.0.0
 * @return void
 */
function kaamase_pay_plan_error_notice() {

	$error = get_transient( 'kaamase_pay_plan_error' );

	if ( ! $error ) {
		return;
	}

	delete_transient( 'kaamase_pay_plan_error' );

	echo '<div class="notice notice-error"><p>'
		. esc_html__( 'The plan was saved, but Razorpay would not create the subscription plan for it, so that period cannot be sold yet.', 'kaamase-pay' )
		. ' ' . esc_html( (string) $error )
		. '</p></div>';
}
add_action( 'admin_notices', 'kaamase_pay_plan_error_notice' );
