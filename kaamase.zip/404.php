<?php
/**
 * Not found.
 *
 * This page will get more traffic than a 404 usually does, and for one
 * specific reason.
 *
 * Job links get shared in WhatsApp groups. Somebody posts a job for two
 * masons, it gets forwarded around three groups, and by the evening the
 * position is filled and the post is closed. The link keeps circulating
 * for days afterwards. Every person who taps it lands here.
 *
 * That person is not lost. They are a worker actively looking for work,
 * arriving with intent, at the exact moment they are most receptive. A
 * generic "page not found" wastes them. Telling them the job is probably
 * gone and pointing at current openings in the same breath does not.
 *
 * So this template looks at what was asked for and answers accordingly.
 * No cartoon, no joke, no apology. The people landing here are usually
 * standing outside somewhere on a slow connection wanting one thing.
 *
 * @package Kaamase
 * @version 1.0.0
 * @since   1.0.0
 */

defined( 'ABSPATH' ) || exit;

get_header();

/*
 * Guess what the visitor was after from the path they asked for.
 *
 * Only ever used to choose which message to show. Nothing from the
 * request is printed back into the page, because a 404 that echoes the
 * requested URL is a reflected cross site scripting hole and a very
 * common one.
 */
$kaamase_path = isset( $_SERVER['REQUEST_URI'] )
	? wp_parse_url( esc_url_raw( wp_unslash( $_SERVER['REQUEST_URI'] ) ), PHP_URL_PATH )
	: '';

$kaamase_path = strtolower( (string) $kaamase_path );

$kaamase_context = 'generic';

if ( false !== strpos( $kaamase_path, '/job' ) ) {
	$kaamase_context = 'job';
} elseif ( false !== strpos( $kaamase_path, '/worker' ) ) {
	$kaamase_context = 'worker';
} elseif ( false !== strpos( $kaamase_path, '/team' ) || false !== strpos( $kaamase_path, '/gang' ) ) {
	$kaamase_context = 'team';
}
?>

<div class="ka-container ka-container--narrow ka-section">

	<div class="ka-stack--lg">

		<?php
		/* --------------------------------------------------------------
		 * The message
		 * ------------------------------------------------------------ */
		?>
		<header class="ka-stack">

			<?php if ( 'job' === $kaamase_context ) : ?>

				<h1><?php esc_html_e( 'This job is no longer open', 'kaamase' ); ?></h1>

				<p class="ka-lead ka-soft">
					<?php
					esc_html_e(
						'It has probably been filled, or the employer closed it. Links shared in WhatsApp keep working for days after a job is taken.',
						'kaamase'
					);
					?>
				</p>

				<p class="ka-soft">
					<?php esc_html_e( 'There is other work posted right now.', 'kaamase' ); ?>
				</p>

				<a class="ka-btn ka-btn--action ka-btn--lg" href="<?php echo esc_url( home_url( '/jobs/' ) ); ?>">
					<?php esc_html_e( 'See jobs open now', 'kaamase' ); ?>
				</a>

			<?php elseif ( 'worker' === $kaamase_context || 'team' === $kaamase_context ) : ?>

				<h1><?php esc_html_e( 'This profile is not available', 'kaamase' ); ?></h1>

				<p class="ka-lead ka-soft">
					<?php
					esc_html_e(
						'The person may have removed their profile, or the link is out of date.',
						'kaamase'
					);
					?>
				</p>

				<a class="ka-btn ka-btn--action ka-btn--lg" href="<?php echo esc_url( home_url( '/workers/' ) ); ?>">
					<?php esc_html_e( 'Find other workers', 'kaamase' ); ?>
				</a>

			<?php else : ?>

				<h1><?php esc_html_e( 'This page is not here', 'kaamase' ); ?></h1>

				<p class="ka-lead ka-soft">
					<?php
					esc_html_e(
						'The link may be old, or it may have been typed wrong. Try searching instead.',
						'kaamase'
					);
					?>
				</p>

			<?php endif; ?>

		</header>

		<?php
		/* --------------------------------------------------------------
		 * Search
		 *
		 * Placed high, because a person who arrives here already knows
		 * what they wanted. Giving them a box is better than giving them
		 * a menu.
		 * ------------------------------------------------------------ */
		?>
		<div class="ka-card ka-card--pad-lg">
			<h2 class="ka-text-lg"><?php esc_html_e( 'Search Kaam Ase', 'kaamase' ); ?></h2>

			<div class="ka-mt-4">
				<?php get_search_form(); ?>
			</div>
		</div>

		<?php
		/* --------------------------------------------------------------
		 * Where to go instead
		 * ------------------------------------------------------------ */
		?>
		<nav class="ka-404__links" aria-label="<?php esc_attr_e( 'Useful links', 'kaamase' ); ?>">

			<h2 class="ka-text-lg"><?php esc_html_e( 'Or go to', 'kaamase' ); ?></h2>

			<ul class="ka-grid ka-grid--2 ka-mt-4">

				<li class="ka-card ka-card--link ka-card--flat">
					<a href="<?php echo esc_url( home_url( '/jobs/' ) ); ?>">
						<strong><?php esc_html_e( 'Find work', 'kaamase' ); ?></strong>
					</a>
					<p class="ka-small ka-mute">
						<?php esc_html_e( 'Jobs posted across Nagaland', 'kaamase' ); ?>
					</p>
				</li>

				<li class="ka-card ka-card--link ka-card--flat">
					<a href="<?php echo esc_url( home_url( '/workers/' ) ); ?>">
						<strong><?php esc_html_e( 'Find workers', 'kaamase' ); ?></strong>
					</a>
					<p class="ka-small ka-mute">
						<?php esc_html_e( 'Search by trade and district', 'kaamase' ); ?>
					</p>
				</li>

				<li class="ka-card ka-card--link ka-card--flat">
					<a href="<?php echo esc_url( home_url( '/post-job/' ) ); ?>">
						<strong><?php esc_html_e( 'Post a job', 'kaamase' ); ?></strong>
					</a>
					<p class="ka-small ka-mute">
						<?php esc_html_e( 'Free to post, any district', 'kaamase' ); ?>
					</p>
				</li>

				<li class="ka-card ka-card--link ka-card--flat">
					<a href="<?php echo esc_url( home_url( '/' ) ); ?>">
						<strong><?php esc_html_e( 'Home', 'kaamase' ); ?></strong>
					</a>
					<p class="ka-small ka-mute">
						<?php esc_html_e( 'Start again from the beginning', 'kaamase' ); ?>
					</p>
				</li>

			</ul>

		</nav>

		<?php
		/* --------------------------------------------------------------
		 * Report
		 *
		 * A broken link that a real person hit is worth knowing about.
		 * On a site this new, most 404s are our own mistakes.
		 * ------------------------------------------------------------ */
		?>
		<p class="ka-small ka-mute">
			<?php esc_html_e( 'Think this is a mistake on our side?', 'kaamase' ); ?>
			<a href="<?php echo esc_url( home_url( '/report/' ) ); ?>">
				<?php esc_html_e( 'Tell us', 'kaamase' ); ?>
			</a>
		</p>

	</div>

</div>

<?php
get_footer();
