<?php
/**
 * Search form.
 *
 * Small file, three decisions worth stating.
 *
 * First, it keeps the filters the visitor already set. Somebody browsing
 * electricians in Mokokchung who then types a name into search should
 * still be in Mokokchung afterwards. Losing their filters and dumping
 * them into a statewide result set is the sort of thing that makes a
 * person give up and phone somebody instead.
 *
 * Second, the placeholder teaches. A first time user types something
 * like "need man for house work" and gets nothing back. Showing real
 * trade names in the field tells them what kind of word works here
 * before they waste a search on it.
 *
 * Third, every instance gets a unique id. This form appears in the
 * header, in the empty state and on the results page, sometimes twice on
 * the same page. Repeated ids break the label association and a screen
 * reader then announces the wrong field.
 *
 * @package Kaamase
 * @version 1.0.0
 * @since   1.0.0
 */

defined( 'ABSPATH' ) || exit;

/*
 * Unique identifier per instance.
 *
 * Static rather than random so the value is stable within a request,
 * which keeps output identical between page loads and therefore
 * cacheable.
 */
static $kaamase_search_instance = 0;
$kaamase_search_instance++;

$kaamase_search_id = 'ka-search-' . $kaamase_search_instance;

/*
 * Arguments passed through get_search_form( array( ... ) ).
 *
 * Templates use this to scope the form, for example a search box on the
 * workers archive that only searches workers.
 */
$kaamase_args = isset( $args ) && is_array( $args ) ? $args : array();

$kaamase_args = wp_parse_args(
	$kaamase_args,
	array(
		'label'       => __( 'Search', 'kaamase' ),
		'placeholder' => __( 'Mason, electrician, driver, cook', 'kaamase' ),
		'button'      => __( 'Search', 'kaamase' ),
		'post_type'   => '',
		'action'      => home_url( '/' ),
	)
);

/*
 * Work out which post type to stay inside.
 *
 * If the caller did not say, and we are on an archive, stay in that
 * archive. A search from the jobs page should return jobs.
 */
$kaamase_scope = (string) $kaamase_args['post_type'];

if ( '' === $kaamase_scope ) {
	$kaamase_queried = get_query_var( 'post_type' );
	$kaamase_queried = is_array( $kaamase_queried ) ? reset( $kaamase_queried ) : (string) $kaamase_queried;

	if ( in_array( $kaamase_queried, array( 'kaamase_worker', 'kaamase_gang', 'kaamase_job' ), true ) ) {
		$kaamase_scope = $kaamase_queried;
	}
}

/*
 * Filters currently applied, carried forward as hidden fields.
 *
 * Only a fixed list is carried. Never loop over the whole query string
 * and echo it back, because that turns the search form into a way to
 * inject arbitrary parameters into every link on the site.
 */
$kaamase_carry = array();

foreach ( array( 'kaamase_trade', 'kaamase_district', 'kaamase_available' ) as $kaamase_key ) {

	// phpcs:ignore WordPress.Security.NonceVerification.Recommended
	if ( empty( $_GET[ $kaamase_key ] ) ) {
		continue;
	}

	// phpcs:ignore WordPress.Security.NonceVerification.Recommended
	$kaamase_value = sanitize_text_field( wp_unslash( $_GET[ $kaamase_key ] ) );

	if ( '' !== $kaamase_value ) {
		$kaamase_carry[ $kaamase_key ] = $kaamase_value;
	}
}
?>

<form role="search" method="get" class="ka-searchform"
	action="<?php echo esc_url( $kaamase_args['action'] ); ?>">

	<label class="ka-sr" for="<?php echo esc_attr( $kaamase_search_id ); ?>">
		<?php echo esc_html( $kaamase_args['label'] ); ?>
	</label>

	<div class="ka-search">

		<input
			class="ka-input"
			type="search"
			id="<?php echo esc_attr( $kaamase_search_id ); ?>"
			name="s"
			value="<?php echo esc_attr( get_search_query() ); ?>"
			placeholder="<?php echo esc_attr( $kaamase_args['placeholder'] ); ?>"
			autocomplete="off"
			<?php
			/*
			 * Deliberately no autofocus.
			 *
			 * Autofocus on a phone opens the keyboard as soon as the page
			 * loads, covering half the screen before the visitor has read
			 * anything. It also scrolls the page to the field, which on a
			 * slow connection happens while content is still arriving and
			 * throws away wherever they were looking.
			 */
			?>
		>

		<button class="ka-btn ka-btn--primary" type="submit">
			<?php echo esc_html( $kaamase_args['button'] ); ?>
		</button>

	</div>

	<?php
	// Stay inside the current post type.
	if ( '' !== $kaamase_scope ) :
		?>
		<input type="hidden" name="post_type" value="<?php echo esc_attr( $kaamase_scope ); ?>">
		<?php
	endif;

	// Keep the filters the visitor already chose.
	foreach ( $kaamase_carry as $kaamase_key => $kaamase_value ) :
		?>
		<input type="hidden" name="<?php echo esc_attr( $kaamase_key ); ?>"
			value="<?php echo esc_attr( $kaamase_value ); ?>">
		<?php
	endforeach;
	?>

</form>
