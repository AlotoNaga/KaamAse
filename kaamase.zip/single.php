<?php
/**
 * Single post.
 *
 * The fallback for ordinary WordPress content: blog posts, and any post
 * type that does not have a template of its own. Without this file
 * WordPress falls through to index.php, which renders a card in a grid
 * rather than an article, and never calls the_content().
 *
 * @package Kaamase
 * @version 1.1.0
 * @since   1.1.0
 */

defined( 'ABSPATH' ) || exit;

get_header();
?>

<div class="ka-container ka-container--narrow ka-section">

	<?php
	while ( have_posts() ) :
		the_post();
		?>

		<article <?php post_class( 'ka-page' ); ?>>

			<header class="ka-page-head ka-stack">
				<h1><?php the_title(); ?></h1>

				<p class="ka-small ka-mute">
					<time datetime="<?php echo esc_attr( get_the_date( 'c' ) ); ?>">
						<?php echo esc_html( get_the_date() ); ?>
					</time>
				</p>
			</header>

			<?php if ( has_post_thumbnail() ) : ?>
				<figure class="ka-page__media ka-mt-6">
					<?php
					the_post_thumbnail(
						'kaamase-wide',
						array(
							'class'    => 'ka-page__image',
							'decoding' => 'async',
						)
					);
					?>
				</figure>
			<?php endif; ?>

			<div class="ka-prose ka-mt-6">
				<?php the_content(); ?>
			</div>

			<?php
			wp_link_pages(
				array(
					'before'    => '<nav class="ka-pagination ka-mt-6" aria-label="' . esc_attr__( 'Page sections', 'kaamase' ) . '"><ul class="ka-cluster"><li>',
					'after'     => '</li></ul></nav>',
					'separator' => '</li><li>',
				)
			);
			?>

		</article>

		<?php
		/*
		 * Previous and next. Kept plain, and only rendered when there is
		 * something on at least one side, so a single post on a new site
		 * does not show an empty navigation block.
		 */
		$kaamase_prev = get_previous_post();
		$kaamase_next = get_next_post();

		if ( $kaamase_prev || $kaamase_next ) :
			?>
			<nav class="ka-postnav ka-mt-6" aria-label="<?php esc_attr_e( 'More posts', 'kaamase' ); ?>">

				<?php if ( $kaamase_prev ) : ?>
					<a class="ka-card ka-card--link ka-card--flat" href="<?php echo esc_url( get_permalink( $kaamase_prev ) ); ?>">
						<span class="ka-small ka-mute"><?php esc_html_e( 'Previous', 'kaamase' ); ?></span>
						<strong><?php echo esc_html( get_the_title( $kaamase_prev ) ); ?></strong>
					</a>
				<?php endif; ?>

				<?php if ( $kaamase_next ) : ?>
					<a class="ka-card ka-card--link ka-card--flat" href="<?php echo esc_url( get_permalink( $kaamase_next ) ); ?>">
						<span class="ka-small ka-mute"><?php esc_html_e( 'Next', 'kaamase' ); ?></span>
						<strong><?php echo esc_html( get_the_title( $kaamase_next ) ); ?></strong>
					</a>
				<?php endif; ?>

			</nav>
			<?php
		endif;

	endwhile;
	?>

</div>

<?php
get_footer();
