<?php
/**
 * Navigation.
 *
 * A custom walker so menus come out with the design system classes
 * rather than the default WordPress markup, and so submenus are usable
 * by keyboard, by screen reader and by thumb.
 *
 * The accessibility approach here is the reverse of most themes.
 *
 * Submenus render OPEN by default and the toggle button renders hidden.
 * JavaScript then unhides the button and collapses the submenu. That way
 * a visitor whose script never arrived, which on a 2G connection is a
 * real and regular event, still sees every link in the menu. A menu that
 * silently hides half its links when a script fails is worse than a menu
 * with no dropdown at all.
 *
 * Dropdowns open on click, never on hover. Hover does not exist on a
 * phone, and hover only menus are the single most common navigation
 * failure on touch devices.
 *
 * @package Kaamase
 * @version 1.1.0
 * @since   1.0.0
 *
 * Changelog
 *   1.0.1  Fixed items_wrap. The %3$s placeholder was used twice, which
 *          printed the menu items inside the opening ul tag as well as
 *          in the body of the list. Menus rendered as broken markup.
 */

defined( 'ABSPATH' ) || exit;


/* ==========================================================================
   1. THE WALKER
   ========================================================================== */

if ( ! class_exists( 'Kaamase_Nav_Walker' ) ) {

	/**
	 * Builds navigation markup for the Kaam Ase design system.
	 *
	 * @since 1.0.0
	 */
	class Kaamase_Nav_Walker extends Walker_Nav_Menu {

		/**
		 * Counter used to generate unique submenu identifiers.
		 *
		 * Needed because aria-controls must point at a unique id, and the
		 * same menu can be printed more than once on a page, for example
		 * in the header and again in the mobile drawer.
		 *
		 * @since 1.0.0
		 * @var int
		 */
		protected $submenu_count = 0;

		/**
		 * Identifier of the submenu currently being opened.
		 *
		 * @since 1.0.0
		 * @var string
		 */
		protected $current_submenu_id = '';

		/**
		 * Open a submenu list.
		 *
		 * @since 1.0.0
		 * @param string        $output Menu markup, passed by reference.
		 * @param int           $depth  Depth of the current item.
		 * @param stdClass|null $args   Menu arguments.
		 * @return void
		 */
		public function start_lvl( &$output, $depth = 0, $args = null ) {

			$indent = str_repeat( "\t", $depth + 1 );

			$classes = array( 'ka-nav__sub' );

			if ( $depth > 0 ) {
				$classes[] = 'ka-nav__sub--nested';
			}

			$output .= sprintf(
				"\n%1\$s<ul class=\"%2\$s\" id=\"%3\$s\">\n",
				$indent,
				esc_attr( implode( ' ', $classes ) ),
				esc_attr( $this->current_submenu_id )
			);
		}

		/**
		 * Close a submenu list.
		 *
		 * @since 1.0.0
		 * @param string        $output Menu markup, passed by reference.
		 * @param int           $depth  Depth of the current item.
		 * @param stdClass|null $args   Menu arguments.
		 * @return void
		 */
		public function end_lvl( &$output, $depth = 0, $args = null ) {
			$output .= str_repeat( "\t", $depth + 1 ) . "</ul>\n";
		}

		/**
		 * Open a menu item.
		 *
		 * @since 1.0.0
		 * @param string        $output            Menu markup, passed by reference.
		 * @param WP_Post       $data_object       The menu item.
		 * @param int           $depth             Depth of the current item.
		 * @param stdClass|null $args              Menu arguments.
		 * @param int           $current_object_id Current object ID.
		 * @return void
		 */
		public function start_el( &$output, $data_object, $depth = 0, $args = null, $current_object_id = 0 ) {

			$item   = $data_object;
			$indent = $depth ? str_repeat( "\t", $depth ) : '';

			$item_classes = empty( $item->classes ) ? array() : (array) $item->classes;
			$has_children = in_array( 'menu-item-has-children', $item_classes, true );
			$is_current   = $this->is_current_item( $item_classes );

			// Item classes.
			$li_classes = array( 'ka-nav__item' );

			if ( $has_children ) {
				$li_classes[] = 'ka-nav__item--parent';
			}

			if ( $is_current ) {
				$li_classes[] = 'is-current';
			}

			if ( $depth > 0 ) {
				$li_classes[] = 'ka-nav__item--sub';
			}

			/**
			 * Filter the list item classes for a menu item.
			 *
			 * @since 1.0.0
			 * @param string[] $li_classes Classes applied to the list item.
			 * @param WP_Post  $item       The menu item.
			 * @param int      $depth      Item depth.
			 */
			$li_classes = (array) apply_filters( 'kaamase_nav_item_classes', $li_classes, $item, $depth );

			$output .= sprintf(
				'%1$s<li class="%2$s">',
				$indent,
				esc_attr( implode( ' ', array_filter( $li_classes ) ) )
			);

			// Link.
			$link_class = ( isset( $args->walker_style ) && 'stack' === $args->walker_style )
				? 'ka-nav__link ka-nav__link--stack'
				: 'ka-nav__link';

			if ( $depth > 0 ) {
				$link_class .= ' ka-nav__link--sub';
			}

			$attributes = array(
				'class' => $link_class,
				'href'  => ! empty( $item->url ) ? $item->url : '',
			);

			if ( ! empty( $item->target ) ) {
				$attributes['target'] = $item->target;

				// A link opening a new tab must say so, and must not leak the referrer.
				if ( '_blank' === $item->target ) {
					$attributes['rel'] = 'noopener noreferrer';
				}
			}

			if ( ! empty( $item->xfn ) ) {
				$attributes['rel'] = trim( ( isset( $attributes['rel'] ) ? $attributes['rel'] . ' ' : '' ) . $item->xfn );
			}

			if ( ! empty( $item->attr_title ) ) {
				$attributes['title'] = $item->attr_title;
			}

			if ( $is_current ) {
				$attributes['aria-current'] = 'page';
			}

			$output .= '<a' . $this->build_attributes( $attributes ) . '>';

			// Optional icon, taken from a menu item class such as ka-icon-search.
			$output .= $this->maybe_icon( $item_classes );

			$output .= '<span class="ka-nav__text">' . esc_html( $item->title ) . '</span>';

			// Optional description, used for two line menu items in the drawer.
			if ( ! empty( $item->description ) && isset( $args->walker_style ) && 'stack' === $args->walker_style ) {
				$output .= '<span class="ka-nav__desc ka-small ka-mute">' . esc_html( $item->description ) . '</span>';
			}

			$output .= '</a>';

			/*
			 * Submenu toggle.
			 *
			 * Rendered with the hidden attribute and aria-expanded true,
			 * matching the fact that the submenu itself starts open. The
			 * script removes hidden, sets aria-expanded to false and
			 * collapses the list. No script means no toggle and no hidden
			 * links.
			 */
			if ( $has_children ) {

				$this->submenu_count++;
				$this->current_submenu_id = 'ka-submenu-' . $this->submenu_count;

				$output .= sprintf(
					'<button type="button" class="ka-nav__toggle" aria-expanded="true" aria-controls="%1$s" hidden>'
						. '<span class="ka-sr">%2$s</span>'
						. '<svg class="ka-nav__chevron" width="20" height="20" viewBox="0 0 20 20" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" focusable="false"><path d="M5.5 7.5 10 12l4.5-4.5"/></svg>'
						. '</button>',
					esc_attr( $this->current_submenu_id ),
					sprintf(
						/* translators: %s: parent menu item title */
						esc_html__( 'Show items under %s', 'kaamase' ),
						esc_html( $item->title )
					)
				);
			}
		}

		/**
		 * Close a menu item.
		 *
		 * @since 1.0.0
		 * @param string        $output      Menu markup, passed by reference.
		 * @param WP_Post       $data_object The menu item.
		 * @param int           $depth       Depth of the current item.
		 * @param stdClass|null $args        Menu arguments.
		 * @return void
		 */
		public function end_el( &$output, $data_object, $depth = 0, $args = null ) {
			$output .= "</li>\n";
		}

		/**
		 * Whether a menu item represents the page being viewed.
		 *
		 * @since 1.0.0
		 * @param string[] $classes Menu item classes from WordPress.
		 * @return bool
		 */
		protected function is_current_item( $classes ) {

			$markers = array(
				'current-menu-item',
				'current_page_item',
				'current-menu-ancestor',
				'current-menu-parent',
				'current_page_parent',
			);

			foreach ( $markers as $marker ) {
				if ( in_array( $marker, $classes, true ) ) {
					return true;
				}
			}

			return false;
		}

		/**
		 * Render an inline icon when the menu item asks for one.
		 *
		 * Add a class such as ka-icon-search to a menu item in the admin
		 * and the matching SVG from assets/icons is inlined before the
		 * label. Missing icons return nothing rather than breaking.
		 *
		 * @since 1.0.0
		 * @param string[] $classes Menu item classes.
		 * @return string Icon markup or an empty string.
		 */
		protected function maybe_icon( $classes ) {

			if ( ! function_exists( 'kaamase_svg' ) ) {
				return '';
			}

			foreach ( $classes as $class ) {

				if ( 0 !== strpos( $class, 'ka-icon-' ) ) {
					continue;
				}

				$name = substr( $class, strlen( 'ka-icon-' ) );
				$svg  = kaamase_svg( $name, array( 'size' => 20, 'class' => 'ka-nav__icon' ) );

				if ( '' !== $svg ) {
					return $svg;
				}
			}

			return '';
		}

		/**
		 * Turn an attribute array into an escaped attribute string.
		 *
		 * @since 1.0.0
		 * @param array $attributes Attribute name and value pairs.
		 * @return string Attribute string with a leading space.
		 */
		protected function build_attributes( $attributes ) {

			$html = '';

			foreach ( $attributes as $name => $value ) {

				if ( '' === $value || null === $value ) {
					continue;
				}

				$value = ( 'href' === $name ) ? esc_url( $value ) : esc_attr( $value );
				$html .= sprintf( ' %1$s="%2$s"', esc_attr( $name ), $value );
			}

			return $html;
		}
	}
}


/* ==========================================================================
   2. RENDER HELPER

   Templates call this rather than wp_nav_menu directly, so that every
   menu on the site comes out consistent and no template has to remember
   eight arguments.
   ========================================================================== */

if ( ! function_exists( 'kaamase_nav' ) ) {
	/**
	 * Print a navigation menu.
	 *
	 * @since 1.0.0
	 * @param string $location Registered menu location.
	 * @param array  $options  Optional. style (bar or stack), class, depth, label.
	 * @return void
	 */
	function kaamase_nav( $location, $options = array() ) {

		$defaults = array(
			'style' => 'bar',
			'class' => '',
			'depth' => 2,
			'label' => '',
		);

		$options = wp_parse_args( $options, $defaults );

		$list_class = ( 'stack' === $options['style'] )
			? 'ka-nav__list ka-nav__list--stack'
			: 'ka-nav__list';

		if ( $options['class'] ) {
			$list_class .= ' ' . $options['class'];
		}

		// No menu assigned yet. Show the fallback rather than nothing at all.
		if ( ! has_nav_menu( $location ) ) {

			if ( function_exists( 'kaamase_menu_fallback' ) ) {
				kaamase_menu_fallback();
			}

			return;
		}

		wp_nav_menu(
			array(
				'theme_location'  => $location,
				'container'       => false,
				'menu_class'      => $list_class,
				'depth'           => absint( $options['depth'] ),
				'walker'          => new Kaamase_Nav_Walker(),
				'walker_style'    => $options['style'],
				'fallback_cb'     => function_exists( 'kaamase_menu_fallback' ) ? 'kaamase_menu_fallback' : false,
				'items_wrap'      => '<ul class="%2$s">%3$s</ul>',
			)
		);
	}
}

/**
 * Keep the walker style argument available inside the walker.
 *
 * wp_nav_menu strips arguments it does not recognise, so a custom one
 * has to be added back through this filter before the walker runs.
 *
 * @since 1.0.0
 * An array, not an object, and that distinction took the site down.
 *
 * wp_nav_menu parses its arguments, runs them through this filter, and
 * only then casts them to an object. So a filter that treats them as an
 * object is assigning a property to an array, which in PHP 8 is a fatal
 * error rather than a warning.
 *
 * It never showed, because kaamase_nav skips wp_nav_menu entirely while
 * no menu is assigned and draws the fallback links instead. The filter
 * therefore never ran on a fresh site. The moment a menu was created
 * and assigned, wp_nav_menu was called for the first time, this fired,
 * and every page went white. Creating a menu appeared to break the
 * site, which is exactly what it did.
 *
 * Both shapes are handled below rather than only the correct one,
 * because a plugin may pass an object here and being right about the
 * documentation is no comfort when a page is blank.
 *
 * @param array|stdClass $args Menu arguments.
 * @return array|stdClass Filtered arguments.
 */
function kaamase_preserve_walker_style( $args ) {

	if ( is_array( $args ) ) {

		if ( ! isset( $args['walker_style'] ) ) {
			$args['walker_style'] = 'bar';
		}

		return $args;
	}

	if ( is_object( $args ) && ! isset( $args->walker_style ) ) {
		$args->walker_style = 'bar';
	}

	return $args;
}
add_filter( 'wp_nav_menu_args', 'kaamase_preserve_walker_style' );

/**
 * Remove the WordPress menu item id attributes.
 *
 * They are unique per install and appear in the page source of every
 * page. Nothing in this theme styles or scripts against them.
 *
 * @since 1.0.0
 * @param string $id Menu item ID attribute.
 * @return string Empty string.
 */
function kaamase_strip_menu_item_ids( $id ) {
	unset( $id );

	return '';
}
add_filter( 'nav_menu_item_id', 'kaamase_strip_menu_item_ids' );