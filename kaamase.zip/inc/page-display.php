<?php
/**
 * Page display options.
 *
 * One checkbox on a page: hide the title and the featured image.
 *
 * Why a page would want that
 * --------------------------
 * Most pages on this site are not articles. They are the dashboard,
 * registration, posting a job, the saved list. A screen like that
 * usually opens with its own heading written into the content, and the
 * theme's heading above it repeats the same words twice in a row. That
 * reads as a mistake rather than as design, which is exactly the
 * impression a platform asking for somebody's phone number cannot
 * afford.
 *
 * Hidden, not removed
 * -------------------
 * This is the part worth being careful about, because getting it wrong
 * quietly costs search traffic.
 *
 * The heading is not deleted. It stays in the markup and is hidden
 * visually, using the same screen reader class the rest of the theme
 * uses. A page with no h1 at all is a page a search engine has to guess
 * the subject of, and a person using a screen reader lands on a page
 * with no idea what it is. Neither is a trade worth making to remove
 * one line of text from a screen.
 *
 * The featured image is a different case, and is genuinely free to hide.
 * Nothing about it is on the page for a search engine's benefit. It is
 * read from the post record by the document head, by Open Graph tags and
 * by any SEO plugin, none of which care whether the theme also drew it
 * in the body. So that one is simply not rendered.
 *
 * Neither is cloaking. Nothing here shows a search engine text that a
 * person cannot get to: the heading is the title, in the markup, in the
 * same words, and any assistive technology reads it aloud.
 *
 * @package Kaamase
 * @version 1.0.0
 * @since   1.2.0
 */

defined( 'ABSPATH' ) || exit;


/**
 * Meta key holding the choice.
 *
 * Underscore prefixed so it stays out of the custom fields box, where
 * an editor could change it by accident.
 */
define( 'KAAMASE_HIDE_HEAD_KEY', '_kaamase_hide_page_head' );


/* ==========================================================================
   1. THE CHECKBOX
   ========================================================================== */

if ( ! function_exists( 'kaamase_add_page_display_box' ) ) {
	/**
	 * Add the box to the page editor.
	 *
	 * Pages only. There are no posts on this site, and adding it to a
	 * type nobody uses is a setting somebody has to understand later for
	 * no reason.
	 *
	 * @since 1.2.0
	 * @return void
	 */
	function kaamase_add_page_display_box() {

		add_meta_box(
			'kaamase-page-display',
			__( 'Page heading', 'kaamase' ),
			'kaamase_render_page_display_box',
			'page',
			'side',
			'default'
		);
	}
}
add_action( 'add_meta_boxes', 'kaamase_add_page_display_box' );

if ( ! function_exists( 'kaamase_render_page_display_box' ) ) {
	/**
	 * Draw the checkbox.
	 *
	 * @since 1.2.0
	 * @param WP_Post $post The page being edited.
	 * @return void
	 */
	function kaamase_render_page_display_box( $post ) {

		wp_nonce_field( 'kaamase_page_display', 'kaamase_page_display_nonce' );

		$hidden = (bool) get_post_meta( $post->ID, KAAMASE_HIDE_HEAD_KEY, true );
		?>

		<p>
			<label for="kaamase-hide-page-head">
				<input type="checkbox"
					id="kaamase-hide-page-head"
					name="kaamase_hide_page_head"
					value="1"
					<?php checked( $hidden ); ?>>
				<?php esc_html_e( 'Hide the title and photo on this page', 'kaamase' ); ?>
			</label>
		</p>

		<p class="description">
			<?php esc_html_e( 'Use this when the page writes its own heading. The title stays in the page code for search engines and screen readers, it is only hidden from view. The featured image is still used for search results and link previews.', 'kaamase' ); ?>
		</p>

		<?php
	}
}

if ( ! function_exists( 'kaamase_save_page_display_box' ) ) {
	/**
	 * Store the choice.
	 *
	 * @since 1.2.0
	 * @param int $post_id Page being saved.
	 * @return void
	 */
	function kaamase_save_page_display_box( $post_id ) {

		if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) {
			return;
		}

		if ( ! isset( $_POST['kaamase_page_display_nonce'] ) ) {
			return;
		}

		$nonce = sanitize_text_field( wp_unslash( $_POST['kaamase_page_display_nonce'] ) );

		if ( ! wp_verify_nonce( $nonce, 'kaamase_page_display' ) ) {
			return;
		}

		if ( ! current_user_can( 'edit_post', $post_id ) ) {
			return;
		}

		if ( empty( $_POST['kaamase_hide_page_head'] ) ) {
			delete_post_meta( $post_id, KAAMASE_HIDE_HEAD_KEY );

			return;
		}

		update_post_meta( $post_id, KAAMASE_HIDE_HEAD_KEY, 1 );
	}
}
add_action( 'save_post_page', 'kaamase_save_page_display_box' );


/* ==========================================================================
   2. WHAT THE TEMPLATE ASKS
   ========================================================================== */

if ( ! function_exists( 'kaamase_hides_page_head' ) ) {
	/**
	 * Whether this page has asked for its heading to be out of the way.
	 *
	 * @since 1.2.0
	 * @param int $post_id Optional. Defaults to the current page.
	 * @return bool
	 */
	function kaamase_hides_page_head( $post_id = 0 ) {

		$post_id = $post_id ? (int) $post_id : (int) get_the_ID();

		if ( ! $post_id ) {
			return false;
		}

		/**
		 * Filter the decision.
		 *
		 * Here so the choice can be forced for a whole set of pages
		 * later without every one of them needing the box ticked.
		 *
		 * @since 1.2.0
		 * @param bool $hidden  Whether the heading is hidden.
		 * @param int  $post_id Page ID.
		 */
		return (bool) apply_filters(
			'kaamase_hides_page_head',
			(bool) get_post_meta( $post_id, KAAMASE_HIDE_HEAD_KEY, true ),
			$post_id
		);
	}
}


/* ==========================================================================
   3. THE LIST OF PAGES

   A column in the page list, so somebody can see at a glance which
   pages are set this way without opening each one.
   ========================================================================== */

if ( ! function_exists( 'kaamase_page_display_column' ) ) {
	/**
	 * Add the column header.
	 *
	 * @since 1.2.0
	 * @param array $columns Existing columns.
	 * @return array
	 */
	function kaamase_page_display_column( $columns ) {

		$columns['kaamase_head'] = __( 'Heading', 'kaamase' );

		return $columns;
	}
}
add_filter( 'manage_page_posts_columns', 'kaamase_page_display_column' );

if ( ! function_exists( 'kaamase_page_display_column_value' ) ) {
	/**
	 * Fill the column.
	 *
	 * @since 1.2.0
	 * @param string $column  Column key.
	 * @param int    $post_id Page ID.
	 * @return void
	 */
	function kaamase_page_display_column_value( $column, $post_id ) {

		if ( 'kaamase_head' !== $column ) {
			return;
		}

		echo esc_html(
			kaamase_hides_page_head( $post_id )
				? __( 'Hidden', 'kaamase' )
				: __( 'Shown', 'kaamase' )
		);
	}
}
add_action( 'manage_page_posts_custom_column', 'kaamase_page_display_column_value', 10, 2 );