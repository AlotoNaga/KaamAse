<?php
/**
 * Main template.
 *
 * The universal fallback. WordPress uses this whenever nothing more
 * specific exists, so it has to handle search results, archives, the
 * blog and any Kaam Ase post type that does not yet have its own
 * template file.
 *
 * The part worth reading is the empty state at the bottom.
 *
 * For the first months of this platform, most visits will land on a
 * screen with nothing on it. No workers in that district yet. No jobs in
 * that trade yet. A generic "no posts found" tells the visitor the site
 * is broken and they do not come back. A message that names what is
 * missing and offers the obvious next action is the difference between
 * losing that person and recruiting them. The empty screen is not an
 * edge case here, it is the common case, so it gets real work.
 *
 * @package Kaamase
 * @version 1.1.0
 * @since   1.0.0
 */

defined( 'ABSPATH' ) || exit;

get_header();

$kaamase_post_type = get_post_type() ? get_post_type() : get_query_var( 'post_type' );
$kaamase_post_type = is_array( $kaamase_post_type ) ? reset( $kaamase_post_type ) : (string) $kaamase_post_type;

// Wider cards for jobs, tighter grid for people.
$kaamase_grid = in_array( $kaamase_post_type, array( 'kaamase_worker', 'kaamase_gang' ), true )
	? 'ka-grid ka-grid--2 ka-grid--3'
	: 'ka-grid ka-grid--2';
?>

<div class="ka-container ka-section">

	<?php
	/* ------------------------------------------------------------------
	 * Page header
	 * ---------------------------------------------------------------- */
	?>
	<header class="ka-page-head ka-stack">

		<h1>
			<?php
			if ( is_search() ) {

				printf(
					/* translators: %s: search term */
					esc_html__( 'Results for %s', 'kaamase' ),
					'<span class="ka-page-head__term">' . esc_html( get_search_query() ) . '</span>'
				);

			} elseif ( is_archive() ) {

				echo wp_kses_post( get_the_archive_title() );

			} elseif ( is_home() && ! is_front_page() ) {

				echo esc_html( get_the_title( absint( get_option( 'page_for_posts' ) ) ) );

			} else {

				esc_html_e( 'Latest', 'kaamase' );

			}
			?>
		</h1>

		<?php if ( is_archive() && get_the_archive_description() ) : ?>
			<div class="ka-page-head__desc ka-soft">
				<?php
				/*
				 * Not run through wp_kses_post here, and that is
				 * deliberate rather than an oversight.
				 *
				 * On a Kaam Ase archive this description is not text
				 * somebody typed: the plugin builds it, and it contains
				 * the filter panel, which is a form. wp_kses_post
				 * removes form, select, option and input while keeping
				 * the text inside them, so filtering it here printed
				 * every dropdown as a run of words and left no way to
				 * filter anything. It looked like a styling fault and
				 * was a stripped tag.
				 *
				 * The untrusted part is already handled at the source:
				 * the plugin runs wp_kses_post over the term
				 * description it was given before appending anything of
				 * its own, and a term description is admin entered and
				 * filtered by WordPress on save in any case. Echoing it
				 * here is what core's own the_archive_description does.
				 */
				echo get_the_archive_description(); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
				?>
			</div>
		<?php endif; ?>

		<?php
		/*
		 * Result count.
		 *
		 * Small, and worth having. On a hiring platform the number is
		 * itself information: eleven electricians in Kohima tells a
		 * contractor something useful before they read a single card.
		 */
		if ( have_posts() ) :

			global $wp_query;
			$kaamase_found = absint( $wp_query->found_posts );
			?>
			<p class="ka-small ka-mute">
				<?php
				printf(
					esc_html(
						/* translators: %s: number of results */
						_n( '%s result', '%s results', $kaamase_found, 'kaamase' )
					),
					esc_html( number_format_i18n( $kaamase_found ) )
				);
				?>
			</p>
		<?php endif; ?>

		<?php if ( is_search() ) : ?>
			<div class="ka-page-head__search">
				<?php get_search_form(); ?>
			</div>
		<?php endif; ?>

	</header>

	<?php if ( have_posts() ) : ?>

		<div class="<?php echo esc_attr( $kaamase_grid ); ?> ka-mt-6">

			<?php
			while ( have_posts() ) :
				the_post();

				/*
				 * Route each result to the card that suits it.
				 *
				 * Kept here rather than in a template part because this
				 * is the only template that has to be generic. Once each
				 * post type has its own archive template, each of those
				 * will call its card renderer directly.
				 */
				switch ( get_post_type() ) {

					case 'kaamase_worker':
						kaamase_worker_card();
						break;

					case 'kaamase_gang':
						kaamase_gang_card();
						break;

					case 'kaamase_job':
						kaamase_job_card();
						break;

					default:
						?>
						<article <?php post_class( 'ka-card ka-card--link' ); ?>>

							<?php if ( has_post_thumbnail() ) : ?>
								<a href="<?php the_permalink(); ?>" tabindex="-1" aria-hidden="true">
									<?php
									the_post_thumbnail(
										'kaamase-card',
										array(
											'class'    => 'ka-card__image',
											'loading'  => 'lazy',
											'decoding' => 'async',
											'alt'      => '',
										)
									);
									?>
								</a>
							<?php endif; ?>

							<h2 class="ka-mt-4">
								<a href="<?php the_permalink(); ?>"><?php the_title(); ?></a>
							</h2>

							<p class="ka-small ka-mute">
								<?php echo esc_html( get_the_date() ); ?>
							</p>

							<?php if ( has_excerpt() || get_the_excerpt() ) : ?>
								<p class="ka-soft ka-mt-4"><?php echo esc_html( get_the_excerpt() ); ?></p>
							<?php endif; ?>

						</article>
						<?php
						break;
				}

			endwhile;
			?>

		</div>

		<?php kaamase_pagination(); ?>

	<?php else : ?>

		<div class="ka-mt-6">
			<?php
			/* --------------------------------------------------------------
			 * Empty states
			 *
			 * Each one names what is missing and offers the action that
			 * would fix it. Nothing here says "no posts found".
			 * ------------------------------------------------------------ */

			if ( is_search() ) {

				kaamase_empty(
					array(
						'title'        => __( 'Nothing matched that search', 'kaamase' ),
						'text'         => __( 'Try a trade name like mason or electrician, or search by district instead.', 'kaamase' ),
						'button_label' => __( 'Browse all trades', 'kaamase' ),
						'button_url'   => home_url( '/trades/' ),
					)
				);

			} elseif ( 'kaamase_job' === $kaamase_post_type ) {

				kaamase_empty(
					array(
						'title'        => __( 'No jobs here yet', 'kaamase' ),
						'text'         => __( 'Nobody has posted work in this trade or district yet. Check another district, or tell an employer you know about Kaam Ase.', 'kaamase' ),
						'button_label' => __( 'See all jobs', 'kaamase' ),
						'button_url'   => home_url( '/jobs/' ),
					)
				);

			} elseif ( 'kaamase_worker' === $kaamase_post_type || 'kaamase_gang' === $kaamase_post_type ) {

				/*
				 * This one converts. A contractor who searched for a
				 * plumber in Wokha and found nobody is a contractor with
				 * a real need right now. Posting the job is a better next
				 * step for them than an apology, and it fills the supply
				 * gap that caused the empty screen in the first place.
				 */
				kaamase_empty(
					array(
						'title'        => __( 'No workers listed here yet', 'kaamase' ),
						'text'         => __( 'Kaam Ase is new and this district is still filling up. Post your job and workers nearby will see it.', 'kaamase' ),
						'button_label' => __( 'Post a job free', 'kaamase' ),
						'button_url'   => home_url( '/post-job/' ),
					)
				);

			} else {

				kaamase_empty(
					array(
						'title'        => __( 'Nothing here yet', 'kaamase' ),
						'text'         => __( 'There is nothing on this page at the moment.', 'kaamase' ),
						'button_label' => __( 'Go to home', 'kaamase' ),
						'button_url'   => home_url( '/' ),
					)
				);
			}
			?>
		</div>

	<?php endif; ?>

</div>

<?php
get_footer();