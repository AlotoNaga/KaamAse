<?php
/**
 * Page template.
 *
 * Every functional screen on this platform is a WordPress page holding a
 * shortcode: the dashboard, registration, posting a job, the saved list,
 * the report and grievance forms, the trade and district indexes. If a
 * page template does not call the_content(), none of those shortcodes
 * ever run and the entire platform renders as a heading with nothing
 * under it.
 *
 * That is why this file exists and why it is not optional.
 *
 * Width
 * -----
 * Prose pages read badly at full width, so they get the narrow container.
 * Pages holding a shortcode that renders a card grid need the room, so
 * they get the full one. Decided from the content rather than from a
 * page template setting, because the pages are created automatically on
 * activation and nobody is going to remember to set a template on each.
 *
 * Hiding the heading
 * ------------------
 * A page can ask for its title and photo to be out of the way, for the
 * screens that write their own heading into the content and would
 * otherwise show the same words twice.
 *
 * The title is hidden rather than dropped. It stays in the markup on the
 * screen reader class, because a page with no h1 gives a search engine
 * nothing to read the subject from and gives somebody using a screen
 * reader no idea where they have landed. The featured image is a
 * different matter and is simply not drawn: the head, the Open Graph
 * tags and any SEO plugin read it from the post record, not from here.
 *
 * @package Kaamase
 * @version 1.2.0
 * @since   1.1.0
 */

defined( 'ABSPATH' ) || exit;

get_header();

/*
 * Shortcodes that render their own grids and need the full container.
 * Everything else is prose or a single column form.
 */
$kaamase_wide_shortcodes = array(
	'kaamase_dashboard',
	'kaamase_saved',
	'kaamase_trade_index',
	'kaamase_district_index',
);

$kaamase_content = get_post_field( 'post_content', get_the_ID() );
$kaamase_wide    = false;

foreach ( $kaamase_wide_shortcodes as $kaamase_shortcode ) {
	if ( has_shortcode( (string) $kaamase_content, $kaamase_shortcode ) ) {
		$kaamase_wide = true;
		break;
	}
}

unset( $kaamase_wide_shortcodes, $kaamase_shortcode, $kaamase_content );

$kaamase_container = $kaamase_wide
	? 'ka-container'
	: 'ka-container ka-container--narrow';
?>

<div class="<?php echo esc_attr( $kaamase_container ); ?> ka-section">

	<?php
	while ( have_posts() ) :
		the_post();
		?>

		<article <?php post_class( 'ka-page' ); ?>>

			<?php
			/*
			 * The heading.
			 *
			 * Off entirely on the front page, which builds its own hero.
			 * Off visually on any page with the box ticked, where the h1
			 * moves onto the screen reader class rather than leaving the
			 * document. Everywhere else a page without a heading reads
			 * as content that failed to load.
			 */
			$kaamase_hide_head = function_exists( 'kaamase_hides_page_head' )
				&& kaamase_hides_page_head();

			if ( ! is_front_page() ) :
				?>
				<header class="<?php echo esc_attr( $kaamase_hide_head ? 'ka-sr' : 'ka-page-head ka-stack' ); ?>">
					<h1><?php the_title(); ?></h1>

					<?php if ( has_excerpt() ) : ?>
						<p class="ka-lead ka-soft"><?php echo esc_html( get_the_excerpt() ); ?></p>
					<?php endif; ?>
				</header>
			<?php endif; ?>

			<?php if ( has_post_thumbnail() && ! $kaamase_hide_head ) : ?>
				<figure class="ka-page__media ka-mt-6">
					<?php
					the_post_thumbnail(
						'kaamase-wide',
						array(
							'class'    => 'ka-page__image',
							'decoding' => 'async',
						)
					);
					?>
				</figure>
			<?php endif; ?>

			<?php
			/*
			 * The whole reason this template exists.
			 *
			 * The core plugin hooks the_content for the contact screen,
			 * the save button and the job posted notice, so filtering
			 * this out or echoing post_content raw would silently break
			 * three features at once.
			 */
			?>
			<div class="<?php echo esc_attr( $kaamase_hide_head ? 'ka-prose' : 'ka-prose ka-mt-6' ); ?>">
				<?php the_content(); ?>
			</div>

			<?php
			wp_link_pages(
				array(
					'before'   => '<nav class="ka-pagination ka-mt-6" aria-label="' . esc_attr__( 'Page sections', 'kaamase' ) . '"><ul class="ka-cluster"><li>',
					'after'    => '</li></ul></nav>',
					'separator' => '</li><li>',
				)
			);
			?>

		</article>

		<?php
	endwhile;
	?>

</div>

<?php
get_footer();