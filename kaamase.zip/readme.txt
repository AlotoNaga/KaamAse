=== Kaam Ase ===
Requires at least: 6.4
Tested up to: 6.8
Requires PHP: 8.1
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

Hiring platform theme for Kaam Ase. Built for Nagaland: mobile first,
works on slow connections, no external requests.

== Description ==

Presentation only. Every worker, job and rating lives in the Kaam Ase
Core plugin, so switching or rebuilding this theme later loses nothing.

Design decisions worth knowing:

* No web fonts. System stack only, which saves roughly 100KB and one
  round trip on every page load.
* One stylesheet, one script. On a high latency connection fewer
  requests beats smaller files.
* Nothing depends on JavaScript. The menu, the filters and every form
  work without it and are enhanced when it arrives.
* Minimum 48px touch targets throughout.
* Camera metadata, including GPS coordinates, is stripped from every
  uploaded photograph.

== Installation ==

1. Install and activate the Kaam Ase Core plugin FIRST.
2. Appearance, Themes, Add New, Upload Theme, choose this zip.
3. Activate.
4. Settings, Permalinks, Save.
5. Appearance, Menus: create menus and assign them to the Primary and
   Mobile locations. Until you do, the header shows a basic fallback.
6. Settings, Reading: set the front page to a static page.

== Changelog ==

= 1.1.0 =

The first release shipped with no page template and no single template,
and never called the_content() anywhere. Everything below follows from
that.

* Added page.php. Every functional screen on this platform is a page
  holding a shortcode: the dashboard, registration, posting a job, the
  saved list, the report and grievance forms, the trade and district
  indexes. Without a page template none of those shortcodes ever ran, so
  all fifteen rendered as a heading with nothing under it. The platform
  was not usable.
* Added single templates for workers, teams, jobs and employers. A worker
  profile was previously rendered as a card in a grid, so there was no
  profile page on a hiring platform. The core plugin also appends the
  contact screen, the save button and the job posted notice to the
  content, and none of those appeared either.
* Added single.php for ordinary posts.
* Wrote the missing component layer in the stylesheet. Around sixty
  classes were used in the markup with no styles behind them, including
  the whole front page hero, the worker and job cards, the mobile menu,
  pagination, the 404 page and the profile screens. The mobile menu
  showed its open and close icons at the same time and pushed the page
  down instead of opening over it.
* Long form content was rendering with no list markers and no indent, so
  the Safety, Privacy, Terms and How it works pages read as run on lines.
* District was printed from the stored slug, so every card and every
  profile on the site read dimapur rather than Dimapur.
* The select arrow was a filled triangle rather than a chevron, because
  the inline SVG had a fill on a path meant to be stroked.
* Added a sticky call bar to profile and job pages, so somebody who has
  read to the bottom does not have to scroll back up to act.

= 1.0.0 =
* First release.
