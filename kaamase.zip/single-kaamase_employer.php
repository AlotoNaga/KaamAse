<?php
/**
 * Single employer.
 *
 * Nobody browses a list of employers, which is why this post type has no
 * archive. But a worker deciding whether to travel for a job absolutely
 * wants to look one up first, and what they want to know is one thing:
 * does this person pay.
 *
 * So the ratings other workers left are the substance of this page, not a
 * footnote. The questions behind them were written for exactly this
 * moment: were you paid the amount that was agreed, were you paid when
 * they said, were you treated properly.
 *
 * Their open jobs sit below, because a worker who has decided this
 * employer is fine should be able to see what else they are hiring for
 * without going back to search.
 *
 * @package Kaamase
 * @version 1.1.0
 * @since   1.1.0
 */

defined( 'ABSPATH' ) || exit;

get_header();

while ( have_posts() ) :
	the_post();

	$kaamase_id      = get_the_ID();
	$kaamase_type    = (string) kaamase_field( $kaamase_id, 'employer_type' );
	$kaamase_contact = (string) kaamase_field( $kaamase_id, 'contact_name' );
	$kaamase_gst     = (string) kaamase_field( $kaamase_id, 'gst' );
	$kaamase_hires   = absint( kaamase_field( $kaamase_id, 'hires_made' ) );
	$kaamase_owner   = function_exists( 'kaamase_user_owns' ) && kaamase_user_owns( $kaamase_id );

	$kaamase_types = array(
		'individual' => __( 'An individual, building or fixing something', 'kaamase' ),
		'contractor' => __( 'A contractor', 'kaamase' ),
		'company'    => __( 'A registered company', 'kaamase' ),
	);
	?>

	<div class="ka-container ka-section ka-profile">

		<?php if ( $kaamase_owner ) : ?>
			<div class="ka-notice ka-notice--info ka-mb-4">
				<div>
					<span class="ka-notice__title"><?php esc_html_e( 'This is your page', 'kaamase' ); ?></span>
					<p><?php esc_html_e( 'This is what a worker sees before deciding whether to answer your job.', 'kaamase' ); ?></p>
					<a class="ka-btn ka-btn--outline ka-btn--sm ka-mt-4"
						href="<?php echo esc_url( add_query_arg( 'edit', $kaamase_id, home_url( '/dashboard/' ) ) ); ?>">
						<?php esc_html_e( 'Edit my details', 'kaamase' ); ?>
					</a>
				</div>
			</div>
		<?php endif; ?>

		<article <?php post_class( 'ka-profile__article' ); ?>>

			<header class="ka-card ka-card--pad-lg ka-profile__head">

				<div class="ka-profile__identity">
					<?php echo kaamase_avatar( $kaamase_id, 'kaamase-avatar-lg', 'ka-avatar--xl' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>

					<div class="ka-profile__titles">
						<h1 class="ka-profile__name"><?php the_title(); ?></h1>

						<?php echo kaamase_place( $kaamase_id ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>

						<div class="ka-cluster ka-mt-4">
							<?php
							echo kaamase_rating( // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
								kaamase_field( $kaamase_id, 'rating_average', 0 ),
								kaamase_field( $kaamase_id, 'rating_count', 0 )
							);
							echo kaamase_badges( $kaamase_id ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
							?>
						</div>
					</div>
				</div>

			</header>

			<section class="ka-facts ka-mt-6">

				<?php if ( isset( $kaamase_types[ $kaamase_type ] ) ) : ?>
					<div class="ka-fact">
						<p class="ka-fact__label"><?php esc_html_e( 'Type', 'kaamase' ); ?></p>
						<p class="ka-fact__value ka-text-base"><?php echo esc_html( $kaamase_types[ $kaamase_type ] ); ?></p>
					</div>
				<?php endif; ?>

				<?php if ( $kaamase_contact ) : ?>
					<div class="ka-fact">
						<p class="ka-fact__label"><?php esc_html_e( 'Ask for', 'kaamase' ); ?></p>
						<p class="ka-fact__value ka-text-base"><?php echo esc_html( $kaamase_contact ); ?></p>
					</div>
				<?php endif; ?>

				<?php if ( $kaamase_hires ) : ?>
					<div class="ka-fact">
						<p class="ka-fact__label"><?php esc_html_e( 'Workers hired here', 'kaamase' ); ?></p>
						<p class="ka-fact__value"><?php echo esc_html( number_format_i18n( $kaamase_hires ) ); ?></p>
					</div>
				<?php endif; ?>

				<?php if ( $kaamase_gst ) : ?>
					<div class="ka-fact">
						<p class="ka-fact__label"><?php esc_html_e( 'GST', 'kaamase' ); ?></p>
						<p class="ka-fact__value ka-text-base"><?php echo esc_html( $kaamase_gst ); ?></p>
					</div>
				<?php endif; ?>

			</section>

			<div class="ka-prose ka-mt-6">
				<?php the_content(); ?>
			</div>

		</article>

		<?php
		/* --------------------------------------------------------------
		 * Their open jobs.
		 * ------------------------------------------------------------ */
		$kaamase_jobs = new WP_Query(
			array(
				'post_type'           => 'kaamase_job',
				'author'              => (int) get_post_field( 'post_author', $kaamase_id ),
				'post_status'         => 'publish',
				'posts_per_page'      => 6,
				'ignore_sticky_posts' => true,
				'no_found_rows'       => true,
			)
		);

		if ( $kaamase_jobs->have_posts() ) :
			?>
			<section class="ka-mt-6">
				<h2><?php esc_html_e( 'Work they are hiring for', 'kaamase' ); ?></h2>

				<div class="ka-grid ka-grid--2 ka-mt-6">
					<?php
					while ( $kaamase_jobs->have_posts() ) :
						$kaamase_jobs->the_post();
						kaamase_job_card();
					endwhile;
					?>
				</div>
			</section>
			<?php
		endif;

		wp_reset_postdata();

		/* --------------------------------------------------------------
		 * What workers said. The substance of this page.
		 * ------------------------------------------------------------ */
		if ( function_exists( 'kaamase_rating_list' ) ) {
			echo kaamase_rating_list( $kaamase_id ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
		}

		if ( function_exists( 'kaamase_rating_form' ) ) {
			echo kaamase_rating_form( $kaamase_id ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
		}

		if ( $kaamase_owner && function_exists( 'kaamase_who_looked_me_up' ) ) {
			echo kaamase_who_looked_me_up( $kaamase_id ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
		}
		?>

	</div>

	<?php
endwhile;

get_footer();
