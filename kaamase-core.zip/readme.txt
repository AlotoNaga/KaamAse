=== Kaam Ase Core ===
Contributors: nagalandme
Requires at least: 6.4
Tested up to: 6.8
Requires PHP: 8.1
Stable tag: 1.3.0
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

The data layer for Kaam Ase. Workers, teams, employers, jobs, trades,
districts, ratings, reports and everything that must survive a theme change.

== Description ==

Kaam Ase Core owns every record on the platform. The theme decides how
things look; this plugin decides what exists.

Install this BEFORE activating the Kaam Ase theme. The theme checks for
this plugin and falls back to ordinary WordPress pages without it.

== Installation ==

1. Plugins, Add New, Upload Plugin, choose this zip, Install Now.
2. Activate.
3. Go to Settings, Permalinks and click Save. Nothing works with plain
   permalinks and this step is easy to forget.
4. Go to Kaam Ase, Settings and fill in the report email address.
5. Write the Privacy and Terms pages before letting anybody register.

== What activation creates ==

Fifteen pages, the 17 districts of Nagaland, around 30 trades grouped by
category, 21 languages, and three user roles: Worker, Employer and Field
Agent.

It creates nothing you have to clean up afterwards, and deleting the
plugin destroys no data unless you have explicitly switched that on in
Settings.

== Before you launch ==

* Ask your host to block PHP execution inside wp-content/uploads. Until
  that is done, an upload hole becomes a compromised server.
* Dial every emergency number on the Safety page. A helpline that rings
  out is worse than no helpline.
* Take a database backup and test that it restores.

== Changelog ==

= 1.3.0 =

Adds the API the Kaam Ase phone app talks to. Nothing on the website
changes behaviour.

* New REST namespace at /wp-json/kaamase/v1/ with token authentication.
  Tokens are stored as a salted HMAC, never in the clear, expire after
  sixty days of disuse, are capped at ten devices per account and are
  revoked when somebody changes their password.
* Sign in is rate limited: ten failures from one connection in fifteen
  minutes and it stops answering.
* The rules moved into includes/services.php so the website and the app
  enforce one identical set rather than two copies that drift. The wage
  floor, the urgent limit and the daily posting cap now exist in exactly
  one place each.
* Lookup by permalink slug, so a job link shared into a WhatsApp group
  opens in the app rather than nowhere.
* Push notifications through Expo. Off by default; switch on under
  Kaam Ase, Settings. Three are sent and a phone number is never in one.
* No response anywhere in the API carries a phone number except the
  contact endpoint, after the same gate, log and quota the website
  applies, and the caller's own number on their own account.

= 1.2.0 =

Fixed, and one of these was serious.

* Ratings could never be left by anybody. A rating requires a recorded
  hire, and nothing in the plugin ever recorded one, so the whole trust
  system was unreachable code. The dashboard now asks whether a hire
  happened two days after a number is looked up, which is what opens
  rating for both sides.
* Teams could not be created. The post type, the archive, the cards and
  the menu links all existed with no form behind them, so /teams/ was
  permanently empty. There is now a My team page.
* Employers could not close a filled job. Workers kept ringing about work
  that was already done.
* Switching to any other theme caused a fatal error. The plugin called
  nine display helpers that live in the theme. It now supplies its own
  fallbacks, which is what the architecture promised all along.
* For work inside a home, no worker could answer the job. The safety gate
  was applied to job posts as well as worker profiles, so a worker
  answering a cook's advert was told only verified employers may make
  contact. It now applies to worker profiles only, as intended.
* Editing a closed or filled job quietly put it back in front of workers.
* Ten mistyped job forms used up the day's posting allowance without a
  single job going up. The limit now counts jobs, not attempts.
* The report confirmation screen left an output buffer open, which could
  swallow later markup on the same page.
* A worker who had registered but not yet confirmed their email got a 404
  from the dashboard link to their own profile.

= 1.1.0 =
* Bootstrap now auto discovers feature files in includes/. Adding a
  feature no longer means editing the main plugin file.

= 1.0.0 =
* First release.
