<?php
/**
 * Uninstall.
 *
 * Runs when the plugin is DELETED from the plugins screen. Not on
 * deactivation, and not on update.
 *
 * The decision this file exists to get right
 * ------------------------------------------
 * By default it deletes nothing.
 *
 * That is unusual and it is deliberate. Most plugins treat deletion as
 * permission to wipe everything they created. Here, everything they
 * created is several hundred people's livelihood listings, their
 * photographs, their work history and their ratings. A plugin deletion
 * happens for all sorts of reasons that are not "destroy this data":
 * reinstalling a clean copy, moving host, a developer tidying up, a
 * mistaken click on the wrong row.
 *
 * So data removal requires somebody to have gone into the settings
 * beforehand and switched it on, in full knowledge of what it does. If
 * they have not, this file exits and the workers are still there when
 * the plugin is installed again.
 *
 * The cost of that choice is orphaned rows on a site that genuinely
 * finished with the platform. The cost of the other choice is a mistaken
 * click destroying data that cannot be recovered and that belongs to
 * people who never agreed to any of it. Orphaned rows are the cheaper
 * mistake.
 *
 * @package KaamaseCore
 * @version 1.0.0
 * @since   1.0.0
 */

// Only ever run through the real uninstall path.
if ( ! defined( 'WP_UNINSTALL_PLUGIN' ) ) {
	exit;
}


/**
 * Remove everything for one site.
 *
 * @since 1.0.0
 * @return void
 */
function kaamase_uninstall_site() {

	// The opt in. Without it, nothing below runs.
	if ( ! get_option( 'kaamase_delete_data_on_uninstall' ) ) {
		return;
	}

	global $wpdb;

	$prefix     = '_kaamase_';
	$post_types = array( 'kaamase_worker', 'kaamase_gang', 'kaamase_employer', 'kaamase_job', 'kaamase_report' );

	/* ----------------------------------------------------------------
	 * Posts and their photographs.
	 *
	 * Batched. On a site with a few thousand profiles, each carrying
	 * several images, deleting everything in one pass will hit the PHP
	 * time limit and leave the job half done with no way to resume. A
	 * batch of 200 at a time finishes or fails cleanly.
	 * ---------------------------------------------------------------- */

	foreach ( $post_types as $type ) {

		do {

			$ids = $wpdb->get_col( // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
				$wpdb->prepare(
					"SELECT ID FROM {$wpdb->posts} WHERE post_type = %s LIMIT 200",
					$type
				)
			);

			foreach ( (array) $ids as $id ) {

				// Photographs first, or they are left in the uploads folder forever.
				$attachments = get_children(
					array(
						'post_parent' => $id,
						'post_type'   => 'attachment',
						'numberposts' => -1,
						'fields'      => 'ids',
					)
				);

				foreach ( (array) $attachments as $attachment_id ) {
					wp_delete_attachment( $attachment_id, true );
				}

				$thumbnail = get_post_thumbnail_id( $id );

				if ( $thumbnail ) {
					wp_delete_attachment( $thumbnail, true );
				}

				wp_delete_post( $id, true );
			}
		} while ( ! empty( $ids ) );
	}

	/* ----------------------------------------------------------------
	 * Ratings. Stored as comments, so they need removing by type.
	 * ---------------------------------------------------------------- */

	$rating_ids = $wpdb->get_col( // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
		$wpdb->prepare(
			"SELECT comment_ID FROM {$wpdb->comments} WHERE comment_type = %s",
			'kaamase_rating'
		)
	);

	foreach ( (array) $rating_ids as $comment_id ) {
		wp_delete_comment( $comment_id, true );
	}

	/* ----------------------------------------------------------------
	 * Terms.
	 * ---------------------------------------------------------------- */

	foreach ( array( 'kaamase_trade', 'kaamase_district', 'kaamase_language' ) as $taxonomy ) {

		$terms = $wpdb->get_col( // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
			$wpdb->prepare(
				"SELECT t.term_id FROM {$wpdb->terms} t
				INNER JOIN {$wpdb->term_taxonomy} tt ON tt.term_id = t.term_id
				WHERE tt.taxonomy = %s",
				$taxonomy
			)
		);

		foreach ( (array) $terms as $term_id ) {
			wp_delete_term( (int) $term_id, $taxonomy );
		}
	}

	/* ----------------------------------------------------------------
	 * Roles.
	 *
	 * Users holding them are NOT deleted. Removing somebody's account
	 * because a plugin was uninstalled would be well beyond what this
	 * file has any business doing. They lose the role and become
	 * ordinary users with no capabilities, which an administrator can
	 * see and decide about.
	 * ---------------------------------------------------------------- */

	foreach ( array( 'kaamase_worker', 'kaamase_employer', 'kaamase_agent' ) as $role ) {
		remove_role( $role );
	}

	// Capabilities added to the built in roles.
	foreach ( array( 'administrator', 'editor' ) as $role_name ) {

		$role = get_role( $role_name );

		if ( ! $role ) {
			continue;
		}

		foreach ( array_keys( (array) $role->capabilities ) as $cap ) {
			if ( 0 === strpos( $cap, 'kaamase_' ) ) {
				$role->remove_cap( $cap );
			}
		}
	}

	/* ----------------------------------------------------------------
	 * Meta and options.
	 * ---------------------------------------------------------------- */

	$wpdb->query( // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
		$wpdb->prepare(
			"DELETE FROM {$wpdb->postmeta} WHERE meta_key LIKE %s",
			$wpdb->esc_like( $prefix ) . '%'
		)
	);

	$wpdb->query( // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
		$wpdb->prepare(
			"DELETE FROM {$wpdb->usermeta} WHERE meta_key LIKE %s",
			$wpdb->esc_like( 'kaamase_' ) . '%'
		)
	);

	$wpdb->query( // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
		$wpdb->prepare(
			"DELETE FROM {$wpdb->options} WHERE option_name LIKE %s OR option_name LIKE %s OR option_name LIKE %s",
			$wpdb->esc_like( 'kaamase_' ) . '%',
			$wpdb->esc_like( '_transient_kaamase_' ) . '%',
			$wpdb->esc_like( '_transient_timeout_kaamase_' ) . '%'
		)
	);

	/* ----------------------------------------------------------------
	 * Scheduled tasks.
	 * ---------------------------------------------------------------- */

	$timestamp = wp_next_scheduled( 'kaamase_daily' );

	while ( $timestamp ) {
		wp_unschedule_event( $timestamp, 'kaamase_daily' );
		$timestamp = wp_next_scheduled( 'kaamase_daily' );
	}

	/*
	 * Pages are deliberately left alone. They are ordinary WordPress
	 * pages that somebody has probably edited, and the shortcodes inside
	 * them simply stop rendering. Deleting content an editor wrote is not
	 * this file's business.
	 */

	flush_rewrite_rules();
}


/*
 * Run for every site on a network install, or just this one otherwise.
 */
if ( is_multisite() ) {

	$site_ids = get_sites(
		array(
			'fields' => 'ids',
			'number' => 500,
		)
	);

	foreach ( (array) $site_ids as $site_id ) {

		switch_to_blog( $site_id );
		kaamase_uninstall_site();
		restore_current_blog();
	}
} else {
	kaamase_uninstall_site();
}
