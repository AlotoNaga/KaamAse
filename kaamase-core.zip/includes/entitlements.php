<?php
/**
 * Limits and allowances.
 *
 * What a person is allowed to do in a day or a month, and how much of it
 * they have left.
 *
 * This is the layer money sits on, and it is deliberately in the core
 * plugin rather than in the payment one.
 *
 * The reason is the off switch. If limits lived in the payment plugin,
 * deactivating it would remove every limit on the site at once, and the
 * first thing that happens is somebody pulls four thousand phone numbers
 * in an afternoon. Limits are a safety feature that happens to also be
 * a meter. They belong with the platform.
 *
 * So this file knows about allowances and knows nothing about money.
 * Every allowance is a free number, editable on the Limits screen, plus
 * whatever a payment plugin adds through the kaamase_paid_allowance
 * filter. With no payment plugin installed the filter has no listeners,
 * the paid part is zero, and the site runs on the free numbers exactly
 * as it does today.
 *
 * What that buys you
 * ------------------
 * Charging can be switched off at any point without a person losing
 * access to anything they had. Their allowance drops back to the free
 * one. Nobody is locked out, no page breaks, and nothing needs a code
 * change to reverse. A payment system you cannot turn off is a payment
 * system you cannot experiment with.
 *
 * @package KaamaseCore
 * @version 1.2.0
 * @since   1.2.0
 */

defined( 'ABSPATH' ) || exit;


/* ==========================================================================
   1. WHAT IS MEASURED

   Adding a meter here is enough for it to appear on the Limits screen,
   be readable through the functions below, and be toppable up by a
   payment plugin. Nothing else needs editing.
   ========================================================================== */

if ( ! function_exists( 'kaamase_meters' ) ) {
	/**
	 * Every metered thing on the platform.
	 *
	 * @since 1.2.0
	 * @return array[] Keyed by meter, each with label, note, period and free default.
	 */
	function kaamase_meters() {

		$meters = array(

			'contact_reveals' => array(
				'label'  => __( 'Contact lookups a day', 'kaamase-core' ),
				'note'   => __( 'How many different workers one account can get the number of in a day. This is the main protection against somebody harvesting phone numbers, so keep it a real number rather than a large one.', 'kaamase-core' ),
				'period' => 'day',
				'free'   => 20,
			),

			'urgent_jobs' => array(
				'label'  => __( 'Urgent jobs at once', 'kaamase-core' ),
				'note'   => __( 'How many jobs one employer can have marked urgent at the same time. Urgent only means anything while it is rare. If everybody can mark everything urgent, the tag stops being read.', 'kaamase-core' ),
				'period' => 'concurrent',
				'free'   => 1,
			),

			'jobs_per_day' => array(
				'label'  => __( 'Jobs posted a day', 'kaamase-core' ),
				'note'   => __( 'How many jobs one employer can post in a day. This is here to stop the listings being flooded by one account rather than to ration honest use, so it should sit well above what a real employer would ever need.', 'kaamase-core' ),
				'period' => 'day',
				'free'   => 10,
			),
		);

		/**
		 * Filter the meters.
		 *
		 * @since 1.2.0
		 * @param array[] $meters Meters keyed by name.
		 */
		return (array) apply_filters( 'kaamase_meters', $meters );
	}
}

if ( ! function_exists( 'kaamase_meter_option' ) ) {
	/**
	 * Option name holding the free allowance for a meter.
	 *
	 * @since 1.2.0
	 * @param string $key Meter key.
	 * @return string
	 */
	function kaamase_meter_option( $key ) {
		return 'kaamase_free_' . sanitize_key( $key );
	}
}


/* ==========================================================================
   2. READING AN ALLOWANCE
   ========================================================================== */

if ( ! function_exists( 'kaamase_free_allowance' ) ) {
	/**
	 * The allowance everybody gets without paying.
	 *
	 * @since 1.2.0
	 * @param string $key Meter key.
	 * @return int
	 */
	function kaamase_free_allowance( $key ) {

		$meters = kaamase_meters();

		if ( ! isset( $meters[ $key ] ) ) {
			return 0;
		}

		$stored = get_option( kaamase_meter_option( $key ), null );

		if ( null === $stored || '' === $stored ) {
			return (int) $meters[ $key ]['free'];
		}

		return max( 0, (int) $stored );
	}
}

if ( ! function_exists( 'kaamase_allowance' ) ) {
	/**
	 * What this person is actually allowed, free plus anything paid for.
	 *
	 * @since 1.2.0
	 * @param string $key     Meter key.
	 * @param int    $user_id Optional. Defaults to the current user.
	 * @return int
	 */
	function kaamase_allowance( $key, $user_id = 0 ) {

		$user_id = $user_id ? (int) $user_id : get_current_user_id();
		$free    = kaamase_free_allowance( $key );

		/*
		 * Staff and field agents are not metered.
		 *
		 * A limit exists to stop harvesting. Somebody moderating reports
		 * needs to open twenty profiles in a row, and a field agent
		 * signing people up at a labour point works through more than
		 * that before lunch. Neither should be told to come back
		 * tomorrow, and neither is the threat the limit is for.
		 */
		if ( $user_id && ( user_can( $user_id, 'edit_others_kaamase_jobs' ) || user_can( $user_id, 'edit_others_kaamase_workers' ) ) ) {
			return PHP_INT_MAX;
		}

		/**
		 * Filter to add a paid allowance on top of the free one.
		 *
		 * This is the whole contract between this plugin and a payment
		 * plugin. A payment plugin returns however much extra this
		 * person has bought. Nothing here knows what a plan costs, what
		 * a subscription is, or whether one has expired: that is the
		 * payment plugin's business and it answers with a number.
		 *
		 * With no payment plugin active there are no listeners, the
		 * extra is zero, and everybody is on the free allowance.
		 *
		 * @since 1.2.0
		 * @param int    $extra   Additional allowance. Zero by default.
		 * @param string $key     Meter key.
		 * @param int    $user_id User being checked.
		 */
		$extra = (int) apply_filters( 'kaamase_paid_allowance', 0, $key, $user_id );

		return max( 0, $free + max( 0, $extra ) );
	}
}

if ( ! function_exists( 'kaamase_charging_is_on' ) ) {
	/**
	 * Whether anything on this site can currently be paid for.
	 *
	 * Answered by the payment plugin, not by this one. It decides false
	 * here so that a site with no payment plugin never offers somebody a
	 * way to pay that does not exist.
	 *
	 * Used for wording rather than for permission. A person who has run
	 * out is told to come back tomorrow when this is false, and offered
	 * a way through when it is true.
	 *
	 * @since 1.2.0
	 * @return bool
	 */
	function kaamase_charging_is_on() {

		/**
		 * Filter whether payments are live.
		 *
		 * @since 1.2.0
		 * @param bool $on Whether charging is switched on.
		 */
		return (bool) apply_filters( 'kaamase_charging_is_on', false );
	}
}

if ( ! function_exists( 'kaamase_limit_reached_message' ) ) {
	/**
	 * What to tell somebody who has run out.
	 *
	 * Two different sentences, and the difference matters. Telling a
	 * person to come back tomorrow when they could pay to carry on is a
	 * lost sale. Offering to sell something when there is no way to buy
	 * it is worse, so the wording follows whether payments are actually
	 * live rather than whether we intend them to be.
	 *
	 * @since 1.2.0
	 * @param string $key Meter key.
	 * @return string
	 */
	function kaamase_limit_reached_message( $key ) {

		$plain = array(
			'urgent_jobs'     => __( 'You already have an urgent job running. One at a time.', 'kaamase-core' ),
			'jobs_per_day'    => __( 'You have posted a lot of jobs today. Try again tomorrow.', 'kaamase-core' ),
			'contact_reveals' => __( 'You have looked up a lot of numbers today. Try again tomorrow.', 'kaamase-core' ),
		);

		$plain = $plain[ $key ] ?? $plain['contact_reveals'];

		if ( ! kaamase_charging_is_on() ) {
			return $plain;
		}

		$upgrade = array(
			'urgent_jobs'     => __( 'You have used your urgent jobs. You can get more, or wait until one of the current ones closes.', 'kaamase-core' ),
			'jobs_per_day'    => __( 'You have posted all the jobs this account can post today. You can get more now, or wait until tomorrow.', 'kaamase-core' ),
			'contact_reveals' => __( 'You have used today\'s contact lookups. You can get more now, or wait until tomorrow.', 'kaamase-core' ),
		);

		$upgrade = $upgrade[ $key ] ?? $upgrade['contact_reveals'];

		/**
		 * Filter the message shown when an allowance runs out.
		 *
		 * A payment plugin can append a link to whatever it sells.
		 *
		 * @since 1.2.0
		 * @param string $message The message.
		 * @param string $key     Meter key.
		 */
		return (string) apply_filters( 'kaamase_limit_reached_message', $upgrade, $key );
	}
}


/* ==========================================================================
   3. WIRING THE EXISTING LIMITS THROUGH

   Both of these already had filters, which is why nothing else in the
   plugin needed editing for any of this.
   ========================================================================== */

if ( ! function_exists( 'kaamase_meter_contact_limit' ) ) {
	/**
	 * Use the allowance for contact lookups.
	 *
	 * @since 1.2.0
	 * @param int $limit   Existing limit.
	 * @param int $user_id User being checked.
	 * @return int
	 */
	function kaamase_meter_contact_limit( $limit, $user_id ) {

		unset( $limit );

		/*
		 * The number on the Limits screen is the number people get.
		 *
		 * There was a multiplier here that gave any account with a
		 * confirmed email five times the setting, which meant setting
		 * the field to 20 handed out 100 and the screen quietly lied
		 * about it. It came from misreading the original rule: the
		 * higher figure was never for verified accounts, it was for
		 * field agents, who register workers in person and legitimately
		 * look up dozens in a morning.
		 *
		 * A settings field that does not mean what it says is worse
		 * than no settings field, because it is only discovered by
		 * somebody counting.
		 */
		return kaamase_allowance( 'contact_reveals', $user_id );
	}
}
add_filter( 'kaamase_contact_daily_limit', 'kaamase_meter_contact_limit', 20, 2 );


/* ==========================================================================
   4. THE LIMITS SCREEN

   Its own page rather than more rows on the settings screen, because
   these numbers get changed on a different rhythm from a support email
   address, and because a payment plugin will want to add to this page
   rather than to a general one.
   ========================================================================== */

if ( ! function_exists( 'kaamase_limits_menu' ) ) {
	/**
	 * Add the Limits screen under Kaam Ase.
	 *
	 * @since 1.2.0
	 * @return void
	 */
	function kaamase_limits_menu() {

		add_submenu_page(
			'kaamase',
			__( 'Limits', 'kaamase-core' ),
			__( 'Limits', 'kaamase-core' ),
			'manage_options',
			'kaamase-limits',
			'kaamase_limits_page'
		);
	}
}
add_action( 'admin_menu', 'kaamase_limits_menu', 20 );

if ( ! function_exists( 'kaamase_register_limit_settings' ) ) {
	/**
	 * Register a setting for each meter.
	 *
	 * @since 1.2.0
	 * @return void
	 */
	function kaamase_register_limit_settings() {

		foreach ( kaamase_meters() as $key => $meter ) {

			register_setting(
				'kaamase_limits',
				kaamase_meter_option( $key ),
				array(
					'type'              => 'integer',
					'sanitize_callback' => 'absint',
					'default'           => (int) $meter['free'],
				)
			);
		}
	}
}
add_action( 'admin_init', 'kaamase_register_limit_settings' );

if ( ! function_exists( 'kaamase_limits_page' ) ) {
	/**
	 * Render the Limits screen.
	 *
	 * @since 1.2.0
	 * @return void
	 */
	function kaamase_limits_page() {

		if ( ! current_user_can( 'manage_options' ) ) {
			return;
		}

		$charging = kaamase_charging_is_on();
		?>
		<div class="wrap">

			<h1><?php esc_html_e( 'Limits', 'kaamase-core' ); ?></h1>

			<p class="description" style="max-width:40em">
				<?php esc_html_e( 'What everybody gets for free. These apply whether or not anything is being charged for, because they are what stops one account from taking more out of the platform than it puts in.', 'kaamase-core' ); ?>
			</p>

			<?php if ( $charging ) : ?>
				<div class="notice notice-info inline">
					<p><?php esc_html_e( 'Payments are switched on. People can buy more than the numbers below. Prices are set on the payments screen, not here.', 'kaamase-core' ); ?></p>
				</div>
			<?php else : ?>
				<div class="notice notice-info inline">
					<p><?php esc_html_e( 'Nothing is being charged for right now, so these numbers are the whole story. Somebody who runs out is told to come back tomorrow.', 'kaamase-core' ); ?></p>
				</div>
			<?php endif; ?>

			<form method="post" action="options.php">

				<?php settings_fields( 'kaamase_limits' ); ?>

				<table class="form-table" role="presentation">

					<?php foreach ( kaamase_meters() as $key => $meter ) : ?>
						<?php $option = kaamase_meter_option( $key ); ?>
						<tr>
							<th scope="row">
								<label for="<?php echo esc_attr( $option ); ?>">
									<?php echo esc_html( $meter['label'] ); ?>
								</label>
							</th>
							<td>
								<input type="number"
									min="0"
									step="1"
									class="small-text"
									id="<?php echo esc_attr( $option ); ?>"
									name="<?php echo esc_attr( $option ); ?>"
									value="<?php echo esc_attr( (string) kaamase_free_allowance( $key ) ); ?>">

								<p class="description" style="max-width:40em">
									<?php echo esc_html( $meter['note'] ); ?>
								</p>
							</td>
						</tr>
					<?php endforeach; ?>

				</table>

				<?php submit_button(); ?>

			</form>

			<h2><?php esc_html_e( 'A note on lowering these', 'kaamase-core' ); ?></h2>

			<p class="description" style="max-width:40em">
				<?php esc_html_e( 'Dropping a free allowance to make room for something to sell is the most tempting mistake here, and the one that does lasting damage. Somebody who could do their work yesterday and cannot today does not read it as a new product, they read it as the platform turning on them. Raise what paying gets you rather than lowering what free gets you.', 'kaamase-core' ); ?>
			</p>

		</div>
		<?php
	}
}