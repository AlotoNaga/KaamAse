<?php
/**
 * Theme compatibility.
 *
 * The promise this file keeps
 * --------------------------
 * The main plugin file says it plainly: themes are clothes, this is the
 * body, and switching a theme must never make a single record on the
 * platform unreachable.
 *
 * That promise was not being kept. Nine display helpers live in the Kaam
 * Ase theme, and the plugin called all nine of them directly:
 *
 *   kaamase_field, kaamase_avatar, kaamase_place, kaamase_rating,
 *   kaamase_empty, kaamase_contact_button, kaamase_worker_card,
 *   kaamase_gang_card, kaamase_job_card
 *
 * Switch to any other theme and the dashboard, the saved page and every
 * ratings list fatal on an undefined function. Not degrade. Fatal. The
 * exact failure the architecture was written to prevent.
 *
 * So this file supplies a plain fallback for each one.
 *
 * Why it runs on after_setup_theme
 * --------------------------------
 * Plugins load before a theme's functions.php, so defining these at
 * plugin load time would win the race and permanently override the
 * theme's much better versions. By after_setup_theme the theme has
 * already declared whatever it declares, so every function_exists check
 * below is asking the right question: is anybody already providing this.
 *
 * Nothing here tries to be pretty. It is the difference between a plain
 * page and a white screen.
 *
 * @package KaamaseCore
 * @version 1.2.0
 * @since   1.2.0
 */

defined( 'ABSPATH' ) || exit;

/**
 * Define fallbacks for any display helper the active theme does not.
 *
 * @since 1.2.0
 * @return void
 */
function kaamase_define_display_fallbacks() {

	if ( ! function_exists( 'kaamase_field' ) ) {
		/**
		 * Read a Kaam Ase field.
		 *
		 * Applies the same filter the theme's version does, which is not
		 * cosmetic: the privacy rule in fields.php is enforced on that
		 * filter. A fallback that skipped it would start printing phone
		 * numbers the moment somebody switched theme.
		 *
		 * @since 1.2.0
		 * @param int    $post_id Post ID.
		 * @param string $key     Field key without the prefix.
		 * @param mixed  $default Value returned when the field is empty.
		 * @return mixed Field value.
		 */
		function kaamase_field( $post_id, $key, $default = '' ) {

			$post_id = absint( $post_id );
			$value   = $post_id ? get_post_meta( $post_id, KAAMASE_META_PREFIX . $key, true ) : '';

			if ( '' === $value || null === $value || array() === $value ) {
				$value = $default;
			}

			/** This filter is documented in the Kaam Ase theme. */
			return apply_filters( 'kaamase_field', $value, $post_id, $key, $default );
		}
	}

	if ( ! function_exists( 'kaamase_avatar' ) ) {
		/**
		 * Profile photograph, or nothing.
		 *
		 * @since 1.2.0
		 * @param int    $post_id Post ID.
		 * @param string $size    Image size.
		 * @param string $class   Extra class.
		 * @return string Markup.
		 */
		function kaamase_avatar( $post_id, $size = 'thumbnail', $class = '' ) {

			$post_id = absint( $post_id );

			if ( ! $post_id || ! has_post_thumbnail( $post_id ) ) {
				return '';
			}

			return get_the_post_thumbnail(
				$post_id,
				$size,
				array(
					'class'   => trim( 'ka-avatar ' . $class ),
					'loading' => 'lazy',
					'alt'     => '',
				)
			);
		}
	}

	if ( ! function_exists( 'kaamase_place' ) ) {
		/**
		 * Town and district on one line.
		 *
		 * @since 1.2.0
		 * @param int $post_id Post ID.
		 * @return string Markup.
		 */
		function kaamase_place( $post_id ) {

			$town     = (string) kaamase_field( $post_id, 'town' );
			$district = (string) kaamase_field( $post_id, 'district' );

			if ( $district && function_exists( 'kaamase_district_name' ) ) {
				$name     = kaamase_district_name( $district );
				$district = $name ? $name : ucwords( str_replace( '-', ' ', $district ) );
			}

			$parts = array_filter( array( $town, $district ) );

			if ( empty( $parts ) ) {
				return '';
			}

			return '<span class="ka-place ka-small ka-mute">' . esc_html( implode( ', ', $parts ) ) . '</span>';
		}
	}

	if ( ! function_exists( 'kaamase_rating' ) ) {
		/**
		 * Score and count, or a New badge.
		 *
		 * @since 1.2.0
		 * @param float $score Average out of five.
		 * @param int   $count Number of ratings.
		 * @return string Markup.
		 */
		function kaamase_rating( $score, $count ) {

			$score = (float) $score;
			$count = absint( $count );

			if ( $count < 1 || $score <= 0 ) {
				return '<span class="ka-badge ka-badge--new">' . esc_html__( 'New', 'kaamase-core' ) . '</span>';
			}

			return sprintf(
				'<span class="ka-rating"><span class="ka-rating__star" aria-hidden="true">&#9733;</span><span>%1$s</span> <span class="ka-rating__count">(%2$s)</span></span>',
				esc_html( number_format_i18n( $score, 1 ) ),
				esc_html( number_format_i18n( $count ) )
			);
		}
	}

	if ( ! function_exists( 'kaamase_empty' ) ) {
		/**
		 * Empty state with an optional way forward.
		 *
		 * @since 1.2.0
		 * @param array $args title, text, button_label, button_url.
		 * @return void
		 */
		function kaamase_empty( $args = array() ) {

			$args = wp_parse_args(
				$args,
				array(
					'title'        => __( 'Nothing here yet', 'kaamase-core' ),
					'text'         => '',
					'button_label' => '',
					'button_url'   => '',
				)
			);

			echo '<div class="ka-empty">';
			echo '<h2 class="ka-empty__title">' . esc_html( $args['title'] ) . '</h2>';

			if ( $args['text'] ) {
				echo '<p class="ka-empty__text">' . esc_html( $args['text'] ) . '</p>';
			}

			if ( $args['button_label'] && $args['button_url'] ) {
				printf(
					'<a class="ka-btn ka-btn--primary" href="%1$s">%2$s</a>',
					esc_url( $args['button_url'] ),
					esc_html( $args['button_label'] )
				);
			}

			echo '</div>';
		}
	}

	if ( ! function_exists( 'kaamase_contact_button' ) ) {
		/**
		 * Contact button.
		 *
		 * Never renders a number. Goes through the same filter the theme
		 * uses, which contact.php points at the gated contact screen.
		 *
		 * @since 1.2.0
		 * @param int    $post_id Post ID.
		 * @param string $label   Button label.
		 * @return string Markup.
		 */
		function kaamase_contact_button( $post_id, $label = '' ) {

			$post_id = absint( $post_id );
			$label   = $label ? $label : __( 'Call', 'kaamase-core' );

			if ( ! is_user_logged_in() ) {
				return sprintf(
					'<a class="ka-btn ka-btn--outline ka-btn--sm" href="%1$s">%2$s</a>',
					esc_url( wp_login_url( get_permalink( $post_id ) ) ),
					esc_html__( 'Sign in to contact', 'kaamase-core' )
				);
			}

			/** This filter is documented in the Kaam Ase theme. */
			$url = apply_filters( 'kaamase_contact_url', get_permalink( $post_id ), $post_id );

			return sprintf(
				'<a class="ka-btn ka-btn--action ka-btn--sm" href="%1$s" rel="nofollow">%2$s</a>',
				esc_url( $url ),
				esc_html( $label )
			);
		}
	}

	/*
	 * Cards.
	 *
	 * One shared renderer behind all three. A theme that wants them to
	 * look like anything in particular defines its own, which is exactly
	 * what the Kaam Ase theme does.
	 */
	if ( ! function_exists( 'kaamase_fallback_card' ) ) {
		/**
		 * A plain card for any Kaam Ase record.
		 *
		 * @since 1.2.0
		 * @param int $post_id Post ID.
		 * @return void
		 */
		function kaamase_fallback_card( $post_id ) {

			$post_id = $post_id ? absint( $post_id ) : get_the_ID();

			if ( ! $post_id ) {
				return;
			}

			echo '<article class="ka-card ka-card--link">';

			printf(
				'<h3><a href="%1$s">%2$s</a></h3>',
				esc_url( (string) get_permalink( $post_id ) ),
				esc_html( get_the_title( $post_id ) )
			);

			echo kaamase_place( $post_id ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped

			echo '<div class="ka-card__foot ka-cluster ka-cluster--between">';

			echo kaamase_rating( // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
				kaamase_field( $post_id, 'rating_average', 0 ),
				kaamase_field( $post_id, 'rating_count', 0 )
			);

			echo kaamase_contact_button( $post_id ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped

			echo '</div></article>';
		}
	}

	if ( ! function_exists( 'kaamase_worker_card' ) ) {
		/**
		 * Worker card fallback.
		 *
		 * @since 1.2.0
		 * @param int $post_id Post ID.
		 * @return void
		 */
		function kaamase_worker_card( $post_id = 0 ) {
			kaamase_fallback_card( $post_id );
		}
	}

	if ( ! function_exists( 'kaamase_gang_card' ) ) {
		/**
		 * Team card fallback.
		 *
		 * @since 1.2.0
		 * @param int $post_id Post ID.
		 * @return void
		 */
		function kaamase_gang_card( $post_id = 0 ) {
			kaamase_fallback_card( $post_id );
		}
	}

	if ( ! function_exists( 'kaamase_job_card' ) ) {
		/**
		 * Job card fallback.
		 *
		 * @since 1.2.0
		 * @param int $post_id Post ID.
		 * @return void
		 */
		function kaamase_job_card( $post_id = 0 ) {
			kaamase_fallback_card( $post_id );
		}
	}
}
add_action( 'after_setup_theme', 'kaamase_define_display_fallbacks', 99 );
