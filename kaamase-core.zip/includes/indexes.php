<?php
/**
 * Index pages.
 *
 * The all trades and all districts hub pages, and the wiring that puts
 * the filter bar and result count onto every trade and district archive.
 *
 * Why these pages matter more than they look
 * ------------------------------------------
 * They are the only pages on the platform whose job is to be found by
 * somebody who has never heard of Kaam Ase. A person types electrician
 * in Dimapur into a search engine. The page that should come back is the
 * electrician archive filtered to Dimapur. These hubs are what makes
 * those pages reachable, both by a search engine crawling the site and
 * by a person browsing rather than searching.
 *
 * The rule about empty combinations
 * ---------------------------------
 * There are seventeen districts and around thirty trades, so five
 * hundred possible combinations. Linking to all of them would create
 * five hundred pages, most of them empty, and a site made mostly of
 * empty pages is a site a search engine stops trusting.
 *
 * So the cross links are generated only where there is something to
 * find. A combination with no workers is not linked. The page count
 * grows as the platform fills up, which is the correct way round.
 *
 * @package KaamaseCore
 * @version 1.0.0
 * @since   1.0.0
 */

defined( 'ABSPATH' ) || exit;


/* ==========================================================================
   1. COUNTING

   Every number on these pages is a query. Seventeen districts times four
   post types on every page load would be slow on the hosting this runs
   on, so everything here is counted once and cached.
   ========================================================================== */

if ( ! function_exists( 'kaamase_term_counts' ) ) {
	/**
	 * How many published items sit under each term of a taxonomy.
	 *
	 * Counted in one query per post type rather than one per term.
	 *
	 * @since 1.0.0
	 * @param string $taxonomy  Taxonomy name.
	 * @param string $post_type Post type to count.
	 * @return int[] Counts keyed by term slug.
	 */
	function kaamase_term_counts( $taxonomy, $post_type ) {

		$key    = 'kaamase_counts_' . md5( $taxonomy . $post_type );
		$cached = get_transient( $key );

		if ( is_array( $cached ) ) {
			return $cached;
		}

		global $wpdb;

		$rows = $wpdb->get_results( // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
			$wpdb->prepare(
				"SELECT t.slug AS slug, COUNT(DISTINCT p.ID) AS total
				FROM {$wpdb->terms} t
				INNER JOIN {$wpdb->term_taxonomy} tt ON tt.term_id = t.term_id
				INNER JOIN {$wpdb->term_relationships} tr ON tr.term_taxonomy_id = tt.term_taxonomy_id
				INNER JOIN {$wpdb->posts} p ON p.ID = tr.object_id
				WHERE tt.taxonomy = %s
				AND p.post_type = %s
				AND p.post_status = 'publish'
				GROUP BY t.slug",
				$taxonomy,
				$post_type
			)
		);

		$counts = array();

		foreach ( (array) $rows as $row ) {
			$counts[ $row->slug ] = (int) $row->total;
		}

		set_transient( $key, $counts, 6 * HOUR_IN_SECONDS );

		return $counts;
	}
}

if ( ! function_exists( 'kaamase_clear_count_cache' ) ) {
	/**
	 * Drop the cached counts when content changes.
	 *
	 * @since 1.0.0
	 * @return void
	 */
	function kaamase_clear_count_cache() {

		foreach ( array( 'kaamase_trade', 'kaamase_district' ) as $taxonomy ) {
			foreach ( kaamase_post_types() as $type ) {
				delete_transient( 'kaamase_counts_' . md5( $taxonomy . $type ) );
			}
		}
	}
}
add_action( 'save_post_kaamase_worker', 'kaamase_clear_count_cache' );
add_action( 'save_post_kaamase_gang', 'kaamase_clear_count_cache' );
add_action( 'save_post_kaamase_job', 'kaamase_clear_count_cache' );
add_action( 'kaamase_daily', 'kaamase_clear_count_cache' );


/* ==========================================================================
   2. ALL TRADES
   ========================================================================== */

if ( ! function_exists( 'kaamase_trade_index_shortcode' ) ) {
	/**
	 * Render the all trades page.
	 *
	 * Grouped by category, with counts. Trades nobody has registered for
	 * are still listed, because a person looking for a tile worker needs
	 * to see that the trade exists here even when nobody has signed up
	 * yet, and the page tells them what to do about it.
	 *
	 * @since 1.0.0
	 * @return string Markup.
	 */
	function kaamase_trade_index_shortcode() {

		$workers = kaamase_term_counts( 'kaamase_trade', 'kaamase_worker' );
		$jobs    = kaamase_term_counts( 'kaamase_trade', 'kaamase_job' );

		ob_start();
		?>
		<div class="ka-stack--lg">

			<p class="ka-lead ka-soft">
				<?php esc_html_e( 'Every kind of work on Kaam Ase. Tap one to see who is available across Nagaland.', 'kaamase-core' ); ?>
			</p>

			<?php foreach ( kaamase_trade_choices() as $group => $trades ) : ?>

				<section>
					<h2><?php echo esc_html( $group ); ?></h2>

					<ul class="ka-grid ka-grid--2 ka-grid--3 ka-mt-4">
						<?php
						foreach ( $trades as $slug => $name ) :

							$link = get_term_link( $slug, 'kaamase_trade' );

							if ( is_wp_error( $link ) ) {
								continue;
							}

							$worker_count = isset( $workers[ $slug ] ) ? (int) $workers[ $slug ] : 0;
							$job_count    = isset( $jobs[ $slug ] ) ? (int) $jobs[ $slug ] : 0;
							?>
							<li class="ka-card ka-card--link ka-card--flat">
								<a href="<?php echo esc_url( $link ); ?>">
									<strong><?php echo esc_html( $name ); ?></strong>
								</a>

								<p class="ka-small ka-mute">
									<?php if ( $worker_count ) : ?>
										<?php
										printf(
											esc_html(
												/* translators: %s: number of workers */
												_n( '%s available', '%s available', $worker_count, 'kaamase-core' )
											),
											esc_html( number_format_i18n( $worker_count ) )
										);
										?>
									<?php else : ?>
										<?php esc_html_e( 'Nobody yet', 'kaamase-core' ); ?>
									<?php endif; ?>

									<?php if ( $job_count ) : ?>
										<span aria-hidden="true">&middot;</span>
										<?php
										printf(
											esc_html(
												/* translators: %s: number of open jobs */
												_n( '%s job open', '%s jobs open', $job_count, 'kaamase-core' )
											),
											esc_html( number_format_i18n( $job_count ) )
										);
										?>
									<?php endif; ?>
								</p>
							</li>
						<?php endforeach; ?>
					</ul>
				</section>

			<?php endforeach; ?>

			<div class="ka-card ka-card--pad-lg">
				<h2><?php esc_html_e( 'Your trade not listed?', 'kaamase-core' ); ?></h2>
				<p class="ka-soft ka-mt-4">
					<?php esc_html_e( 'Tell us what you do and we will add it. This list is meant to cover the work people actually do in Nagaland, not a list somebody wrote in an office.', 'kaamase-core' ); ?>
				</p>
				<a class="ka-btn ka-btn--outline ka-mt-4" href="<?php echo esc_url( kaamase_page_url( 'contact' ) ); ?>">
					<?php esc_html_e( 'Tell us', 'kaamase-core' ); ?>
				</a>
			</div>

		</div>
		<?php

		return (string) ob_get_clean();
	}
}
add_shortcode( 'kaamase_trade_index', 'kaamase_trade_index_shortcode' );


/* ==========================================================================
   3. ALL DISTRICTS
   ========================================================================== */

if ( ! function_exists( 'kaamase_district_index_shortcode' ) ) {
	/**
	 * Render the all districts page.
	 *
	 * Districts with nothing in them are shown honestly rather than
	 * hidden. A person from Noklak who finds their district missing
	 * concludes the platform is not for them. A person who finds it
	 * listed with nobody in it yet, and a button saying be the first, is
	 * being invited.
	 *
	 * @since 1.0.0
	 * @return string Markup.
	 */
	function kaamase_district_index_shortcode() {

		$workers = kaamase_term_counts( 'kaamase_district', 'kaamase_worker' );
		$jobs    = kaamase_term_counts( 'kaamase_district', 'kaamase_job' );

		$rows = array();

		foreach ( kaamase_districts() as $slug => $district ) {

			$link = get_term_link( $slug, 'kaamase_district' );

			$rows[] = array(
				'slug'    => $slug,
				'name'    => $district['name'],
				'link'    => is_wp_error( $link ) ? '' : $link,
				'workers' => isset( $workers[ $slug ] ) ? (int) $workers[ $slug ] : 0,
				'jobs'    => isset( $jobs[ $slug ] ) ? (int) $jobs[ $slug ] : 0,
			);
		}

		// Busiest first, so the page opens on the places where it works.
		usort(
			$rows,
			static function ( $a, $b ) {
				return ( $b['workers'] + $b['jobs'] ) <=> ( $a['workers'] + $a['jobs'] );
			}
		);

		ob_start();
		?>
		<div class="ka-stack--lg">

			<p class="ka-lead ka-soft">
				<?php esc_html_e( 'All seventeen districts of Nagaland. Some are busy, some are just starting.', 'kaamase-core' ); ?>
			</p>

			<ul class="ka-grid ka-grid--2 ka-grid--3">
				<?php foreach ( $rows as $row ) : ?>
					<li class="ka-card ka-card--link">

						<h2 class="ka-text-lg">
							<?php if ( $row['link'] ) : ?>
								<a href="<?php echo esc_url( $row['link'] ); ?>"><?php echo esc_html( $row['name'] ); ?></a>
							<?php else : ?>
								<?php echo esc_html( $row['name'] ); ?>
							<?php endif; ?>
						</h2>

						<?php if ( $row['workers'] || $row['jobs'] ) : ?>

							<p class="ka-small ka-soft ka-mt-4">
								<?php
								printf(
									esc_html(
										/* translators: %s: number of workers */
										_n( '%s worker', '%s workers', $row['workers'], 'kaamase-core' )
									),
									esc_html( number_format_i18n( $row['workers'] ) )
								);
								?>
								<span aria-hidden="true">&middot;</span>
								<?php
								printf(
									esc_html(
										/* translators: %s: number of open jobs */
										_n( '%s job open', '%s jobs open', $row['jobs'], 'kaamase-core' )
									),
									esc_html( number_format_i18n( $row['jobs'] ) )
								);
								?>
							</p>

							<?php echo kaamase_top_trades_in( $row['slug'] ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>

						<?php else : ?>

							<p class="ka-small ka-mute ka-mt-4">
								<?php esc_html_e( 'Nobody registered here yet.', 'kaamase-core' ); ?>
							</p>

							<a class="ka-btn ka-btn--outline ka-btn--sm ka-mt-4"
								href="<?php echo esc_url( add_query_arg( 'type', 'worker', kaamase_page_url( 'register' ) ) ); ?>">
								<?php esc_html_e( 'Be the first', 'kaamase-core' ); ?>
							</a>

						<?php endif; ?>

					</li>
				<?php endforeach; ?>
			</ul>

		</div>
		<?php

		return (string) ob_get_clean();
	}
}
add_shortcode( 'kaamase_district_index', 'kaamase_district_index_shortcode' );

if ( ! function_exists( 'kaamase_top_trades_in' ) ) {
	/**
	 * The trades that actually have people in a district.
	 *
	 * These are the cross links. Only combinations with something behind
	 * them, for the reason at the top of this file.
	 *
	 * @since 1.0.0
	 * @param string $district District slug.
	 * @param int    $limit    How many to show.
	 * @return string Markup.
	 */
	function kaamase_top_trades_in( $district, $limit = 4 ) {

		$key    = 'kaamase_top_' . md5( $district );
		$cached = get_transient( $key );

		if ( false !== $cached ) {
			return (string) $cached;
		}

		global $wpdb;

		$rows = $wpdb->get_results( // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
			$wpdb->prepare(
				"SELECT trade.slug AS slug, trade.name AS name, COUNT(DISTINCT p.ID) AS total
				FROM {$wpdb->posts} p
				INNER JOIN {$wpdb->term_relationships} tr_d ON tr_d.object_id = p.ID
				INNER JOIN {$wpdb->term_taxonomy} tt_d ON tt_d.term_taxonomy_id = tr_d.term_taxonomy_id AND tt_d.taxonomy = 'kaamase_district'
				INNER JOIN {$wpdb->terms} district ON district.term_id = tt_d.term_id AND district.slug = %s
				INNER JOIN {$wpdb->term_relationships} tr_t ON tr_t.object_id = p.ID
				INNER JOIN {$wpdb->term_taxonomy} tt_t ON tt_t.term_taxonomy_id = tr_t.term_taxonomy_id AND tt_t.taxonomy = 'kaamase_trade'
				INNER JOIN {$wpdb->terms} trade ON trade.term_id = tt_t.term_id
				WHERE p.post_type = 'kaamase_worker'
				AND p.post_status = 'publish'
				AND tt_t.parent != 0
				GROUP BY trade.slug, trade.name
				ORDER BY total DESC
				LIMIT %d",
				$district,
				absint( $limit )
			)
		);

		if ( empty( $rows ) ) {
			set_transient( $key, '', HOUR_IN_SECONDS );
			return '';
		}

		$out = '<ul class="ka-cluster ka-mt-4">';

		foreach ( $rows as $row ) {

			$link = get_term_link( $row->slug, 'kaamase_trade' );

			if ( is_wp_error( $link ) ) {
				continue;
			}

			$out .= sprintf(
				'<li><a class="ka-chip" href="%1$s">%2$s <span class="ka-mute">%3$s</span></a></li>',
				esc_url( add_query_arg( 'kaamase_district', $district, $link ) ),
				esc_html( $row->name ),
				esc_html( number_format_i18n( $row->total ) )
			);
		}

		$out .= '</ul>';

		set_transient( $key, $out, 6 * HOUR_IN_SECONDS );

		return $out;
	}
}


/* ==========================================================================
   4. ARCHIVE WIRING

   queries.php built a filter bar and a result summary and nothing was
   calling them. This puts both onto every trade and district archive
   through the archive description, so the theme needs no changes.
   ========================================================================== */

if ( ! function_exists( 'kaamase_archive_intro' ) ) {
	/**
	 * Add the summary and filters to a Kaam Ase archive.
	 *
	 * @since 1.0.0
	 * @param string $description Existing archive description.
	 * @return string Filtered description.
	 */
	function kaamase_archive_intro( $description ) {

		if ( is_admin() || ! is_main_query() ) {
			return $description;
		}

		$is_taxonomy = is_tax( array( 'kaamase_trade', 'kaamase_district' ) );
		$is_archive  = is_post_type_archive( array( 'kaamase_worker', 'kaamase_gang', 'kaamase_job' ) );

		if ( ! $is_taxonomy && ! $is_archive ) {
			return $description;
		}

		$type = get_query_var( 'post_type' );
		$type = is_array( $type ) ? reset( $type ) : (string) $type;
		$type = $type ? $type : 'kaamase_worker';

		$out = '';

		if ( $description ) {
			$out .= '<div class="ka-soft">' . wp_kses_post( $description ) . '</div>';
		}

		$out .= '<p class="ka-lead">' . esc_html( kaamase_result_summary() ) . '</p>';
		$out .= kaamase_filter_bar( $type );

		// On a trade archive, offer the districts that actually have people.
		if ( is_tax( 'kaamase_trade' ) ) {
			$out .= kaamase_districts_for_trade( get_queried_object() );
		}

		return $out;
	}
}
add_filter( 'get_the_archive_description', 'kaamase_archive_intro' );

if ( ! function_exists( 'kaamase_districts_for_trade' ) ) {
	/**
	 * Which districts have workers in this trade.
	 *
	 * The other half of the cross linking. Somebody on the mason page
	 * gets one tap to masons in their own district, and only for
	 * districts where there is somebody to find.
	 *
	 * @since 1.0.0
	 * @param WP_Term|null $term The trade term.
	 * @return string Markup.
	 */
	function kaamase_districts_for_trade( $term ) {

		if ( ! $term instanceof WP_Term ) {
			return '';
		}

		$key    = 'kaamase_tradedist_' . md5( $term->slug );
		$cached = get_transient( $key );

		if ( false !== $cached ) {
			return (string) $cached;
		}

		global $wpdb;

		$rows = $wpdb->get_results( // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
			$wpdb->prepare(
				"SELECT district.slug AS slug, district.name AS name, COUNT(DISTINCT p.ID) AS total
				FROM {$wpdb->posts} p
				INNER JOIN {$wpdb->term_relationships} tr_t ON tr_t.object_id = p.ID
				INNER JOIN {$wpdb->term_taxonomy} tt_t ON tt_t.term_taxonomy_id = tr_t.term_taxonomy_id AND tt_t.taxonomy = 'kaamase_trade'
				INNER JOIN {$wpdb->terms} trade ON trade.term_id = tt_t.term_id AND trade.slug = %s
				INNER JOIN {$wpdb->term_relationships} tr_d ON tr_d.object_id = p.ID
				INNER JOIN {$wpdb->term_taxonomy} tt_d ON tt_d.term_taxonomy_id = tr_d.term_taxonomy_id AND tt_d.taxonomy = 'kaamase_district'
				INNER JOIN {$wpdb->terms} district ON district.term_id = tt_d.term_id
				WHERE p.post_status = 'publish'
				GROUP BY district.slug, district.name
				ORDER BY total DESC
				LIMIT 17",
				$term->slug
			)
		);

		if ( empty( $rows ) ) {
			set_transient( $key, '', HOUR_IN_SECONDS );
			return '';
		}

		$base = get_term_link( $term );

		if ( is_wp_error( $base ) ) {
			return '';
		}

		$out = '<div class="ka-mt-4"><p class="ka-small ka-mute">'
			. esc_html(
				sprintf(
					/* translators: %s: trade name */
					__( '%s by district', 'kaamase-core' ),
					$term->name
				)
			)
			. '</p><ul class="ka-chips-scroll ka-mt-4">';

		foreach ( $rows as $row ) {
			$out .= sprintf(
				'<li><a class="ka-chip" href="%1$s">%2$s <span class="ka-mute">%3$s</span></a></li>',
				esc_url( add_query_arg( 'kaamase_district', $row->slug, $base ) ),
				esc_html( $row->name ),
				esc_html( number_format_i18n( $row->total ) )
			);
		}

		$out .= '</ul></div>';

		set_transient( $key, $out, 6 * HOUR_IN_SECONDS );

		return $out;
	}
}

/**
 * Drop the cross link caches when content changes.
 *
 * @since 1.0.0
 * @return void
 */
function kaamase_clear_crosslink_cache() {

	global $wpdb;

	// Transients are the only thing here with a shared prefix worth sweeping.
	$wpdb->query( // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.NotPrepared
		$wpdb->prepare(
			"DELETE FROM {$wpdb->options}
			WHERE option_name LIKE %s OR option_name LIKE %s",
			$wpdb->esc_like( '_transient_kaamase_top_' ) . '%',
			$wpdb->esc_like( '_transient_kaamase_tradedist_' ) . '%'
		)
	);
}
add_action( 'kaamase_daily', 'kaamase_clear_crosslink_cache' );


/* ==========================================================================
   5. ARCHIVE TITLES

   WordPress writes Archives: Mason and Trade: Mason. Neither is a
   sentence anybody would say, and both look like a site somebody has not
   finished configuring.
   ========================================================================== */

/**
 * Write plain archive titles.
 *
 * @since 1.0.0
 * @param string $title Existing title.
 * @return string Filtered title.
 */
function kaamase_archive_title( $title ) {

	if ( is_admin() ) {
		return $title;
	}

	$term = get_queried_object();

	if ( is_tax( 'kaamase_trade' ) && $term instanceof WP_Term ) {

		$district = sanitize_key( (string) get_query_var( 'kaamase_district' ) );

		if ( $district ) {
			return sprintf(
				/* translators: 1: trade name, 2: district name */
				__( '%1$s in %2$s', 'kaamase-core' ),
				$term->name,
				kaamase_district_name( $district )
			);
		}

		return sprintf(
			/* translators: %s: trade name */
			__( '%s in Nagaland', 'kaamase-core' ),
			$term->name
		);
	}

	if ( is_tax( 'kaamase_district' ) && $term instanceof WP_Term ) {
		return sprintf(
			/* translators: %s: district name */
			__( 'Workers and jobs in %s', 'kaamase-core' ),
			$term->name
		);
	}

	if ( is_post_type_archive( 'kaamase_worker' ) ) {
		return __( 'Workers across Nagaland', 'kaamase-core' );
	}

	if ( is_post_type_archive( 'kaamase_gang' ) ) {
		return __( 'Teams for hire', 'kaamase-core' );
	}

	if ( is_post_type_archive( 'kaamase_job' ) ) {
		return __( 'Work available now', 'kaamase-core' );
	}

	return $title;
}
add_filter( 'get_the_archive_title', 'kaamase_archive_title' );
