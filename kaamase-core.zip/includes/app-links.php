<?php
/**
 * App links.
 *
 * The two files Google and Apple fetch from this domain before they will
 * let a kaamase.com link open the app instead of a browser.
 *
 * What was missing
 * ----------------
 * Android App Links are verified by Google fetching
 * /.well-known/assetlinks.json from the domain and checking that it
 * names the app's package and the certificate it was signed with. Apple
 * does the same with /.well-known/apple-app-site-association. Neither
 * file existed here, so the Play Console reported failed domain checks
 * and every link went to the browser.
 *
 * Nothing about that was ever an app problem. The app declares which
 * links it wants; the domain has to agree, in writing, at a fixed
 * address.
 *
 * Why from PHP rather than a file on disk
 * ---------------------------------------
 * A folder beginning with a dot is awkward to create and easy to lose in
 * a hosting file manager, and it disappears the next time somebody
 * restores a backup or moves the site. The fingerprints also change:
 * when Play re-signs, or a second key is added, or the app moves
 * account. Served from here they are a setting somebody can correct in
 * wp-admin in a minute rather than a file nobody remembers exists.
 *
 * A real file on disk still wins if one is ever put there. The web
 * server answers before WordPress is loaded, and that is the correct
 * order.
 *
 * Nothing else under .well-known is touched. That path also carries the
 * certificate renewal checks that keep the site's HTTPS working, and
 * intercepting those would take the site down in a way nobody would
 * connect back to this file.
 *
 * @package KaamaseCore
 * @version 1.0.0
 * @since   1.0.0
 */

defined( 'ABSPATH' ) || exit;


/** The Android package name. */
define( 'KAAMASE_LINK_PACKAGE_OPTION', 'kaamase_link_package' );

/** Signing certificate fingerprints, one per line. */
define( 'KAAMASE_LINK_FINGERPRINTS_OPTION', 'kaamase_link_fingerprints' );

/** The Apple team identifier. */
define( 'KAAMASE_LINK_TEAM_OPTION', 'kaamase_link_team' );

/** The iOS bundle identifier. */
define( 'KAAMASE_LINK_BUNDLE_OPTION', 'kaamase_link_bundle' );

/** Which paths the app claims, one per line. */
define( 'KAAMASE_LINK_PATHS_OPTION', 'kaamase_link_paths' );


/* ==========================================================================
   1. SETTINGS
   ========================================================================== */

if ( ! function_exists( 'kaamase_link_settings' ) ) {
	/**
	 * Register everything the two files are built from.
	 *
	 * @since 1.0.0
	 * @return void
	 */
	function kaamase_link_settings() {

		$text = array(
			'type'              => 'string',
			'sanitize_callback' => 'sanitize_text_field',
			'default'           => '',
		);

		register_setting( 'kaamase_links', KAAMASE_LINK_PACKAGE_OPTION, $text );
		register_setting( 'kaamase_links', KAAMASE_LINK_TEAM_OPTION, $text );
		register_setting( 'kaamase_links', KAAMASE_LINK_BUNDLE_OPTION, $text );

		register_setting(
			'kaamase_links',
			KAAMASE_LINK_FINGERPRINTS_OPTION,
			array(
				'type'              => 'string',
				'sanitize_callback' => 'kaamase_link_clean_fingerprints',
				'default'           => '',
			)
		);

		register_setting(
			'kaamase_links',
			KAAMASE_LINK_PATHS_OPTION,
			array(
				'type'              => 'string',
				'sanitize_callback' => 'sanitize_textarea_field',
				'default'           => "/job/*\n/worker/*",
			)
		);
	}
}
add_action( 'admin_init', 'kaamase_link_settings' );

if ( ! function_exists( 'kaamase_link_clean_fingerprints' ) ) {
	/**
	 * Tidy pasted fingerprints without throwing any away.
	 *
	 * Uppercased and stripped of anything that is not hex or a colon,
	 * because these get copied out of consoles and terminals and arrive
	 * with stray spaces and quotes around them. A line that still looks
	 * wrong afterwards is kept and flagged on the screen rather than
	 * dropped: silently discarding the one value that makes this work
	 * would be the worst possible failure here.
	 *
	 * @since 1.0.0
	 * @param string $raw What was pasted.
	 * @return string One fingerprint per line.
	 */
	function kaamase_link_clean_fingerprints( $raw ) {

		$out = array();

		foreach ( preg_split( '/[\r\n,]+/', (string) $raw ) as $line ) {

			$line = strtoupper( preg_replace( '/[^0-9a-fA-F:]/', '', $line ) );

			if ( '' !== $line ) {
				$out[] = $line;
			}
		}

		return implode( "\n", array_unique( $out ) );
	}
}

if ( ! function_exists( 'kaamase_link_fingerprints' ) ) {
	/**
	 * The fingerprints, as a list.
	 *
	 * @since 1.0.0
	 * @return string[]
	 */
	function kaamase_link_fingerprints() {

		$raw = (string) get_option( KAAMASE_LINK_FINGERPRINTS_OPTION, '' );

		return array_values( array_filter( array_map( 'trim', explode( "\n", $raw ) ) ) );
	}
}

if ( ! function_exists( 'kaamase_link_fingerprint_looks_right' ) ) {
	/**
	 * Whether a fingerprint is the shape Google expects.
	 *
	 * Thirty two hexadecimal pairs joined by colons. Worth checking
	 * because the usual mistake is pasting the SHA-1 by accident, which
	 * is the same shape at half the length and produces a file that
	 * looks perfectly correct and never verifies.
	 *
	 * @since 1.0.0
	 * @param string $value A fingerprint.
	 * @return bool
	 */
	function kaamase_link_fingerprint_looks_right( $value ) {

		return (bool) preg_match( '/^([0-9A-F]{2}:){31}[0-9A-F]{2}$/', (string) $value );
	}
}

if ( ! function_exists( 'kaamase_link_paths' ) ) {
	/**
	 * The paths the app claims.
	 *
	 * @since 1.0.0
	 * @return string[]
	 */
	function kaamase_link_paths() {

		$raw = (string) get_option( KAAMASE_LINK_PATHS_OPTION, "/job/*\n/worker/*" );

		$paths = array_values( array_filter( array_map( 'trim', explode( "\n", $raw ) ) ) );

		return $paths ? $paths : array( '/job/*', '/worker/*' );
	}
}


/* ==========================================================================
   2. THE TWO FILES
   ========================================================================== */

if ( ! function_exists( 'kaamase_link_android_json' ) ) {
	/**
	 * What Google fetches.
	 *
	 * @since 1.0.0
	 * @return array
	 */
	function kaamase_link_android_json() {

		return array(
			array(
				'relation' => array( 'delegate_permission/common.handle_all_urls' ),
				'target'   => array(
					'namespace'                => 'android_app',
					'package_name'             => (string) get_option( KAAMASE_LINK_PACKAGE_OPTION, '' ),
					'sha256_cert_fingerprints' => kaamase_link_fingerprints(),
				),
			),
		);
	}
}

if ( ! function_exists( 'kaamase_link_apple_json' ) ) {
	/**
	 * What Apple fetches.
	 *
	 * Written in both the old shape and the new one. Apple changed the
	 * format and older iOS versions read the older keys, so a file
	 * carrying only the new ones quietly stops working on exactly the
	 * cheap, out of date phones this platform is built for.
	 *
	 * @since 1.0.0
	 * @return array
	 */
	function kaamase_link_apple_json() {

		$app_id = trim( (string) get_option( KAAMASE_LINK_TEAM_OPTION, '' ) )
			. '.' . trim( (string) get_option( KAAMASE_LINK_BUNDLE_OPTION, '' ) );

		$components = array();

		foreach ( kaamase_link_paths() as $path ) {
			$components[] = array( '/' => $path );
		}

		return array(
			'applinks' => array(
				'apps'    => array(),
				'details' => array(
					array(
						'appID'      => $app_id,
						'appIDs'     => array( $app_id ),
						'paths'      => kaamase_link_paths(),
						'components' => $components,
					),
				),
			),
		);
	}
}

if ( ! function_exists( 'kaamase_link_ready' ) ) {
	/**
	 * Whether there is enough to answer with.
	 *
	 * An empty or half filled file is worse than no file. Google caches
	 * what it fetched and a wrong answer takes longer to recover from
	 * than a missing one, so nothing is served until the values that
	 * matter are actually present.
	 *
	 * @since 1.0.0
	 * @param string $which android or apple.
	 * @return bool
	 */
	function kaamase_link_ready( $which ) {

		if ( 'android' === $which ) {
			return (bool) get_option( KAAMASE_LINK_PACKAGE_OPTION, '' ) && kaamase_link_fingerprints();
		}

		return (bool) get_option( KAAMASE_LINK_TEAM_OPTION, '' )
			&& (bool) get_option( KAAMASE_LINK_BUNDLE_OPTION, '' );
	}
}


/* ==========================================================================
   3. ANSWERING THE REQUEST

   Early, before WordPress decides this is a page that does not exist and
   before any redirect can send the fetcher somewhere else. Neither
   Google nor Apple follows a redirect here, so a request that arrives at
   the wrong host or gets bounced to a canonical address simply fails,
   with nothing in the log to say why.
   ========================================================================== */

if ( ! function_exists( 'kaamase_link_serve' ) ) {
	/**
	 * Serve the file when one of the two addresses is asked for.
	 *
	 * @since 1.0.0
	 * @return void
	 */
	function kaamase_link_serve() {

		if ( is_admin() || ! isset( $_SERVER['REQUEST_URI'] ) ) {
			return;
		}

		$path = (string) wp_parse_url(
			esc_url_raw( wp_unslash( $_SERVER['REQUEST_URI'] ) ),
			PHP_URL_PATH
		);

		$path = rtrim( $path, '/' );

		if ( '/.well-known/assetlinks.json' === $path ) {

			if ( ! kaamase_link_ready( 'android' ) ) {
				return;
			}

			kaamase_link_send( kaamase_link_android_json() );
		}

		if ( '/.well-known/apple-app-site-association' === $path ) {

			if ( ! kaamase_link_ready( 'apple' ) ) {
				return;
			}

			kaamase_link_send( kaamase_link_apple_json() );
		}
	}
}
add_action( 'init', 'kaamase_link_serve', 0 );

if ( ! function_exists( 'kaamase_link_send' ) ) {
	/**
	 * Send one of the files and stop.
	 *
	 * The content type has to be JSON on both, including on Apple's,
	 * which has no file extension to give it away. An HTML content type
	 * is the single most common reason one of these fails while looking
	 * perfectly correct in a browser.
	 *
	 * @since 1.0.0
	 * @param array $data What to send.
	 * @return void
	 */
	function kaamase_link_send( $data ) {

		status_header( 200 );

		header( 'Content-Type: application/json; charset=utf-8' );
		header( 'Cache-Control: public, max-age=3600' );
		header( 'X-Robots-Tag: noindex' );

		echo wp_json_encode( $data, JSON_UNESCAPED_SLASHES | JSON_PRETTY_PRINT );

		exit;
	}
}


/* ==========================================================================
   4. THE SCREEN
   ========================================================================== */

if ( ! function_exists( 'kaamase_link_menu' ) ) {
	/**
	 * Add it under Kaam Ase.
	 *
	 * @since 1.0.0
	 * @return void
	 */
	function kaamase_link_menu() {

		add_submenu_page(
			'kaamase',
			__( 'App links', 'kaamase-core' ),
			__( 'App links', 'kaamase-core' ),
			'manage_options',
			'kaamase-app-links',
			'kaamase_link_screen'
		);
	}
}
add_action( 'admin_menu', 'kaamase_link_menu', 26 );

if ( ! function_exists( 'kaamase_link_screen' ) ) {
	/**
	 * Render the screen.
	 *
	 * @since 1.0.0
	 * @return void
	 */
	function kaamase_link_screen() {

		if ( ! current_user_can( 'manage_options' ) ) {
			return;
		}

		$prints = kaamase_link_fingerprints();
		$odd    = array();

		foreach ( $prints as $print ) {
			if ( ! kaamase_link_fingerprint_looks_right( $print ) ) {
				$odd[] = $print;
			}
		}
		?>
		<div class="wrap">

			<h1><?php esc_html_e( 'App links', 'kaamase-core' ); ?></h1>

			<p style="max-width:45em">
				<?php esc_html_e( 'Makes a kaamase.com link open the app instead of a browser. Google and Apple both check this domain before they allow it, and this screen is what they read. Fill it in, save, then press Retry in the Play Console.', 'kaamase-core' ); ?>
			</p>

			<h2><?php esc_html_e( 'What is being served right now', 'kaamase-core' ); ?></h2>

			<table class="widefat striped" style="max-width:46em">
				<tbody>
					<tr>
						<td>
							<a href="<?php echo esc_url( home_url( '/.well-known/assetlinks.json' ) ); ?>" target="_blank" rel="noopener">
								/.well-known/assetlinks.json
							</a>
							<p class="description"><?php esc_html_e( 'Android', 'kaamase-core' ); ?></p>
						</td>
						<td>
							<?php
							echo kaamase_link_ready( 'android' )
								? esc_html__( 'Being served', 'kaamase-core' )
								: esc_html__( 'Nothing yet. Fill in the package name and at least one fingerprint.', 'kaamase-core' );
							?>
						</td>
					</tr>
					<tr>
						<td>
							<a href="<?php echo esc_url( home_url( '/.well-known/apple-app-site-association' ) ); ?>" target="_blank" rel="noopener">
								/.well-known/apple-app-site-association
							</a>
							<p class="description"><?php esc_html_e( 'iPhone', 'kaamase-core' ); ?></p>
						</td>
						<td>
							<?php
							echo kaamase_link_ready( 'apple' )
								? esc_html__( 'Being served', 'kaamase-core' )
								: esc_html__( 'Nothing yet. Fill in the team and bundle identifiers.', 'kaamase-core' );
							?>
						</td>
					</tr>
				</tbody>
			</table>

			<?php if ( $odd ) : ?>
				<div class="notice notice-warning">
					<p>
						<?php esc_html_e( 'One of the fingerprints is not the expected shape. Google wants SHA-256, which is 32 pairs of characters joined by colons. SHA-1 is half that length and is the usual mistake. It has been kept exactly as you typed it in case it is right and this check is wrong.', 'kaamase-core' ); ?>
					</p>
				</div>
			<?php endif; ?>

			<form method="post" action="options.php">

				<?php settings_fields( 'kaamase_links' ); ?>

				<h2><?php esc_html_e( 'Android', 'kaamase-core' ); ?></h2>

				<table class="form-table" role="presentation">

					<tr>
						<th scope="row">
							<label for="ka-package"><?php esc_html_e( 'Package name', 'kaamase-core' ); ?></label>
						</th>
						<td>
							<input class="regular-text" type="text" id="ka-package"
								name="<?php echo esc_attr( KAAMASE_LINK_PACKAGE_OPTION ); ?>"
								value="<?php echo esc_attr( (string) get_option( KAAMASE_LINK_PACKAGE_OPTION, '' ) ); ?>"
								placeholder="com.kaamase.app">
							<p class="description">
								<?php esc_html_e( 'Shown in the Play Console beside the app name.', 'kaamase-core' ); ?>
							</p>
						</td>
					</tr>

					<tr>
						<th scope="row">
							<label for="ka-prints"><?php esc_html_e( 'Signing fingerprints', 'kaamase-core' ); ?></label>
						</th>
						<td>
							<textarea class="large-text code" id="ka-prints" rows="4"
								name="<?php echo esc_attr( KAAMASE_LINK_FINGERPRINTS_OPTION ); ?>"
								placeholder="AB:CD:EF:..."><?php echo esc_textarea( (string) get_option( KAAMASE_LINK_FINGERPRINTS_OPTION, '' ) ); ?></textarea>
							<p class="description">
								<?php esc_html_e( 'Play Console, Test and release, App signing. Copy the SHA-256 certificate fingerprint from the app signing key. One per line if you have more than one.', 'kaamase-core' ); ?>
							</p>
							<p class="description">
								<?php esc_html_e( 'Add the upload key fingerprint from the same screen as a second line. Builds you install straight onto a phone are signed with that one, and without it those builds will not open links even though the Play version does.', 'kaamase-core' ); ?>
							</p>
						</td>
					</tr>

				</table>

				<h2><?php esc_html_e( 'iPhone', 'kaamase-core' ); ?></h2>

				<table class="form-table" role="presentation">

					<tr>
						<th scope="row">
							<label for="ka-team"><?php esc_html_e( 'Team identifier', 'kaamase-core' ); ?></label>
						</th>
						<td>
							<input class="regular-text" type="text" id="ka-team"
								name="<?php echo esc_attr( KAAMASE_LINK_TEAM_OPTION ); ?>"
								value="<?php echo esc_attr( (string) get_option( KAAMASE_LINK_TEAM_OPTION, '' ) ); ?>"
								placeholder="A1B2C3D4E5">
							<p class="description">
								<?php esc_html_e( 'Ten characters, top right of the Apple developer account page.', 'kaamase-core' ); ?>
							</p>
						</td>
					</tr>

					<tr>
						<th scope="row">
							<label for="ka-bundle"><?php esc_html_e( 'Bundle identifier', 'kaamase-core' ); ?></label>
						</th>
						<td>
							<input class="regular-text" type="text" id="ka-bundle"
								name="<?php echo esc_attr( KAAMASE_LINK_BUNDLE_OPTION ); ?>"
								value="<?php echo esc_attr( (string) get_option( KAAMASE_LINK_BUNDLE_OPTION, '' ) ); ?>"
								placeholder="com.kaamase.app">
						</td>
					</tr>

				</table>

				<h2><?php esc_html_e( 'Which links open the app', 'kaamase-core' ); ?></h2>

				<table class="form-table" role="presentation">
					<tr>
						<th scope="row">
							<label for="ka-paths"><?php esc_html_e( 'Paths', 'kaamase-core' ); ?></label>
						</th>
						<td>
							<textarea class="large-text code" id="ka-paths" rows="4"
								name="<?php echo esc_attr( KAAMASE_LINK_PATHS_OPTION ); ?>"><?php echo esc_textarea( (string) get_option( KAAMASE_LINK_PATHS_OPTION, "/job/*\n/worker/*" ) ); ?></textarea>
							<p class="description">
								<?php esc_html_e( 'One per line. These must match what the app itself claims, and only affects iPhone: Android hands the app every link on the domain once the domain is verified.', 'kaamase-core' ); ?>
							</p>
						</td>
					</tr>
				</table>

				<?php submit_button(); ?>

			</form>

			<h2><?php esc_html_e( 'If it still fails', 'kaamase-core' ); ?></h2>

			<ol style="max-width:45em">
				<li><?php esc_html_e( 'Open the two links above. If either shows a page instead of plain text, something on this site is answering before the plugin does.', 'kaamase-core' ); ?></li>
				<li><?php esc_html_e( 'Check that kaamase.com does not redirect to www.kaamase.com or the other way round. Neither Google nor Apple follows a redirect for these files, and a redirect is invisible in a browser because the browser follows it for you.', 'kaamase-core' ); ?></li>
				<li><?php esc_html_e( 'Make sure the domain in the Play Console is written exactly the way the site answers on, without www if the site has no www.', 'kaamase-core' ); ?></li>
				<li><?php esc_html_e( 'Verification is not instant. Give it a day after saving before deciding it has not worked.', 'kaamase-core' ); ?></li>
			</ol>

		</div>
		<?php
	}
}