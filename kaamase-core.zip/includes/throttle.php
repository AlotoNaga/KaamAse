<?php
/**
 * Throttling.
 *
 * One counter, used by both the website and the app, so a limit cannot
 * be tighter on one than the other by accident.
 *
 * Why one file
 * ------------
 * The website and the REST API had grown their own limits, and they had
 * already drifted: app registration was counted against the login
 * failure counter, which a successful registration then cleared, so
 * registering repeatedly reset the very limit meant to stop it. Nobody
 * wrote that on purpose. It is what happens when two routes to the same
 * action each keep their own tally.
 *
 * So the counters live here and both sides call the same function. A
 * limit changed once is changed everywhere.
 *
 * What is counted
 * ---------------
 * Attempts, not failures, for anything that creates something or sends
 * an email. A limiter that only counts failures does not limit anything
 * when the attempts succeed, which is exactly the case worth limiting:
 * a thousand successful password reset emails to somebody else's
 * address is the attack, and every one of them is a success.
 *
 * @package KaamaseCore
 * @version 1.0.0
 * @since   1.3.0
 */

defined( 'ABSPATH' ) || exit;


if ( ! function_exists( 'kaamase_client_key' ) ) {
	/**
	 * Something stable to count against for one caller.
	 *
	 * Address and user agent together, hashed. The address alone puts
	 * everybody behind one office connection or one mobile carrier NAT
	 * in the same bucket, which in a state this size is a real risk of
	 * locking out a village rather than an attacker.
	 *
	 * This is a speed bump, not an identity. Anybody willing to change
	 * address gets a fresh bucket, and that is accepted: the job is to
	 * stop the cheap abuse, and the expensive kind needs a different
	 * answer than a transient.
	 *
	 * @since 1.3.0
	 * @param string $scope What is being counted, so buckets never mix.
	 * @return string
	 */
	function kaamase_client_key( $scope ) {

		$address = isset( $_SERVER['REMOTE_ADDR'] )
			? sanitize_text_field( wp_unslash( $_SERVER['REMOTE_ADDR'] ) )
			: 'unknown';

		$agent = isset( $_SERVER['HTTP_USER_AGENT'] )
			? sanitize_text_field( wp_unslash( $_SERVER['HTTP_USER_AGENT'] ) )
			: '';

		return 'ka_thr_' . sanitize_key( $scope ) . '_' . md5( $address . $agent );
	}
}

if ( ! function_exists( 'kaamase_throttle_ok' ) ) {
	/**
	 * Count one attempt and say whether it is allowed.
	 *
	 * Counts first, then decides, so an attempt that is refused still
	 * counts. Otherwise somebody who keeps going once blocked never
	 * pushes the window forward and can retry the moment it expires,
	 * every time, forever.
	 *
	 * @since 1.3.0
	 * @param string $key    A key from kaamase_client_key or similar.
	 * @param int    $limit  How many are allowed in the window.
	 * @param int    $window How long the window lasts, in seconds.
	 * @return bool True when this attempt is within the limit.
	 */
	function kaamase_throttle_ok( $key, $limit, $window ) {

		$count = (int) get_transient( $key );

		set_transient( $key, $count + 1, (int) $window );

		return $count < (int) $limit;
	}
}

if ( ! function_exists( 'kaamase_throttle_scoped' ) ) {
	/**
	 * The usual case: count against this caller and this subject.
	 *
	 * Both, because either alone leaves a hole. Counting only the caller
	 * lets one connection walk through a list of addresses a few at a
	 * time. Counting only the subject lets one address be hammered from
	 * anywhere, and also lets somebody lock a person out of their own
	 * password reset by burning their allowance for them.
	 *
	 * @since 1.3.0
	 * @param string $scope   What is being counted.
	 * @param string $subject The thing acted on, such as an email address.
	 * @param int    $limit   Per caller allowance in the window.
	 * @param int    $window  Window in seconds.
	 * @param int    $subject_limit Per subject allowance. Defaults to the same.
	 * @return bool
	 */
	function kaamase_throttle_scoped( $scope, $subject, $limit, $window, $subject_limit = 0 ) {

		$caller_ok = kaamase_throttle_ok( kaamase_client_key( $scope ), $limit, $window );

		$subject = trim( strtolower( (string) $subject ) );

		if ( '' === $subject ) {
			return $caller_ok;
		}

		$subject_ok = kaamase_throttle_ok(
			'ka_thr_' . sanitize_key( $scope ) . '_s_' . md5( $subject ),
			$subject_limit > 0 ? $subject_limit : $limit,
			$window
		);

		return $caller_ok && $subject_ok;
	}
}

if ( ! function_exists( 'kaamase_throttle_error' ) ) {
	/**
	 * The same answer every time somebody is over a limit.
	 *
	 * Deliberately says nothing about which limit or how long is left.
	 * A message that names the window is a message that tells somebody
	 * exactly when to come back and try again.
	 *
	 * @since 1.3.0
	 * @return WP_Error
	 */
	function kaamase_throttle_error() {

		return new WP_Error(
			'kaamase_rate_limited',
			__( 'Too many attempts from this connection. Please wait a while and try again.', 'kaamase-core' ),
			array( 'status' => 429 )
		);
	}
}