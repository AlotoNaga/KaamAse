<?php
/**
 * Admin.
 *
 * The screens you and your field agents actually work from.
 *
 * The one screen that matters
 * ---------------------------
 * Kaam Ase, the top level menu, is not a settings page. It shows five
 * numbers and a queue.
 *
 * The five numbers are the ones from the plan: fill rate, show up rate,
 * repeat employers, completed jobs, and how many workers are actually
 * available today. Downloads and registrations are deliberately not on
 * it. Experts Nagaland had traffic and no transactions, and a dashboard
 * full of vanity numbers is how that stays invisible for six months.
 *
 * The queue below them is the work: profiles that have been flagged,
 * accounts waiting on verification, and jobs about to expire. If that
 * queue is empty there is nothing to do here, which is the point.
 *
 * @package KaamaseCore
 * @version 1.0.0
 * @since   1.0.0
 */

defined( 'ABSPATH' ) || exit;


/* ==========================================================================
   1. MENU
   ========================================================================== */

if ( ! function_exists( 'kaamase_admin_menu' ) ) {
	/**
	 * Add the Kaam Ase menu.
	 *
	 * @since 1.0.0
	 * @return void
	 */
	function kaamase_admin_menu() {

		add_menu_page(
			__( 'Kaam Ase', 'kaamase-core' ),
			__( 'Kaam Ase', 'kaamase-core' ),
			'edit_others_kaamase_workers',
			'kaamase',
			'kaamase_admin_page',
			'dashicons-hammer',
			24
		);
	}
}
add_action( 'admin_menu', 'kaamase_admin_menu' );

if ( ! function_exists( 'kaamase_admin_page' ) ) {
	/**
	 * Render the main admin screen.
	 *
	 * @since 1.0.0
	 * @return void
	 */
	function kaamase_admin_page() {

		$stats = kaamase_platform_stats();
		?>
		<div class="wrap">

			<h1><?php esc_html_e( 'Kaam Ase', 'kaamase-core' ); ?></h1>

			<p class="description">
				<?php esc_html_e( 'These are the numbers that say whether this is working. Registrations and page views are not on this page on purpose.', 'kaamase-core' ); ?>
			</p>

			<div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(180px,1fr));gap:16px;margin:24px 0;">

				<?php
				$cards = array(
					array(
						__( 'Jobs filled', 'kaamase-core' ),
						sprintf( '%d%%', $stats['fill_rate'] ),
						__( 'Of jobs posted, how many got somebody.', 'kaamase-core' ),
					),
					array(
						__( 'Turned up', 'kaamase-core' ),
						$stats['show_rate'] > 0 ? sprintf( '%d%%', $stats['show_rate'] ) : __( 'No data', 'kaamase-core' ),
						__( 'Of workers hired, how many actually arrived. The whole business.', 'kaamase-core' ),
					),
					array(
						__( 'Employers who came back', 'kaamase-core' ),
						number_format_i18n( $stats['repeat_employers'] ),
						__( 'Posted more than once. The clearest sign it works.', 'kaamase-core' ),
					),
					array(
						__( 'Jobs completed', 'kaamase-core' ),
						number_format_i18n( $stats['hires'] ),
						__( 'Confirmed hires, all time.', 'kaamase-core' ),
					),
					array(
						__( 'Free right now', 'kaamase-core' ),
						number_format_i18n( $stats['available'] ),
						__( 'Workers marked available today.', 'kaamase-core' ),
					),
				);

				foreach ( $cards as $card ) :
					?>
					<div style="background:#fff;border:1px solid #dcdcde;border-radius:6px;padding:16px;">
						<p style="margin:0;color:#646970;font-size:12px;text-transform:uppercase;letter-spacing:0.04em;">
							<?php echo esc_html( $card[0] ); ?>
						</p>
						<p style="margin:6px 0;font-size:28px;font-weight:600;line-height:1.1;">
							<?php echo esc_html( $card[1] ); ?>
						</p>
						<p style="margin:0;color:#646970;font-size:12px;">
							<?php echo esc_html( $card[2] ); ?>
						</p>
					</div>
				<?php endforeach; ?>

			</div>

			<?php
			if ( $stats['hires'] < 50 ) :
				?>
				<div class="notice notice-info inline" style="margin:16px 0;">
					<p>
						<?php
						printf(
							/* translators: %s: number of completed hires so far */
							esc_html__( '%s completed hires so far. The target in the plan was 50 in the first 90 days, filled by hand if necessary. Until that number moves, nothing else on this page matters.', 'kaamase-core' ),
							esc_html( number_format_i18n( $stats['hires'] ) )
						);
						?>
					</p>
				</div>
			<?php endif; ?>

			<?php kaamase_admin_queue(); ?>

			<h2><?php esc_html_e( 'Where people are', 'kaamase-core' ); ?></h2>
			<?php kaamase_admin_district_table(); ?>

		</div>
		<?php
	}
}


/* ==========================================================================
   2. STATS
   ========================================================================== */

if ( ! function_exists( 'kaamase_platform_stats' ) ) {
	/**
	 * The five numbers.
	 *
	 * Cached for an hour. These are several counting queries and nobody
	 * needs them recalculated on every page load.
	 *
	 * @since 1.0.0
	 * @return array Statistics.
	 */
	function kaamase_platform_stats() {

		$cached = get_transient( 'kaamase_stats' );

		if ( is_array( $cached ) ) {
			return $cached;
		}

		global $wpdb;

		$jobs_posted = (int) $wpdb->get_var( // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
			"SELECT COUNT(*) FROM {$wpdb->posts}
			WHERE post_type = 'kaamase_job'
			AND post_status IN ('publish','kaamase_closed')"
		);

		$jobs_filled = (int) $wpdb->get_var( // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
			$wpdb->prepare(
				"SELECT COUNT(*) FROM {$wpdb->postmeta}
				WHERE meta_key = %s AND meta_value = 'filled'",
				KAAMASE_META_PREFIX . 'job_status'
			)
		);

		$available = (int) $wpdb->get_var( // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
			$wpdb->prepare(
				"SELECT COUNT(DISTINCT pm.post_id) FROM {$wpdb->postmeta} pm
				INNER JOIN {$wpdb->posts} p ON p.ID = pm.post_id
				WHERE pm.meta_key = %s AND pm.meta_value = 'live'
				AND p.post_status = 'publish'",
				KAAMASE_META_PREFIX . 'availability'
			)
		);

		$hires = (int) $wpdb->get_var( // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
			$wpdb->prepare(
				"SELECT COALESCE(SUM(CAST(meta_value AS UNSIGNED)),0) FROM {$wpdb->postmeta}
				WHERE meta_key = %s",
				KAAMASE_META_PREFIX . 'jobs_completed'
			)
		);

		// Employers who posted more than one job.
		$repeat = (int) $wpdb->get_var( // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
			"SELECT COUNT(*) FROM (
				SELECT post_author FROM {$wpdb->posts}
				WHERE post_type = 'kaamase_job'
				AND post_status IN ('publish','kaamase_closed')
				AND post_author > 0
				GROUP BY post_author
				HAVING COUNT(*) > 1
			) AS repeats"
		);

		$stats = array(
			'jobs_posted'      => $jobs_posted,
			'jobs_filled'      => $jobs_filled,
			'fill_rate'        => $jobs_posted ? (int) round( ( $jobs_filled / $jobs_posted ) * 100 ) : 0,
			'show_rate'        => kaamase_show_up_rate(),
			'repeat_employers' => $repeat,
			'hires'            => $hires,
			'available'        => $available,
		);

		set_transient( 'kaamase_stats', $stats, HOUR_IN_SECONDS );

		return $stats;
	}
}

if ( ! function_exists( 'kaamase_show_up_rate' ) ) {
	/**
	 * What share of hired workers actually turned up.
	 *
	 * Read straight from the turned_up answer on worker ratings. It is
	 * the single most important number this platform produces, and it is
	 * the reason that question exists at all.
	 *
	 * @since 1.0.0
	 * @return int Percentage, or 0 when there is no data.
	 */
	function kaamase_show_up_rate() {

		$ratings = get_comments(
			array(
				'type'   => 'kaamase_rating',
				'status' => 'approve',
				'number' => 500,
			)
		);

		$total  = 0;
		$showed = 0;

		foreach ( $ratings as $comment ) {

			$about = get_comment_meta( $comment->comment_ID, 'kaamase_about', true );

			if ( 'worker' !== $about ) {
				continue;
			}

			$answers = (array) get_comment_meta( $comment->comment_ID, 'kaamase_answers', true );

			if ( ! array_key_exists( 'turned_up', $answers ) ) {
				continue;
			}

			$total++;

			if ( ! empty( $answers['turned_up'] ) ) {
				$showed++;
			}
		}

		return $total ? (int) round( ( $showed / $total ) * 100 ) : 0;
	}
}

if ( ! function_exists( 'kaamase_admin_district_table' ) ) {
	/**
	 * Workers and jobs by district.
	 *
	 * Tells you where the platform is real and where it is only a map.
	 * A district with forty workers and no jobs needs employers, not more
	 * workers, and the two problems look identical until you split them.
	 *
	 * @since 1.0.0
	 * @return void
	 */
	function kaamase_admin_district_table() {

		$rows = array();

		foreach ( kaamase_districts() as $slug => $district ) {

			$term = get_term_by( 'slug', $slug, 'kaamase_district' );

			if ( ! $term instanceof WP_Term ) {
				continue;
			}

			$workers = new WP_Query(
				array(
					'post_type'      => 'kaamase_worker',
					'post_status'    => 'publish',
					'posts_per_page' => 1,
					'fields'         => 'ids',
					'tax_query'      => array( // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_tax_query
						array(
							'taxonomy' => 'kaamase_district',
							'field'    => 'slug',
							'terms'    => $slug,
						),
					),
				)
			);

			$jobs = new WP_Query(
				array(
					'post_type'      => 'kaamase_job',
					'post_status'    => 'publish',
					'posts_per_page' => 1,
					'fields'         => 'ids',
					'tax_query'      => array( // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_tax_query
						array(
							'taxonomy' => 'kaamase_district',
							'field'    => 'slug',
							'terms'    => $slug,
						),
					),
				)
			);

			$rows[] = array(
				'name'    => $district['name'],
				'workers' => (int) $workers->found_posts,
				'jobs'    => (int) $jobs->found_posts,
			);
		}

		usort(
			$rows,
			static function ( $a, $b ) {
				return $b['workers'] <=> $a['workers'];
			}
		);
		?>
		<table class="widefat striped" style="max-width:640px;">
			<thead>
				<tr>
					<th><?php esc_html_e( 'District', 'kaamase-core' ); ?></th>
					<th><?php esc_html_e( 'Workers', 'kaamase-core' ); ?></th>
					<th><?php esc_html_e( 'Open jobs', 'kaamase-core' ); ?></th>
					<th><?php esc_html_e( 'What it needs', 'kaamase-core' ); ?></th>
				</tr>
			</thead>
			<tbody>
				<?php foreach ( $rows as $row ) : ?>
					<tr>
						<td><strong><?php echo esc_html( $row['name'] ); ?></strong></td>
						<td><?php echo esc_html( number_format_i18n( $row['workers'] ) ); ?></td>
						<td><?php echo esc_html( number_format_i18n( $row['jobs'] ) ); ?></td>
						<td>
							<?php
							if ( ! $row['workers'] && ! $row['jobs'] ) {
								esc_html_e( 'Nothing here yet', 'kaamase-core' );
							} elseif ( $row['workers'] > 5 && ! $row['jobs'] ) {
								echo '<strong>' . esc_html__( 'Employers', 'kaamase-core' ) . '</strong>';
							} elseif ( $row['jobs'] > 0 && $row['workers'] < 3 ) {
								echo '<strong>' . esc_html__( 'Workers', 'kaamase-core' ) . '</strong>';
							} else {
								esc_html_e( 'Balanced', 'kaamase-core' );
							}
							?>
						</td>
					</tr>
				<?php endforeach; ?>
			</tbody>
		</table>
		<?php
	}
}


/* ==========================================================================
   3. THE QUEUE
   ========================================================================== */

if ( ! function_exists( 'kaamase_admin_queue' ) ) {
	/**
	 * What needs a human today.
	 *
	 * @since 1.0.0
	 * @return void
	 */
	function kaamase_admin_queue() {

		$flagged = kaamase_flagged_profiles();

		echo '<h2>' . esc_html__( 'Needs your attention', 'kaamase-core' ) . '</h2>';

		if ( empty( $flagged ) ) {
			echo '<p>' . esc_html__( 'Nothing flagged. Nobody has been reported for not paying or not turning up.', 'kaamase-core' ) . '</p>';
			return;
		}
		?>
		<table class="widefat striped" style="max-width:820px;margin-bottom:24px;">
			<thead>
				<tr>
					<th><?php esc_html_e( 'Who', 'kaamase-core' ); ?></th>
					<th><?php esc_html_e( 'What', 'kaamase-core' ); ?></th>
					<th><?php esc_html_e( 'How many times', 'kaamase-core' ); ?></th>
					<th></th>
				</tr>
			</thead>
			<tbody>
				<?php foreach ( $flagged as $item ) : ?>
					<tr>
						<td><strong><?php echo esc_html( get_the_title( $item['post_id'] ) ); ?></strong></td>
						<td><?php echo esc_html( $item['label'] ); ?></td>
						<td><?php echo esc_html( number_format_i18n( $item['count'] ) ); ?></td>
						<td>
							<a href="<?php echo esc_url( get_edit_post_link( $item['post_id'] ) ); ?>">
								<?php esc_html_e( 'Open', 'kaamase-core' ); ?>
							</a>
						</td>
					</tr>
				<?php endforeach; ?>
			</tbody>
		</table>

		<p class="description" style="max-width:640px;">
			<?php esc_html_e( 'Three people saying the same thing about the same person is a pattern. Phone them before it turns into a public argument. That call is the whole job.', 'kaamase-core' ); ?>
		</p>
		<?php
	}
}

if ( ! function_exists( 'kaamase_flagged_profiles' ) ) {
	/**
	 * Profiles carrying three or more flags on one question.
	 *
	 * @since 1.0.0
	 * @return array[] Flagged items.
	 */
	function kaamase_flagged_profiles() {

		global $wpdb;

		$rows = $wpdb->get_results( // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
			$wpdb->prepare(
				"SELECT post_id, meta_value FROM {$wpdb->postmeta} WHERE meta_key = %s LIMIT 200",
				KAAMASE_META_PREFIX . 'flags'
			)
		);

		$labels = array();

		foreach ( array( 'worker', 'employer' ) as $about ) {
			foreach ( kaamase_rating_questions( $about ) as $key => $question ) {
				$labels[ $key ] = $question['label'];
			}
		}

		$out = array();

		foreach ( (array) $rows as $row ) {

			$flags = maybe_unserialize( $row->meta_value );

			if ( ! is_array( $flags ) ) {
				continue;
			}

			foreach ( $flags as $key => $count ) {

				if ( absint( $count ) < 3 ) {
					continue;
				}

				$out[] = array(
					'post_id' => (int) $row->post_id,
					'label'   => isset( $labels[ $key ] ) ? rtrim( $labels[ $key ], '?' ) : $key,
					'count'   => absint( $count ),
				);
			}
		}

		usort(
			$out,
			static function ( $a, $b ) {
				return $b['count'] <=> $a['count'];
			}
		);

		return $out;
	}
}


/* ==========================================================================
   4. LIST COLUMNS
   ========================================================================== */

if ( ! function_exists( 'kaamase_worker_columns' ) ) {
	/**
	 * Columns on the workers list.
	 *
	 * @since 1.0.0
	 * @param array $columns Existing columns.
	 * @return array Filtered columns.
	 */
	function kaamase_worker_columns( $columns ) {

		$new = array();

		foreach ( $columns as $key => $label ) {

			$new[ $key ] = $label;

			if ( 'title' === $key ) {
				$new['ka_where']  = __( 'Where', 'kaamase-core' );
				$new['ka_free']   = __( 'Free', 'kaamase-core' );
				$new['ka_rate']   = __( 'Day rate', 'kaamase-core' );
				$new['ka_trust']  = __( 'Trust', 'kaamase-core' );
			}
		}

		unset( $new['date'] );
		$new['date'] = __( 'Joined', 'kaamase-core' );

		return $new;
	}
}
add_filter( 'manage_kaamase_worker_posts_columns', 'kaamase_worker_columns' );
add_filter( 'manage_kaamase_gang_posts_columns', 'kaamase_worker_columns' );

if ( ! function_exists( 'kaamase_worker_column_content' ) ) {
	/**
	 * Fill the custom columns.
	 *
	 * @since 1.0.0
	 * @param string $column  Column key.
	 * @param int    $post_id Post ID.
	 * @return void
	 */
	function kaamase_worker_column_content( $column, $post_id ) {

		switch ( $column ) {

			case 'ka_where':
				$town     = (string) kaamase_read_field( $post_id, 'town' );
				$district = kaamase_district_name( (string) kaamase_read_field( $post_id, 'district' ) );
				echo esc_html( trim( $town . ( $town && $district ? ', ' : '' ) . $district ) );
				break;

			case 'ka_free':
				$state  = (string) kaamase_read_field( $post_id, 'availability' );
				$labels = array(
					'live'  => __( 'Yes', 'kaamase-core' ),
					'busy'  => __( 'Working', 'kaamase-core' ),
					'leave' => __( 'On leave', 'kaamase-core' ),
				);
				echo esc_html( isset( $labels[ $state ] ) ? $labels[ $state ] : '' );
				break;

			case 'ka_rate':
				$rate = absint( kaamase_read_field( $post_id, 'day_rate' ) );
				echo $rate
					? esc_html( '₹' . number_format_i18n( $rate ) )
					: '<span style="color:#a7aaad;">' . esc_html__( 'Not set', 'kaamase-core' ) . '</span>';
				break;

			case 'ka_trust':
				$bits = array();

				if ( kaamase_read_field( $post_id, 'vouched_by' ) ) {
					$bits[] = esc_html__( 'Vouched', 'kaamase-core' );
				}

				if ( kaamase_read_field( $post_id, 'verified' ) ) {
					$bits[] = esc_html__( 'Verified', 'kaamase-core' );
				}

				$count = absint( get_post_meta( $post_id, KAAMASE_META_PREFIX . 'rating_count', true ) );

				if ( $count ) {
					$score  = (float) get_post_meta( $post_id, KAAMASE_META_PREFIX . 'rating_average', true );
					$bits[] = esc_html( sprintf( '%s (%d)', number_format_i18n( $score, 1 ), $count ) );
				}

				echo $bits
					? esc_html( implode( ', ', $bits ) )
					: '<span style="color:#a7aaad;">' . esc_html__( 'New', 'kaamase-core' ) . '</span>';
				break;
		}
	}
}
add_action( 'manage_kaamase_worker_posts_custom_column', 'kaamase_worker_column_content', 10, 2 );
add_action( 'manage_kaamase_gang_posts_custom_column', 'kaamase_worker_column_content', 10, 2 );

if ( ! function_exists( 'kaamase_job_columns' ) ) {
	/**
	 * Columns on the jobs list.
	 *
	 * @since 1.0.0
	 * @param array $columns Existing columns.
	 * @return array Filtered columns.
	 */
	function kaamase_job_columns( $columns ) {

		$new = array();

		foreach ( $columns as $key => $label ) {

			$new[ $key ] = $label;

			if ( 'title' === $key ) {
				$new['ka_where']  = __( 'Where', 'kaamase-core' );
				$new['ka_pay']    = __( 'Pay', 'kaamase-core' );
				$new['ka_state']  = __( 'State', 'kaamase-core' );
			}
		}

		return $new;
	}
}
add_filter( 'manage_kaamase_job_posts_columns', 'kaamase_job_columns' );

if ( ! function_exists( 'kaamase_job_column_content' ) ) {
	/**
	 * Fill the job columns.
	 *
	 * @since 1.0.0
	 * @param string $column  Column key.
	 * @param int    $post_id Post ID.
	 * @return void
	 */
	function kaamase_job_column_content( $column, $post_id ) {

		switch ( $column ) {

			case 'ka_where':
				$town     = (string) kaamase_read_field( $post_id, 'town' );
				$district = kaamase_district_name( (string) kaamase_read_field( $post_id, 'district' ) );
				echo esc_html( trim( $town . ( $town && $district ? ', ' : '' ) . $district ) );
				break;

			case 'ka_pay':
				$amount = absint( kaamase_read_field( $post_id, 'pay_amount' ) );
				echo $amount ? esc_html( '₹' . number_format_i18n( $amount ) ) : '';
				break;

			case 'ka_state':
				if ( kaamase_job_is_open( $post_id ) ) {

					$expires = (int) kaamase_read_field( $post_id, 'expires' );
					$days    = $expires ? (int) ceil( ( $expires - time() ) / DAY_IN_SECONDS ) : 0;

					printf(
						'<strong>%1$s</strong>%2$s',
						esc_html__( 'Open', 'kaamase-core' ),
						$days > 0
							? esc_html(
								sprintf(
									/* translators: %d: days remaining */
									_n( ', %d day left', ', %d days left', $days, 'kaamase-core' ),
									$days
								)
							)
							: ''
					);

					break;
				}

				echo '<span style="color:#a7aaad;">' . esc_html__( 'Closed', 'kaamase-core' ) . '</span>';
				break;
		}
	}
}
add_action( 'manage_kaamase_job_posts_custom_column', 'kaamase_job_column_content', 10, 2 );


/* ==========================================================================
   5. FILTERS AND BULK ACTIONS
   ========================================================================== */

if ( ! function_exists( 'kaamase_district_filter' ) ) {
	/**
	 * Add a district dropdown above the lists.
	 *
	 * @since 1.0.0
	 * @param string $post_type Current post type.
	 * @return void
	 */
	function kaamase_district_filter( $post_type ) {

		if ( ! in_array( $post_type, kaamase_post_types(), true ) ) {
			return;
		}

		// phpcs:ignore WordPress.Security.NonceVerification.Recommended
		$current = isset( $_GET['kaamase_district'] ) ? sanitize_key( wp_unslash( $_GET['kaamase_district'] ) ) : '';
		?>
		<select name="kaamase_district">
			<option value=""><?php esc_html_e( 'All districts', 'kaamase-core' ); ?></option>
			<?php foreach ( kaamase_district_choices() as $slug => $name ) : ?>
				<option value="<?php echo esc_attr( $slug ); ?>" <?php selected( $current, $slug ); ?>>
					<?php echo esc_html( $name ); ?>
				</option>
			<?php endforeach; ?>
		</select>
		<?php
	}
}
add_action( 'restrict_manage_posts', 'kaamase_district_filter' );

if ( ! function_exists( 'kaamase_verify_bulk_action' ) ) {
	/**
	 * Add a bulk verify action.
	 *
	 * This is the field agent workflow. Somebody registers thirty workers
	 * at a labour point in a morning, then ticks them all and marks them
	 * verified in one go, because they met every one of them in person.
	 *
	 * @since 1.0.0
	 * @param array $actions Existing bulk actions.
	 * @return array Filtered actions.
	 */
	function kaamase_verify_bulk_action( $actions ) {

		if ( ! current_user_can( 'kaamase_verify_workers' ) ) {
			return $actions;
		}

		$actions['kaamase_verify']   = __( 'Mark verified', 'kaamase-core' );
		$actions['kaamase_unverify'] = __( 'Remove verified', 'kaamase-core' );

		return $actions;
	}
}
add_filter( 'bulk_actions-edit-kaamase_worker', 'kaamase_verify_bulk_action' );
add_filter( 'bulk_actions-edit-kaamase_gang', 'kaamase_verify_bulk_action' );
add_filter( 'bulk_actions-edit-kaamase_employer', 'kaamase_verify_bulk_action' );

if ( ! function_exists( 'kaamase_handle_verify_bulk' ) ) {
	/**
	 * Apply the bulk verify action.
	 *
	 * @since 1.0.0
	 * @param string $redirect Redirect URL.
	 * @param string $action   Action being run.
	 * @param int[]  $post_ids Selected posts.
	 * @return string Redirect URL.
	 */
	function kaamase_handle_verify_bulk( $redirect, $action, $post_ids ) {

		if ( ! in_array( $action, array( 'kaamase_verify', 'kaamase_unverify' ), true ) ) {
			return $redirect;
		}

		if ( ! current_user_can( 'kaamase_verify_workers' ) ) {
			return $redirect;
		}

		$value = ( 'kaamase_verify' === $action );

		foreach ( $post_ids as $post_id ) {

			update_post_meta( $post_id, KAAMASE_META_PREFIX . 'verified', $value );

			// Record who did it. Verification is a person vouching, so name them.
			if ( $value ) {
				update_post_meta( $post_id, KAAMASE_META_PREFIX . 'verified_by', get_current_user_id() );
				update_post_meta( $post_id, KAAMASE_META_PREFIX . 'verified_at', time() );
			}
		}

		return add_query_arg( 'kaamase_verified', count( $post_ids ), $redirect );
	}
}
add_filter( 'handle_bulk_actions-edit-kaamase_worker', 'kaamase_handle_verify_bulk', 10, 3 );
add_filter( 'handle_bulk_actions-edit-kaamase_gang', 'kaamase_handle_verify_bulk', 10, 3 );
add_filter( 'handle_bulk_actions-edit-kaamase_employer', 'kaamase_handle_verify_bulk', 10, 3 );

if ( ! function_exists( 'kaamase_bulk_notice' ) ) {
	/**
	 * Confirm a bulk verification.
	 *
	 * @since 1.0.0
	 * @return void
	 */
	function kaamase_bulk_notice() {

		// phpcs:ignore WordPress.Security.NonceVerification.Recommended
		if ( empty( $_GET['kaamase_verified'] ) ) {
			return;
		}

		// phpcs:ignore WordPress.Security.NonceVerification.Recommended
		$count = absint( $_GET['kaamase_verified'] );

		printf(
			'<div class="notice notice-success is-dismissible"><p>%s</p></div>',
			esc_html(
				sprintf(
					/* translators: %s: number of profiles updated */
					_n( '%s profile updated.', '%s profiles updated.', $count, 'kaamase-core' ),
					number_format_i18n( $count )
				)
			)
		);
	}
}
add_action( 'admin_notices', 'kaamase_bulk_notice' );


/* ==========================================================================
   6. RATING MODERATION
   ========================================================================== */

/**
 * Label ratings clearly on the comments screen.
 *
 * Without this a rating shows up as a comment with no context, and the
 * held ones look like spam waiting to be approved. Approving one by hand
 * would break the double blind, so the label says so.
 *
 * @since 1.0.0
 * @param string $text    Existing comment text.
 * @param object $comment The comment.
 * @return string Filtered text.
 */
function kaamase_label_rating_comments( $text, $comment = null ) {

	if ( ! is_admin() || ! $comment || 'kaamase_rating' !== $comment->comment_type ) {
		return $text;
	}

	$score = get_comment_meta( $comment->comment_ID, 'kaamase_score', true );
	$held  = '0' === (string) $comment->comment_approved;

	$prefix = sprintf(
		'<strong>%s</strong><br>',
		esc_html(
			sprintf(
				/* translators: %s: score out of five */
				__( 'Kaam Ase rating: %s out of 5', 'kaamase-core' ),
				number_format_i18n( (float) $score, 1 )
			)
		)
	);

	if ( $held ) {
		$prefix .= '<em>' . esc_html__( 'Waiting for the other side to rate. Do not approve by hand, it releases one rating without the other.', 'kaamase-core' ) . '</em><br>';
	}

	return $prefix . $text;
}
add_filter( 'comment_text', 'kaamase_label_rating_comments', 10, 2 );

/**
 * Recalculate the average when a rating is moderated or deleted.
 *
 * @since 1.0.0
 * @param int $comment_id Comment ID.
 * @return void
 */
function kaamase_rating_moderated( $comment_id ) {

	$comment = get_comment( $comment_id );

	if ( ! $comment || 'kaamase_rating' !== $comment->comment_type ) {
		return;
	}

	kaamase_recalculate_rating( (int) $comment->comment_post_ID );
}
add_action( 'wp_set_comment_status', 'kaamase_rating_moderated' );
add_action( 'deleted_comment', 'kaamase_rating_moderated' );
add_action( 'trashed_comment', 'kaamase_rating_moderated' );


/* ==========================================================================
   7. TIDYING
   ========================================================================== */

/**
 * Clear the stats cache when something changes.
 *
 * @since 1.0.0
 * @return void
 */
function kaamase_clear_stats_cache() {
	delete_transient( 'kaamase_stats' );
}
add_action( 'kaamase_hire_recorded', 'kaamase_clear_stats_cache' );
add_action( 'save_post_kaamase_job', 'kaamase_clear_stats_cache' );

/**
 * Hide the WordPress posts and comments menus from field agents.
 *
 * An agent opening the admin should see workers and teams and nothing
 * else. Every extra menu is a thing to get lost in and a thing to break.
 *
 * @since 1.0.0
 * @return void
 */
function kaamase_simplify_agent_admin() {

	if ( ! current_user_can( 'kaamase_verify_workers' ) || current_user_can( 'manage_options' ) ) {
		return;
	}

	remove_menu_page( 'edit.php' );
	remove_menu_page( 'edit-comments.php' );
	remove_menu_page( 'tools.php' );
}
add_action( 'admin_menu', 'kaamase_simplify_agent_admin', 999 );
