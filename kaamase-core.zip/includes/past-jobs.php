<?php
/**
 * The past jobs archive.
 *
 * A browsable list of every job that has closed, and the rules for how
 * long those pages stay in search.
 *
 * Why this exists
 * ---------------
 * closed-jobs.php stopped closed jobs from returning 404, which recovers
 * the pages that already existed. It does not solve what happens next.
 * Nothing on the site links to a closed job, so over a few years the
 * whole archive becomes orphaned: reachable only by its own address,
 * crawled less and less, and slowly dropped.
 *
 * That is not a penalty. It is a fade, and a fade is enough to waste the
 * thing entirely. This file gives every closed job a live link pointing
 * at it, which is the whole difference between an archive and a pile of
 * abandoned URLs.
 *
 * What the archive is actually for
 * --------------------------------
 * Not for ranking. An expired job post is a notice whose moment has
 * passed, and a thousand of them do not add up to something a person
 * searching for work wants to read.
 *
 * The pages that should rank are the trade and district archives:
 * mason work in Dimapur is a search somebody makes every month for the
 * next ten years, and that page is always current because it always
 * lists open work. Every closed job here is a small link pointing at
 * those pages. That is the job the archive does, and it is worth more
 * than any single dead listing ranking on its own.
 *
 * So the hub itself is deliberately kept out of search while staying
 * fully crawlable. It exists to pass links along, not to compete with
 * the pages it points at.
 *
 * The ageing rule
 * ---------------
 * Google's own guidance on expired listings is to keep them readable
 * while somebody might still care, then take them out of search rather
 * than building endlessly more URLs that answer nothing. After a year a
 * closed job stops being indexed, while staying browsable here for
 * anybody who wants it. The number of months is a setting, and zero
 * switches the ageing off.
 *
 * At the current size this rule does nothing at all: no job on the site
 * is a year old yet. It is here so that it starts working by itself on
 * the day it becomes relevant, rather than being remembered afterwards.
 *
 * @package KaamaseCore
 * @version 1.0.0
 * @since   1.0.0
 */

defined( 'ABSPATH' ) || exit;


/** Which page carries the archive. */
define( 'KAAMASE_PAST_PAGE_OPTION', 'kaamase_past_jobs_page' );

/** How many months before a closed job leaves search. */
define( 'KAAMASE_PAST_MONTHS_OPTION', 'kaamase_past_jobs_months' );

/** How many jobs on one page of the archive. */
define( 'KAAMASE_PAST_PER_PAGE', 24 );


/* ==========================================================================
   1. SETTINGS
   ========================================================================== */

if ( ! function_exists( 'kaamase_past_jobs_settings' ) ) {
	/**
	 * Register the two settings.
	 *
	 * @since 1.0.0
	 * @return void
	 */
	function kaamase_past_jobs_settings() {

		register_setting(
			'kaamase_past_jobs',
			KAAMASE_PAST_PAGE_OPTION,
			array(
				'type'              => 'integer',
				'sanitize_callback' => 'absint',
				'default'           => 0,
			)
		);

		register_setting(
			'kaamase_past_jobs',
			KAAMASE_PAST_MONTHS_OPTION,
			array(
				'type'              => 'integer',
				'sanitize_callback' => 'absint',
				'default'           => 12,
			)
		);
	}
}
add_action( 'admin_init', 'kaamase_past_jobs_settings' );

if ( ! function_exists( 'kaamase_past_jobs_page_id' ) ) {
	/**
	 * The page holding the archive.
	 *
	 * @since 1.0.0
	 * @return int Page ID, or 0 when none is set.
	 */
	function kaamase_past_jobs_page_id() {

		$page_id = (int) get_option( KAAMASE_PAST_PAGE_OPTION, 0 );

		return ( $page_id && 'publish' === get_post_status( $page_id ) ) ? $page_id : 0;
	}
}

if ( ! function_exists( 'kaamase_past_jobs_months' ) ) {
	/**
	 * How many months a closed job stays in search.
	 *
	 * @since 1.0.0
	 * @return int Months, or 0 for forever.
	 */
	function kaamase_past_jobs_months() {

		/**
		 * Filter how long a closed job stays indexed.
		 *
		 * @since 1.0.0
		 * @param int $months Months. Zero means never remove it.
		 */
		return absint( apply_filters( 'kaamase_past_jobs_months', (int) get_option( KAAMASE_PAST_MONTHS_OPTION, 12 ) ) );
	}
}

if ( ! function_exists( 'kaamase_past_jobs_url' ) ) {
	/**
	 * The archive address, optionally filtered.
	 *
	 * @since 1.0.0
	 * @param array $args Query arguments to add.
	 * @return string URL, or an empty string when no page is set.
	 */
	function kaamase_past_jobs_url( $args = array() ) {

		$page_id = kaamase_past_jobs_page_id();

		if ( ! $page_id ) {
			return '';
		}

		$url = (string) get_permalink( $page_id );

		return $args ? add_query_arg( $args, $url ) : $url;
	}
}

if ( ! function_exists( 'kaamase_past_jobs_self_url' ) ) {
	/**
	 * The address of the list as it is being viewed.
	 *
	 * The chosen page when there is one, otherwise whatever page the
	 * shortcode was put on. Filtering and paging use this rather than
	 * the setting, so the list works the moment somebody pastes the
	 * shortcode into a page and before anybody has been to the settings
	 * screen. A list whose Older button goes nowhere until a setting is
	 * saved is a list that looks broken on first use.
	 *
	 * @since 1.0.0
	 * @param array $args Query arguments to add.
	 * @return string URL.
	 */
	function kaamase_past_jobs_self_url( $args = array() ) {

		$url = kaamase_past_jobs_url();

		if ( ! $url && is_singular() ) {
			$url = (string) get_permalink( get_queried_object_id() );
		}

		if ( ! $url ) {
			$url = home_url( '/' );
		}

		return $args ? add_query_arg( $args, $url ) : $url;
	}
}

if ( ! function_exists( 'kaamase_past_jobs_menu' ) ) {
	/**
	 * Add the settings screen.
	 *
	 * @since 1.0.0
	 * @return void
	 */
	function kaamase_past_jobs_menu() {

		add_submenu_page(
			'kaamase',
			__( 'Past jobs', 'kaamase-core' ),
			__( 'Past jobs', 'kaamase-core' ),
			'manage_options',
			'kaamase-past-jobs',
			'kaamase_past_jobs_screen'
		);
	}
}
add_action( 'admin_menu', 'kaamase_past_jobs_menu', 23 );

if ( ! function_exists( 'kaamase_past_jobs_screen' ) ) {
	/**
	 * Render the settings screen.
	 *
	 * @since 1.0.0
	 * @return void
	 */
	function kaamase_past_jobs_screen() {

		if ( ! current_user_can( 'manage_options' ) ) {
			return;
		}

		$page_id = (int) get_option( KAAMASE_PAST_PAGE_OPTION, 0 );
		$months  = (int) get_option( KAAMASE_PAST_MONTHS_OPTION, 12 );
		$closed  = wp_count_posts( 'kaamase_job' );
		$total   = isset( $closed->kaamase_closed ) ? (int) $closed->kaamase_closed : 0;
		?>
		<div class="wrap">

			<h1><?php esc_html_e( 'Past jobs', 'kaamase-core' ); ?></h1>

			<p style="max-width:45em">
				<?php esc_html_e( 'Closed jobs stay on the site and stay readable. This screen decides where people can browse them and how long they stay in search results.', 'kaamase-core' ); ?>
			</p>

			<p>
				<?php
				echo esc_html(
					sprintf(
						/* translators: %s: how many closed jobs there are */
						_n( 'There is %s closed job.', 'There are %s closed jobs.', $total, 'kaamase-core' ),
						number_format_i18n( $total )
					)
				);
				?>
			</p>

			<?php if ( ! $page_id ) : ?>
				<div class="notice notice-warning">
					<p>
						<?php esc_html_e( 'No page is set yet. Make a page called Past jobs, put the shortcode below in it, then choose it here.', 'kaamase-core' ); ?>
					</p>
					<p><code>[kaamase_past_jobs]</code></p>
				</div>
			<?php endif; ?>

			<form method="post" action="options.php">

				<?php settings_fields( 'kaamase_past_jobs' ); ?>

				<table class="form-table" role="presentation">

					<tr>
						<th scope="row">
							<label for="kaamase-past-page"><?php esc_html_e( 'The page', 'kaamase-core' ); ?></label>
						</th>
						<td>
							<?php
							wp_dropdown_pages(
								array(
									'name'              => esc_attr( KAAMASE_PAST_PAGE_OPTION ),
									'id'                => 'kaamase-past-page',
									'selected'          => $page_id,
									'show_option_none'  => esc_html__( 'Not set', 'kaamase-core' ),
									'option_none_value' => 0,
								)
							);
							?>
							<p class="description">
								<?php esc_html_e( 'The page carrying the shortcode. Closed jobs link back to it, which is what stops them going orphaned.', 'kaamase-core' ); ?>
							</p>
						</td>
					</tr>

					<tr>
						<th scope="row">
							<label for="kaamase-past-months"><?php esc_html_e( 'Leave search after', 'kaamase-core' ); ?></label>
						</th>
						<td>
							<input type="number" id="kaamase-past-months" min="0" max="120" step="1"
								name="<?php echo esc_attr( KAAMASE_PAST_MONTHS_OPTION ); ?>"
								value="<?php echo esc_attr( $months ); ?>">
							<?php esc_html_e( 'months', 'kaamase-core' ); ?>
							<p class="description">
								<?php esc_html_e( 'A closed job older than this stops being indexed by search engines. It stays on the site and stays browsable here. Set it to 0 to keep every closed job in search forever.', 'kaamase-core' ); ?>
							</p>
							<p class="description">
								<?php esc_html_e( 'Twelve is a sensible starting point. Nothing on the site is old enough for this to do anything yet.', 'kaamase-core' ); ?>
							</p>
						</td>
					</tr>

				</table>

				<?php submit_button(); ?>

			</form>

		</div>
		<?php
	}
}


/* ==========================================================================
   2. THE ARCHIVE ITSELF
   ========================================================================== */

if ( ! function_exists( 'kaamase_past_jobs_query' ) ) {
	/**
	 * Fetch a page of closed jobs.
	 *
	 * @since 1.0.0
	 * @param string $trade    Trade slug, or an empty string.
	 * @param string $district District slug, or an empty string.
	 * @param int    $paged    Which page.
	 * @return WP_Query
	 */
	function kaamase_past_jobs_query( $trade = '', $district = '', $paged = 1 ) {

		$args = array(
			'post_type'      => 'kaamase_job',
			'post_status'    => 'kaamase_closed',
			'posts_per_page' => KAAMASE_PAST_PER_PAGE,
			'paged'          => max( 1, (int) $paged ),
			'orderby'        => 'modified',
			'order'          => 'DESC',
			'tax_query'      => array(), // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_tax_query
		);

		if ( $trade ) {
			$args['tax_query'][] = array(
				'taxonomy' => 'kaamase_trade',
				'field'    => 'slug',
				'terms'    => $trade,
			);
		}

		if ( $district ) {
			$args['tax_query'][] = array(
				'taxonomy' => 'kaamase_district',
				'field'    => 'slug',
				'terms'    => $district,
			);
		}

		return new WP_Query( $args );
	}
}

if ( ! function_exists( 'kaamase_past_jobs_filters' ) ) {
	/**
	 * The trade and district pickers.
	 *
	 * A plain form with no script behind it, because the people using
	 * this site are on cheap phones over patchy data and a filter that
	 * needs JavaScript to work is a filter that sometimes does not.
	 *
	 * @since 1.0.0
	 * @param string $trade    Current trade slug.
	 * @param string $district Current district slug.
	 * @return string Markup.
	 */
	function kaamase_past_jobs_filters( $trade, $district ) {

		$trades    = function_exists( 'kaamase_trade_choices' ) ? kaamase_trade_choices() : array();
		$districts = function_exists( 'kaamase_district_choices' ) ? kaamase_district_choices() : array();

		ob_start();
		?>
		<form class="ka-form ka-cluster ka-mb-6" method="get" action="<?php echo esc_url( kaamase_past_jobs_self_url() ); ?>">

			<label class="ka-sr-only" for="ka-past-trade"><?php esc_html_e( 'Trade', 'kaamase-core' ); ?></label>
			<select class="ka-input" id="ka-past-trade" name="ka_trade">
				<option value=""><?php esc_html_e( 'Any trade', 'kaamase-core' ); ?></option>
				<?php foreach ( $trades as $group => $items ) : ?>
					<optgroup label="<?php echo esc_attr( $group ); ?>">
						<?php foreach ( $items as $slug => $name ) : ?>
							<option value="<?php echo esc_attr( $slug ); ?>" <?php selected( $trade, $slug ); ?>>
								<?php echo esc_html( $name ); ?>
							</option>
						<?php endforeach; ?>
					</optgroup>
				<?php endforeach; ?>
			</select>

			<label class="ka-sr-only" for="ka-past-district"><?php esc_html_e( 'District', 'kaamase-core' ); ?></label>
			<select class="ka-input" id="ka-past-district" name="ka_district">
				<option value=""><?php esc_html_e( 'Any district', 'kaamase-core' ); ?></option>
				<?php foreach ( $districts as $slug => $name ) : ?>
					<option value="<?php echo esc_attr( $slug ); ?>" <?php selected( $district, $slug ); ?>>
						<?php echo esc_html( $name ); ?>
					</option>
				<?php endforeach; ?>
			</select>

			<button class="ka-btn ka-btn--outline" type="submit"><?php esc_html_e( 'Show', 'kaamase-core' ); ?></button>

		</form>
		<?php

		return (string) ob_get_clean();
	}
}

if ( ! function_exists( 'kaamase_past_jobs_row' ) ) {
	/**
	 * One line in the list.
	 *
	 * @since 1.0.0
	 * @param int $job_id Job ID.
	 * @return string Markup.
	 */
	function kaamase_past_jobs_row( $job_id ) {

		$bits = array();

		$district = (string) kaamase_read_field( $job_id, 'district' );
		$town     = (string) kaamase_read_field( $job_id, 'town' );

		if ( $district && function_exists( 'kaamase_district_name' ) ) {
			$bits[] = $town ? $town . ', ' . kaamase_district_name( $district ) : kaamase_district_name( $district );
		} elseif ( $town ) {
			$bits[] = $town;
		}

		$closed = kaamase_past_jobs_closed_at( $job_id );

		if ( $closed ) {
			$bits[] = sprintf(
				/* translators: %s: a date */
				__( 'Closed %s', 'kaamase-core' ),
				date_i18n( get_option( 'date_format' ), $closed )
			);
		}

		return sprintf(
			'<li class="ka-past__item"><a href="%1$s">%2$s</a>%3$s</li>',
			esc_url( (string) get_permalink( $job_id ) ),
			esc_html( get_the_title( $job_id ) ),
			$bits ? '<span class="ka-past__meta">' . esc_html( implode( ' . ', $bits ) ) . '</span>' : ''
		);
	}
}

if ( ! function_exists( 'kaamase_past_jobs_shortcode' ) ) {
	/**
	 * The archive.
	 *
	 * @since 1.0.0
	 * @return string Markup.
	 */
	function kaamase_past_jobs_shortcode() {

		// phpcs:disable WordPress.Security.NonceVerification.Recommended -- A public list with public filters.
		$trade    = isset( $_GET['ka_trade'] ) ? sanitize_key( wp_unslash( $_GET['ka_trade'] ) ) : '';
		$district = isset( $_GET['ka_district'] ) ? sanitize_key( wp_unslash( $_GET['ka_district'] ) ) : '';
		$paged    = isset( $_GET['ka_page'] ) ? max( 1, absint( $_GET['ka_page'] ) ) : 1;
		// phpcs:enable WordPress.Security.NonceVerification.Recommended

		$found = kaamase_past_jobs_query( $trade, $district, $paged );

		ob_start();

		echo kaamase_past_jobs_styles(); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped

		echo kaamase_past_jobs_filters( $trade, $district ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped

		if ( ! $found->have_posts() ) {

			echo '<p class="ka-soft">' . esc_html__( 'No closed jobs match that yet.', 'kaamase-core' ) . '</p>';

		} else {

			echo '<ul class="ka-past">';

			foreach ( $found->posts as $job ) {
				echo kaamase_past_jobs_row( $job->ID ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
			}

			echo '</ul>';

			echo kaamase_past_jobs_paging( $found, $trade, $district, $paged ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
		}

		wp_reset_postdata();

		return (string) ob_get_clean();
	}
}
add_shortcode( 'kaamase_past_jobs', 'kaamase_past_jobs_shortcode' );

if ( ! function_exists( 'kaamase_past_jobs_paging' ) ) {
	/**
	 * Previous and next.
	 *
	 * Two links rather than a numbered row. A crawler needs a path
	 * through every page and a person needs to not be shown forty
	 * numbers, and two links satisfy both.
	 *
	 * @since 1.0.0
	 * @param WP_Query $found    The results.
	 * @param string   $trade    Current trade.
	 * @param string   $district Current district.
	 * @param int      $paged    Current page.
	 * @return string Markup.
	 */
	function kaamase_past_jobs_paging( $found, $trade, $district, $paged ) {

		$pages = (int) $found->max_num_pages;

		if ( $pages < 2 ) {
			return '';
		}

		$base = array();

		if ( $trade ) {
			$base['ka_trade'] = $trade;
		}

		if ( $district ) {
			$base['ka_district'] = $district;
		}

		$out = '<nav class="ka-cluster ka-mt-6">';

		if ( $paged > 1 ) {
			$out .= sprintf(
				'<a class="ka-btn ka-btn--outline ka-btn--sm" href="%1$s">%2$s</a>',
				esc_url( kaamase_past_jobs_self_url( array_merge( $base, array( 'ka_page' => $paged - 1 ) ) ) ),
				esc_html__( 'Newer', 'kaamase-core' )
			);
		}

		if ( $paged < $pages ) {
			$out .= sprintf(
				'<a class="ka-btn ka-btn--outline ka-btn--sm" href="%1$s">%2$s</a>',
				esc_url( kaamase_past_jobs_self_url( array_merge( $base, array( 'ka_page' => $paged + 1 ) ) ) ),
				esc_html__( 'Older', 'kaamase-core' )
			);
		}

		$out .= sprintf(
			'<span class="ka-past__meta">%s</span>',
			esc_html(
				sprintf(
					/* translators: 1: current page, 2: how many pages */
					__( 'Page %1$s of %2$s', 'kaamase-core' ),
					number_format_i18n( $paged ),
					number_format_i18n( $pages )
				)
			)
		);

		return $out . '</nav>';
	}
}

if ( ! function_exists( 'kaamase_past_jobs_styles' ) ) {
	/**
	 * The few rules the list needs.
	 *
	 * @since 1.0.0
	 * @return string
	 */
	function kaamase_past_jobs_styles() {

		return '<style id="kaamase-past-jobs">'
			. '.ka-past{list-style:none;margin:0;padding:0}'
			. '.ka-past__item{padding:.75rem 0;border-bottom:1px solid rgba(0,0,0,.08)}'
			. '.ka-past__item a{display:block;font-weight:600}'
			. '.ka-past__meta{display:block;font-size:.875rem;opacity:.7}'
			. '</style>';
	}
}


/* ==========================================================================
   3. LINKS OUT OF A CLOSED JOB

   The half that actually stops the orphaning. The archive gives every
   closed job one link in. These give each of them links across, so a
   crawler that reaches one reaches its neighbours without walking forty
   pages of a list to get there.
   ========================================================================== */

if ( ! function_exists( 'kaamase_past_jobs_closed_at' ) ) {
	/**
	 * Roughly when a job closed.
	 *
	 * The expiry date when there is one, since that is the day the work
	 * actually went. Otherwise the last time the record was touched,
	 * which for a job somebody marked as filled is the same moment.
	 *
	 * @since 1.0.0
	 * @param int $job_id Job ID.
	 * @return int Timestamp, or 0.
	 */
	function kaamase_past_jobs_closed_at( $job_id ) {

		$expires = (int) get_post_meta( $job_id, KAAMASE_META_PREFIX . 'expires', true );

		if ( $expires ) {
			return $expires;
		}

		$modified = get_post_field( 'post_modified_gmt', $job_id );

		return $modified ? (int) strtotime( $modified . ' UTC' ) : 0;
	}
}

if ( ! function_exists( 'kaamase_past_jobs_related' ) ) {
	/**
	 * Other closed jobs in the same trade.
	 *
	 * @since 1.0.0
	 * @param int $job_id Job to find neighbours for.
	 * @param int $limit  How many.
	 * @return int[] Job IDs.
	 */
	function kaamase_past_jobs_related( $job_id, $limit = 5 ) {

		$terms = get_the_terms( $job_id, 'kaamase_trade' );

		if ( ! $terms || is_wp_error( $terms ) ) {
			return array();
		}

		$found = get_posts(
			array(
				'post_type'        => 'kaamase_job',
				'post_status'      => 'kaamase_closed',
				'posts_per_page'   => absint( $limit ),
				'post__not_in'     => array( (int) $job_id ),
				'orderby'          => 'modified',
				'order'            => 'DESC',
				'fields'           => 'ids',
				'no_found_rows'    => true,
				'suppress_filters' => false,
				// phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_tax_query
				'tax_query'        => array(
					array(
						'taxonomy' => 'kaamase_trade',
						'field'    => 'slug',
						'terms'    => $terms[0]->slug,
					),
				),
			)
		);

		return is_array( $found ) ? array_map( 'absint', $found ) : array();
	}
}

if ( ! function_exists( 'kaamase_past_jobs_footer' ) ) {
	/**
	 * Put the neighbours at the bottom of a closed job.
	 *
	 * Appended rather than prepended. Somebody reading a closed job page
	 * wants to know what it was before they want to know what else is
	 * near it.
	 *
	 * @since 1.0.0
	 * @param string $content The job description.
	 * @return string
	 */
	function kaamase_past_jobs_footer( $content ) {

		if ( ! is_singular( 'kaamase_job' ) || ! in_the_loop() || ! is_main_query() ) {
			return $content;
		}

		$job_id = get_the_ID();

		if ( ! function_exists( 'kaamase_job_is_open' ) || kaamase_job_is_open( $job_id ) ) {
			return $content;
		}

		$related = kaamase_past_jobs_related( $job_id );
		$archive = kaamase_past_jobs_url();

		if ( empty( $related ) && ! $archive ) {
			return $content;
		}

		$out = '<div class="ka-card ka-card--pad ka-mt-6">';

		if ( $related ) {

			$out .= '<h2 class="ka-h4">' . esc_html__( 'Other past jobs like this', 'kaamase-core' ) . '</h2>';
			$out .= kaamase_past_jobs_styles() . '<ul class="ka-past">';

			foreach ( $related as $other ) {
				$out .= kaamase_past_jobs_row( $other );
			}

			$out .= '</ul>';
		}

		if ( $archive ) {
			$out .= sprintf(
				'<p class="ka-mt-4"><a class="ka-btn ka-btn--ghost ka-btn--sm" href="%1$s">%2$s</a></p>',
				esc_url( $archive ),
				esc_html__( 'Browse all past jobs', 'kaamase-core' )
			);
		}

		return $content . $out . '</div>';
	}
}
add_filter( 'the_content', 'kaamase_past_jobs_footer', 14 );


/* ==========================================================================
   4. WHAT SEARCH ENGINES ARE TOLD
   ========================================================================== */

if ( ! function_exists( 'kaamase_past_jobs_robots' ) ) {
	/**
	 * Keep the hub out of search, and age old jobs out of it.
	 *
	 * Both cases are noindex with follow left on, which is the whole
	 * point. A crawler still walks every link on the page and still
	 * reaches everything the page points at. It just does not offer this
	 * particular page to anybody as an answer.
	 *
	 * @since 1.0.0
	 * @param array $robots Directives.
	 * @return array
	 */
	function kaamase_past_jobs_robots( $robots ) {

		if ( is_page() && kaamase_past_jobs_page_id() === (int) get_queried_object_id() ) {

			$robots['noindex'] = true;
			$robots['follow']  = true;

			return $robots;
		}

		if ( ! is_singular( 'kaamase_job' ) ) {
			return $robots;
		}

		$months = kaamase_past_jobs_months();

		if ( ! $months ) {
			return $robots;
		}

		$job_id = (int) get_queried_object_id();

		if ( ! function_exists( 'kaamase_job_is_open' ) || kaamase_job_is_open( $job_id ) ) {
			return $robots;
		}

		$closed = kaamase_past_jobs_closed_at( $job_id );

		if ( $closed && $closed < strtotime( '-' . $months . ' months' ) ) {
			$robots['noindex'] = true;
			$robots['follow']  = true;
		}

		return $robots;
	}
}
add_filter( 'wp_robots', 'kaamase_past_jobs_robots' );