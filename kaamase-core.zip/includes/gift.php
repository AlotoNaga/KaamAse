<?php
/**
 * Gifts.
 *
 * Giving somebody the paid plan, and the tick, without money changing
 * hands.
 *
 * Why this is a separate file
 * --------------------------
 * rich-manu.php holds one rule: paying does not give the tick, the call
 * does. That rule is about buyers. It says nothing about people the
 * owner already knows personally, and until now there was no way to
 * hand one of them the plan short of taking their money and refunding
 * it.
 *
 * There is a second reason. The tick can already be set by hand from the
 * user record, but it only SHOWS while a plan is running, so ticking the
 * box on somebody who never paid appears to do nothing at all. That
 * looks like a bug and is not one. A gift needs both halves, and this
 * file is where the two are done together.
 *
 * What a gift is not
 * ------------------
 * It is not a different tick. The mark a friend gets here is the same
 * mark a payer gets, and it means the same thing: somebody at Kaam Ase
 * knows who this person is. Give it to people that is true of. A tick
 * handed round to whoever asks is worth exactly nothing to the worker
 * reading it, and that worker is the only reason the mark exists.
 *
 * Nothing here touches ranking. A gift raises nobody in search.
 *
 * @package KaamaseCore
 * @version 1.0.0
 * @since   1.0.0
 */

defined( 'ABSPATH' ) || exit;


/** When the gift was given. Its presence is what makes it a gift. */
define( 'KAAMASE_GIFT_AT_KEY', '_kaamase_gift_at' );

/** Who gave it, so a decision has a name against it. */
define( 'KAAMASE_GIFT_BY_KEY', '_kaamase_gift_by' );

/** Why it was given. */
define( 'KAAMASE_GIFT_NOTE_KEY', '_kaamase_gift_note' );


/* ==========================================================================
   1. WHAT IS AVAILABLE
   ========================================================================== */

if ( ! function_exists( 'kaamase_gift_pay_ready' ) ) {
	/**
	 * Whether the payment plugin is here to hold the access dates.
	 *
	 * With it switched off, a gift is just the tick, which is correct:
	 * with no payment plugin the mark shows on its own.
	 *
	 * @since 1.0.0
	 * @return bool
	 */
	function kaamase_gift_pay_ready() {

		return function_exists( 'kaamase_pay_plans' )
			&& defined( 'KAAMASE_PAY_EXPIRES_KEY' )
			&& defined( 'KAAMASE_PAY_PLAN_KEY' );
	}
}

if ( ! function_exists( 'kaamase_gift_lengths' ) ) {
	/**
	 * How long a gift can run for.
	 *
	 * @since 1.0.0
	 * @return array Days keyed by form value.
	 */
	function kaamase_gift_lengths() {

		return array(
			'month'   => array(
				'days'  => 30,
				'label' => __( 'One month', 'kaamase-core' ),
			),
			'quarter' => array(
				'days'  => 90,
				'label' => __( 'Three months', 'kaamase-core' ),
			),
			'year'    => array(
				'days'  => 365,
				'label' => __( 'One year', 'kaamase-core' ),
			),
			'forever' => array(
				'days'  => 36500,
				'label' => __( 'Forever', 'kaamase-core' ),
			),
		);
	}
}

if ( ! function_exists( 'kaamase_gift_find_user' ) ) {
	/**
	 * Find somebody from whatever the owner typed.
	 *
	 * Email, username or user ID, because remembering which one a
	 * platform wants is a small tax on every single use.
	 *
	 * @since 1.0.0
	 * @param string $needle What was typed.
	 * @return WP_User|null
	 */
	function kaamase_gift_find_user( $needle ) {

		$needle = trim( (string) $needle );

		if ( '' === $needle ) {
			return null;
		}

		if ( ctype_digit( $needle ) ) {
			$user = get_user_by( 'id', (int) $needle );

			if ( $user ) {
				return $user;
			}
		}

		if ( is_email( $needle ) ) {
			$user = get_user_by( 'email', $needle );

			if ( $user ) {
				return $user;
			}
		}

		$user = get_user_by( 'login', $needle );

		return $user ? $user : null;
	}
}

if ( ! function_exists( 'kaamase_gift_holders' ) ) {
	/**
	 * Everybody currently holding a gift.
	 *
	 * @since 1.0.0
	 * @return WP_User[]
	 */
	function kaamase_gift_holders() {

		$users = get_users(
			array(
				'meta_key' => KAAMASE_GIFT_AT_KEY, // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_key
				'orderby'  => 'meta_value_num',
				'order'    => 'DESC',
				'number'   => 200,
			)
		);

		return is_array( $users ) ? $users : array();
	}
}


/* ==========================================================================
   2. GIVING AND TAKING BACK
   ========================================================================== */

if ( ! function_exists( 'kaamase_gift_give' ) ) {
	/**
	 * Give somebody the plan, and optionally the tick.
	 *
	 * The access dates are written straight onto the account rather than
	 * through the payment plugin's grant function. That function is for
	 * money arriving: it puts the person in the queue to be rung and
	 * emails them to say a call is coming. Neither is true of a gift,
	 * and an email promising a call that will never come is worse than
	 * no email.
	 *
	 * @since 1.0.0
	 * @param int    $user_id Who is getting it.
	 * @param string $plan_id Which plan to record, when there is one.
	 * @param int    $days    How many days it runs for.
	 * @param bool   $tick    Whether to set the mark too.
	 * @param bool   $tell    Whether to email them about the mark.
	 * @param string $note    Why, for the record.
	 * @return bool
	 */
	function kaamase_gift_give( $user_id, $plan_id, $days, $tick = true, $tell = false, $note = '' ) {

		$user_id = (int) $user_id;
		$days    = max( 1, (int) $days );

		if ( ! $user_id || ! get_userdata( $user_id ) ) {
			return false;
		}

		if ( kaamase_gift_pay_ready() ) {

			$from = max( time(), (int) get_user_meta( $user_id, KAAMASE_PAY_EXPIRES_KEY, true ) );

			update_user_meta( $user_id, KAAMASE_PAY_EXPIRES_KEY, $from + ( $days * DAY_IN_SECONDS ) );

			if ( $plan_id ) {
				update_user_meta( $user_id, KAAMASE_PAY_PLAN_KEY, sanitize_key( $plan_id ) );
			}
		}

		update_user_meta( $user_id, KAAMASE_GIFT_AT_KEY, time() );
		update_user_meta( $user_id, KAAMASE_GIFT_BY_KEY, get_current_user_id() );
		update_user_meta( $user_id, KAAMASE_GIFT_NOTE_KEY, sanitize_textarea_field( (string) $note ) );

		if ( $tick && function_exists( 'kaamase_record_call' ) ) {

			/*
			 * Held quiet unless the owner asked for the email.
			 *
			 * The email that goes with the mark opens by thanking the
			 * person for taking our call. For somebody the owner rang
			 * himself that is fine. For a friend who was simply given
			 * it, it describes something that did not happen.
			 */
			if ( ! $tell ) {
				add_filter( 'pre_wp_mail', '__return_true', 99 );
			}

			kaamase_record_call(
				$user_id,
				$note ? $note : __( 'Given by the owner. No payment taken.', 'kaamase-core' )
			);

			if ( ! $tell ) {
				remove_filter( 'pre_wp_mail', '__return_true', 99 );
			}
		}

		/**
		 * Fires after a gift is given.
		 *
		 * @since 1.0.0
		 * @param int $user_id Who got it.
		 * @param int $days    How long it runs.
		 */
		do_action( 'kaamase_gift_given', $user_id, $days );

		return true;
	}
}

if ( ! function_exists( 'kaamase_gift_take_back' ) ) {
	/**
	 * Take a gift back.
	 *
	 * Only ever touches the access dates when there is no subscription
	 * on the account. Somebody who was given three months and then
	 * started paying properly must not lose what they paid for because
	 * the gift was tidied up afterwards.
	 *
	 * @since 1.0.0
	 * @param int $user_id User ID.
	 * @return void
	 */
	function kaamase_gift_take_back( $user_id ) {

		$user_id = (int) $user_id;

		if ( ! $user_id || ! get_user_meta( $user_id, KAAMASE_GIFT_AT_KEY, true ) ) {
			return;
		}

		$paying = defined( 'KAAMASE_PAY_SUB_KEY' )
			&& get_user_meta( $user_id, KAAMASE_PAY_SUB_KEY, true );

		if ( kaamase_gift_pay_ready() && ! $paying ) {
			delete_user_meta( $user_id, KAAMASE_PAY_EXPIRES_KEY );
			delete_user_meta( $user_id, KAAMASE_PAY_PLAN_KEY );
		}

		if ( ! $paying && function_exists( 'kaamase_undo_call' ) ) {
			kaamase_undo_call( $user_id );
		}

		delete_user_meta( $user_id, KAAMASE_GIFT_AT_KEY );
		delete_user_meta( $user_id, KAAMASE_GIFT_BY_KEY );
		delete_user_meta( $user_id, KAAMASE_GIFT_NOTE_KEY );

		/**
		 * Fires after a gift is taken back.
		 *
		 * @since 1.0.0
		 * @param int $user_id User ID.
		 */
		do_action( 'kaamase_gift_taken_back', $user_id );
	}
}


/* ==========================================================================
   3. THE SCREEN
   ========================================================================== */

if ( ! function_exists( 'kaamase_gift_menu' ) ) {
	/**
	 * Add the gift screen under Kaam Ase.
	 *
	 * @since 1.0.0
	 * @return void
	 */
	function kaamase_gift_menu() {

		add_submenu_page(
			'kaamase',
			__( 'Give the plan', 'kaamase-core' ),
			__( 'Give the plan', 'kaamase-core' ),
			'promote_users',
			'kaamase-gift',
			'kaamase_gift_page'
		);
	}
}
add_action( 'admin_menu', 'kaamase_gift_menu', 21 );

if ( ! function_exists( 'kaamase_gift_page' ) ) {
	/**
	 * Render the gift screen.
	 *
	 * @since 1.0.0
	 * @return void
	 */
	function kaamase_gift_page() {

		if ( ! current_user_can( 'promote_users' ) ) {
			return;
		}

		// phpcs:disable WordPress.Security.NonceVerification.Recommended -- Read only notice.
		$done   = isset( $_GET['given'] ) ? sanitize_key( wp_unslash( $_GET['given'] ) ) : '';
		$failed = isset( $_GET['failed'] ) ? sanitize_key( wp_unslash( $_GET['failed'] ) ) : '';
		// phpcs:enable WordPress.Security.NonceVerification.Recommended

		$plans = kaamase_gift_pay_ready() ? kaamase_pay_plans() : array();
		?>
		<div class="wrap">

			<h1><?php esc_html_e( 'Give the plan', 'kaamase-core' ); ?></h1>

			<?php if ( 'yes' === $done ) : ?>
				<div class="notice notice-success is-dismissible">
					<p><?php esc_html_e( 'Done. Their account has it now.', 'kaamase-core' ); ?></p>
				</div>
			<?php elseif ( 'removed' === $done ) : ?>
				<div class="notice notice-success is-dismissible">
					<p><?php esc_html_e( 'Taken back.', 'kaamase-core' ); ?></p>
				</div>
			<?php endif; ?>

			<?php if ( 'nouser' === $failed ) : ?>
				<div class="notice notice-error is-dismissible">
					<p><?php esc_html_e( 'No account matched that. Try their email address.', 'kaamase-core' ); ?></p>
				</div>
			<?php endif; ?>

			<p style="max-width:45em">
				<?php esc_html_e( 'Gives somebody the paid plan and the tick without taking any money. The tick means somebody at Kaam Ase knows who this person is, so give it to people that is true of.', 'kaamase-core' ); ?>
			</p>

			<?php if ( kaamase_gift_pay_ready() && empty( $plans ) ) : ?>
				<div class="notice notice-warning">
					<p><?php esc_html_e( 'There are no plans set up yet. Make one on the Plans screen first, otherwise the app will not show the plan as running.', 'kaamase-core' ); ?></p>
				</div>
			<?php endif; ?>

			<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">

				<input type="hidden" name="action" value="kaamase_gift">
				<?php wp_nonce_field( 'kaamase_gift' ); ?>

				<table class="form-table" role="presentation">

					<tr>
						<th scope="row">
							<label for="kaamase-gift-who"><?php esc_html_e( 'Who', 'kaamase-core' ); ?></label>
						</th>
						<td>
							<input class="regular-text" type="text" id="kaamase-gift-who" name="kaamase_who" required
								placeholder="<?php esc_attr_e( 'Email address, username or user ID', 'kaamase-core' ); ?>">
						</td>
					</tr>

					<?php if ( ! empty( $plans ) ) : ?>
						<tr>
							<th scope="row">
								<label for="kaamase-gift-plan"><?php esc_html_e( 'Plan to record', 'kaamase-core' ); ?></label>
							</th>
							<td>
								<select id="kaamase-gift-plan" name="kaamase_plan">
									<?php foreach ( $plans as $plan_id => $plan ) : ?>
										<option value="<?php echo esc_attr( $plan_id ); ?>">
											<?php echo esc_html( isset( $plan['name'] ) ? $plan['name'] : $plan_id ); ?>
										</option>
									<?php endforeach; ?>
								</select>
								<p class="description">
									<?php esc_html_e( 'Which plan their account will say they are on. Nothing is charged.', 'kaamase-core' ); ?>
								</p>
							</td>
						</tr>
					<?php endif; ?>

					<tr>
						<th scope="row">
							<label for="kaamase-gift-length"><?php esc_html_e( 'How long', 'kaamase-core' ); ?></label>
						</th>
						<td>
							<select id="kaamase-gift-length" name="kaamase_length">
								<?php foreach ( kaamase_gift_lengths() as $key => $length ) : ?>
									<option value="<?php echo esc_attr( $key ); ?>" <?php selected( 'year', $key ); ?>>
										<?php echo esc_html( $length['label'] ); ?>
									</option>
								<?php endforeach; ?>
							</select>
							<p class="description">
								<?php esc_html_e( 'Added on top of anything already running on their account.', 'kaamase-core' ); ?>
							</p>
						</td>
					</tr>

					<tr>
						<th scope="row"><?php esc_html_e( 'The tick', 'kaamase-core' ); ?></th>
						<td>
							<label>
								<input type="checkbox" name="kaamase_tick" value="1" checked>
								<?php esc_html_e( 'Put the tick on their profile', 'kaamase-core' ); ?>
							</label>
							<p>
								<label>
									<input type="checkbox" name="kaamase_tell" value="1">
									<?php esc_html_e( 'Email them about it', 'kaamase-core' ); ?>
								</label>
							</p>
							<p class="description">
								<?php esc_html_e( 'The email thanks them for taking our call, so leave it off unless you actually rang them.', 'kaamase-core' ); ?>
							</p>
						</td>
					</tr>

					<tr>
						<th scope="row">
							<label for="kaamase-gift-note"><?php esc_html_e( 'Note', 'kaamase-core' ); ?></label>
						</th>
						<td>
							<textarea class="large-text" id="kaamase-gift-note" name="kaamase_note" rows="2"
								placeholder="<?php esc_attr_e( 'Why they were given it. Only you see this.', 'kaamase-core' ); ?>"></textarea>
						</td>
					</tr>

				</table>

				<?php submit_button( __( 'Give it', 'kaamase-core' ) ); ?>

			</form>

			<h2><?php esc_html_e( 'Given so far', 'kaamase-core' ); ?></h2>

			<?php $holders = kaamase_gift_holders(); ?>

			<?php if ( empty( $holders ) ) : ?>

				<p><?php esc_html_e( 'Nobody yet.', 'kaamase-core' ); ?></p>

			<?php else : ?>

				<table class="widefat striped">
					<thead>
						<tr>
							<th><?php esc_html_e( 'Who', 'kaamase-core' ); ?></th>
							<th><?php esc_html_e( 'Given', 'kaamase-core' ); ?></th>
							<th><?php esc_html_e( 'Runs until', 'kaamase-core' ); ?></th>
							<th><?php esc_html_e( 'Tick', 'kaamase-core' ); ?></th>
							<th><?php esc_html_e( 'Note', 'kaamase-core' ); ?></th>
							<th></th>
						</tr>
					</thead>
					<tbody>
						<?php foreach ( $holders as $holder ) : ?>
							<?php
							$given   = (int) get_user_meta( $holder->ID, KAAMASE_GIFT_AT_KEY, true );
							$expires = defined( 'KAAMASE_PAY_EXPIRES_KEY' )
								? (int) get_user_meta( $holder->ID, KAAMASE_PAY_EXPIRES_KEY, true )
								: 0;
							$ticked  = function_exists( 'kaamase_has_been_called' )
								&& kaamase_has_been_called( $holder->ID );
							?>
							<tr>
								<td>
									<a href="<?php echo esc_url( get_edit_user_link( $holder->ID ) ); ?>">
										<?php echo esc_html( $holder->display_name ); ?>
									</a>
									<br><span class="description"><?php echo esc_html( $holder->user_email ); ?></span>
								</td>
								<td><?php echo esc_html( $given ? date_i18n( get_option( 'date_format' ), $given ) : '' ); ?></td>
								<td>
									<?php
									echo esc_html(
										$expires
											? date_i18n( get_option( 'date_format' ), $expires )
											: __( 'No end date', 'kaamase-core' )
									);
									?>
								</td>
								<td><?php echo $ticked ? esc_html__( 'Yes', 'kaamase-core' ) : esc_html__( 'No', 'kaamase-core' ); ?></td>
								<td><?php echo esc_html( (string) get_user_meta( $holder->ID, KAAMASE_GIFT_NOTE_KEY, true ) ); ?></td>
								<td>
									<a class="button button-small"
										href="<?php echo esc_url( wp_nonce_url( admin_url( 'admin-post.php?action=kaamase_gift_undo&user=' . $holder->ID ), 'kaamase_gift_undo_' . $holder->ID ) ); ?>">
										<?php esc_html_e( 'Take it back', 'kaamase-core' ); ?>
									</a>
								</td>
							</tr>
						<?php endforeach; ?>
					</tbody>
				</table>

			<?php endif; ?>

		</div>
		<?php
	}
}


/* ==========================================================================
   4. HANDLING THE FORM
   ========================================================================== */

if ( ! function_exists( 'kaamase_gift_handle' ) ) {
	/**
	 * Give the gift.
	 *
	 * @since 1.0.0
	 * @return void
	 */
	function kaamase_gift_handle() {

		if ( ! current_user_can( 'promote_users' ) ) {
			wp_die( esc_html__( 'You cannot do that.', 'kaamase-core' ) );
		}

		check_admin_referer( 'kaamase_gift' );

		$who     = isset( $_POST['kaamase_who'] ) ? sanitize_text_field( wp_unslash( $_POST['kaamase_who'] ) ) : '';
		$plan_id = isset( $_POST['kaamase_plan'] ) ? sanitize_key( wp_unslash( $_POST['kaamase_plan'] ) ) : '';
		$length  = isset( $_POST['kaamase_length'] ) ? sanitize_key( wp_unslash( $_POST['kaamase_length'] ) ) : 'year';
		$note    = isset( $_POST['kaamase_note'] ) ? sanitize_textarea_field( wp_unslash( $_POST['kaamase_note'] ) ) : '';
		$tick    = ! empty( $_POST['kaamase_tick'] );
		$tell    = ! empty( $_POST['kaamase_tell'] );

		$user = kaamase_gift_find_user( $who );

		if ( ! $user ) {
			wp_safe_redirect( admin_url( 'admin.php?page=kaamase-gift&failed=nouser' ) );
			exit;
		}

		$lengths = kaamase_gift_lengths();
		$days    = isset( $lengths[ $length ] ) ? (int) $lengths[ $length ]['days'] : 365;

		kaamase_gift_give( $user->ID, $plan_id, $days, $tick, $tell, $note );

		wp_safe_redirect( admin_url( 'admin.php?page=kaamase-gift&given=yes' ) );
		exit;
	}
}
add_action( 'admin_post_kaamase_gift', 'kaamase_gift_handle' );

if ( ! function_exists( 'kaamase_gift_handle_undo' ) ) {
	/**
	 * Take a gift back.
	 *
	 * @since 1.0.0
	 * @return void
	 */
	function kaamase_gift_handle_undo() {

		if ( ! current_user_can( 'promote_users' ) ) {
			wp_die( esc_html__( 'You cannot do that.', 'kaamase-core' ) );
		}

		$user_id = isset( $_GET['user'] ) ? absint( $_GET['user'] ) : 0;

		check_admin_referer( 'kaamase_gift_undo_' . $user_id );

		if ( $user_id ) {
			kaamase_gift_take_back( $user_id );
		}

		wp_safe_redirect( admin_url( 'admin.php?page=kaamase-gift&given=removed' ) );
		exit;
	}
}
add_action( 'admin_post_kaamase_gift_undo', 'kaamase_gift_handle_undo' );