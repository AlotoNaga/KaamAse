<?php
/**
 * Email check.
 *
 * Whether the mail this site sends is actually going anywhere.
 *
 * Why this exists
 * ---------------
 * Every account here waits on an email. The profile stays hidden until
 * somebody taps a link, so a confirmation that never arrives is not a
 * minor annoyance, it is a person who signed up and then vanished.
 *
 * WordPress makes this failure completely silent. wp_mail returns true
 * or false and nothing in this plugin looks at the answer, so a site
 * whose mail is being refused outright behaves exactly like a site whose
 * users cannot be bothered. The two need entirely different fixes and
 * there was no way to tell them apart.
 *
 * This records every send and its result, and gives one button that
 * tries a real email and reports what actually happened, including the
 * error text the mail server sent back.
 *
 * And the fix
 * -----------
 * The answer here turned out to be that the host refuses to send at all:
 * PHP's own mail function is switched off, which shared hosts routinely
 * do, and every message had been rejected before it left the building.
 *
 * So this file now also sends. Mail goes out through a real mailbox on
 * the domain, authenticated, the way the host requires and the way Gmail
 * expects. Kept here rather than added as a separate plugin because the
 * test button that proves it works is already on this screen, and
 * because one more plugin is one more thing that can be deactivated by
 * somebody tidying up.
 *
 * The log holds addresses, so it is capped, it expires by itself after a
 * week, and there is a button to empty it. A debugging tool that quietly
 * accumulates everybody's email address forever is its own problem.
 *
 * @package KaamaseCore
 * @version 1.1.0
 * @since   1.0.0
 */

defined( 'ABSPATH' ) || exit;


/** Where the recent sends are kept. */
define( 'KAAMASE_MAIL_LOG_OPTION', 'kaamase_mail_log' );

/** How many are kept. */
define( 'KAAMASE_MAIL_LOG_MAX', 50 );

/** How long an entry lives. */
define( 'KAAMASE_MAIL_LOG_DAYS', 7 );


/* ==========================================================================
   1. WATCHING EVERY SEND
   ========================================================================== */

if ( ! function_exists( 'kaamase_mail_log' ) ) {
	/**
	 * The recent sends, newest first, with anything stale dropped.
	 *
	 * @since 1.0.0
	 * @return array[]
	 */
	function kaamase_mail_log() {

		$log   = (array) get_option( KAAMASE_MAIL_LOG_OPTION, array() );
		$since = time() - ( KAAMASE_MAIL_LOG_DAYS * DAY_IN_SECONDS );
		$live  = array();

		foreach ( $log as $row ) {
			if ( ! empty( $row['when'] ) && (int) $row['when'] > $since ) {
				$live[] = $row;
			}
		}

		return $live;
	}
}

if ( ! function_exists( 'kaamase_mail_note' ) ) {
	/**
	 * Write down one send.
	 *
	 * @since 1.0.0
	 * @param string $to      Who it was for.
	 * @param string $subject What it said.
	 * @param string $result  sent, refused, or the error.
	 * @return void
	 */
	function kaamase_mail_note( $to, $subject, $result ) {

		$log = kaamase_mail_log();

		array_unshift(
			$log,
			array(
				'when'    => time(),
				'to'      => sanitize_text_field( (string) $to ),
				'subject' => sanitize_text_field( (string) $subject ),
				'result'  => sanitize_text_field( (string) $result ),
			)
		);

		update_option( KAAMASE_MAIL_LOG_OPTION, array_slice( $log, 0, KAAMASE_MAIL_LOG_MAX ), false );
	}
}

if ( ! function_exists( 'kaamase_mail_watch' ) ) {
	/**
	 * Note that a send was attempted.
	 *
	 * Hooked to the filter that runs on the way out. Something recorded
	 * here and never followed by a failure is a message the server
	 * accepted, which is not the same as a message that arrived, and the
	 * screen says so plainly.
	 *
	 * @since 1.0.0
	 * @param array $args The mail arguments.
	 * @return array Unchanged.
	 */
	function kaamase_mail_watch( $args ) {

		$to = $args['to'] ?? '';

		kaamase_mail_note(
			is_array( $to ) ? implode( ', ', $to ) : $to,
			$args['subject'] ?? '',
			'accepted'
		);

		return $args;
	}
}
add_filter( 'wp_mail', 'kaamase_mail_watch', 99 );

if ( ! function_exists( 'kaamase_mail_failed' ) ) {
	/**
	 * Record a refusal, with whatever the server said.
	 *
	 * The newest entry is corrected rather than a second one added, so
	 * one message is one line and the line says what became of it.
	 *
	 * @since 1.0.0
	 * @param WP_Error $error Why it failed.
	 * @return void
	 */
	function kaamase_mail_failed( $error ) {

		$log = kaamase_mail_log();

		$why = is_wp_error( $error ) ? $error->get_error_message() : __( 'Refused, no reason given.', 'kaamase-core' );

		if ( ! empty( $log[0] ) ) {

			$log[0]['result'] = 'refused: ' . $why;

			update_option( KAAMASE_MAIL_LOG_OPTION, array_slice( $log, 0, KAAMASE_MAIL_LOG_MAX ), false );

			return;
		}

		kaamase_mail_note( '', '', 'refused: ' . $why );
	}
}
add_action( 'wp_mail_failed', 'kaamase_mail_failed' );


/* ==========================================================================
   2. SENDING PROPERLY

   Through a mailbox that exists, on the domain the site runs on,
   authenticated. That is what the host demands before it will carry
   anything, and separately it is what lets Gmail see the message as
   coming from where it claims to.

   The from address is forced to the mailbox that did the authenticating.
   Sending as one address while logging in as another is refused by most
   mail servers and treated as forgery by the rest, and it is the usual
   reason a setup that looks correct still fails.
   ========================================================================== */

if ( ! function_exists( 'kaamase_smtp_settings' ) ) {
	/**
	 * Register the mailbox details.
	 *
	 * @since 1.1.0
	 * @return void
	 */
	function kaamase_smtp_settings() {

		$text = array(
			'type'              => 'string',
			'sanitize_callback' => 'sanitize_text_field',
			'default'           => '',
		);

		register_setting( 'kaamase_smtp', 'kaamase_smtp_on', array(
			'type'              => 'boolean',
			'sanitize_callback' => 'rest_sanitize_boolean',
			'default'           => false,
		) );

		register_setting( 'kaamase_smtp', 'kaamase_smtp_host', $text );
		register_setting( 'kaamase_smtp', 'kaamase_smtp_user', $text );
		register_setting( 'kaamase_smtp', 'kaamase_smtp_name', $text );
		register_setting( 'kaamase_smtp', 'kaamase_smtp_secure', $text );

		register_setting( 'kaamase_smtp', 'kaamase_smtp_port', array(
			'type'              => 'integer',
			'sanitize_callback' => 'absint',
			'default'           => 465,
		) );

		register_setting( 'kaamase_smtp', 'kaamase_smtp_pass', array(
			'type'              => 'string',
			'sanitize_callback' => 'kaamase_smtp_keep_pass',
			'default'           => '',
		) );
	}
}
add_action( 'admin_init', 'kaamase_smtp_settings' );

if ( ! function_exists( 'kaamase_smtp_keep_pass' ) ) {
	/**
	 * Keep the stored password when the field was left as it was.
	 *
	 * The screen shows a row of dots rather than the real password, so a
	 * save that comes back with the dots unchanged means nobody retyped
	 * it. Treating that as the new password would wipe a working setup
	 * every time somebody changed the port.
	 *
	 * @since 1.1.0
	 * @param string $raw What was submitted.
	 * @return string
	 */
	function kaamase_smtp_keep_pass( $raw ) {

		$raw = (string) $raw;

		if ( '' === $raw || str_repeat( '*', 12 ) === $raw ) {
			return (string) get_option( 'kaamase_smtp_pass', '' );
		}

		return $raw;
	}
}

if ( ! function_exists( 'kaamase_smtp_ready' ) ) {
	/**
	 * Whether there is enough to send with.
	 *
	 * @since 1.1.0
	 * @return bool
	 */
	function kaamase_smtp_ready() {

		return (bool) get_option( 'kaamase_smtp_on', false )
			&& (string) get_option( 'kaamase_smtp_host', '' )
			&& (string) get_option( 'kaamase_smtp_user', '' )
			&& (string) get_option( 'kaamase_smtp_pass', '' );
	}
}

if ( ! function_exists( 'kaamase_smtp_configure' ) ) {
	/**
	 * Point the mailer at the mailbox.
	 *
	 * @since 1.1.0
	 * @param PHPMailer $mail The mailer.
	 * @return void
	 */
	function kaamase_smtp_configure( $mail ) {

		if ( ! kaamase_smtp_ready() ) {
			return;
		}

		$secure = (string) get_option( 'kaamase_smtp_secure', 'ssl' );

		$mail->isSMTP();
		$mail->Host       = (string) get_option( 'kaamase_smtp_host', '' );
		$mail->Port       = (int) get_option( 'kaamase_smtp_port', 465 );
		$mail->SMTPAuth   = true;
		$mail->Username   = (string) get_option( 'kaamase_smtp_user', '' );
		$mail->Password   = (string) get_option( 'kaamase_smtp_pass', '' );
		$mail->SMTPSecure = ( 'none' === $secure ) ? '' : $secure;
		$mail->SMTPAutoTLS = ( 'none' !== $secure );
		$mail->CharSet    = 'UTF-8';
	}
}
add_action( 'phpmailer_init', 'kaamase_smtp_configure' );

if ( ! function_exists( 'kaamase_smtp_from' ) ) {
	/**
	 * Send as the mailbox that signed in.
	 *
	 * @since 1.1.0
	 * @param string $from The address WordPress chose.
	 * @return string
	 */
	function kaamase_smtp_from( $from ) {

		return kaamase_smtp_ready() ? (string) get_option( 'kaamase_smtp_user', $from ) : $from;
	}
}
add_filter( 'wp_mail_from', 'kaamase_smtp_from', 20 );

if ( ! function_exists( 'kaamase_smtp_from_name' ) ) {
	/**
	 * The name people see it from.
	 *
	 * @since 1.1.0
	 * @param string $name The name WordPress chose.
	 * @return string
	 */
	function kaamase_smtp_from_name( $name ) {

		if ( ! kaamase_smtp_ready() ) {
			return $name;
		}

		$chosen = (string) get_option( 'kaamase_smtp_name', '' );

		return $chosen ? $chosen : $name;
	}
}
add_filter( 'wp_mail_from_name', 'kaamase_smtp_from_name', 20 );


/* ==========================================================================
   3. HOW MANY ARE WAITING
   ========================================================================== */

if ( ! function_exists( 'kaamase_mail_waiting' ) ) {
	/**
	 * Accounts that never confirmed, and how long they have waited.
	 *
	 * The old ones are the number that matters. Somebody who signed up
	 * an hour ago has not failed to confirm, they simply have not got to
	 * it yet. Somebody who signed up a week ago and never did is either
	 * gone or never received anything.
	 *
	 * @since 1.0.0
	 * @return array Total and how many are older than three days.
	 */
	function kaamase_mail_waiting() {

		global $wpdb;

		$rows = $wpdb->get_col( // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
			$wpdb->prepare(
				"SELECT u.user_registered FROM {$wpdb->users} u
				LEFT JOIN {$wpdb->usermeta} m ON m.user_id = u.ID AND m.meta_key = %s
				WHERE m.umeta_id IS NULL",
				'kaamase_verified_at'
			)
		);

		$old   = 0;
		$since = time() - ( 3 * DAY_IN_SECONDS );

		foreach ( (array) $rows as $when ) {

			$stamp = strtotime( (string) $when . ' UTC' );

			if ( $stamp && $stamp < $since ) {
				++$old;
			}
		}

		return array(
			'total' => count( (array) $rows ),
			'old'   => $old,
		);
	}
}


/* ==========================================================================
   4. THE SCREEN
   ========================================================================== */

if ( ! function_exists( 'kaamase_mail_menu' ) ) {
	/**
	 * Add it under Kaam Ase.
	 *
	 * @since 1.0.0
	 * @return void
	 */
	function kaamase_mail_menu() {

		add_submenu_page(
			'kaamase',
			__( 'Email check', 'kaamase-core' ),
			__( 'Email check', 'kaamase-core' ),
			'manage_options',
			'kaamase-email',
			'kaamase_mail_screen'
		);
	}
}
add_action( 'admin_menu', 'kaamase_mail_menu', 28 );

if ( ! function_exists( 'kaamase_mail_sender' ) ) {
	/**
	 * The address WordPress will send from.
	 *
	 * Worth showing. A site sending as wordpress@ at a domain that is
	 * not the one in the address bar is the most common reason Gmail
	 * decides the message is not worth delivering, and nothing anywhere
	 * in wp-admin displays it.
	 *
	 * @since 1.0.0
	 * @return string
	 */
	function kaamase_mail_sender() {

		$host = wp_parse_url( network_home_url(), PHP_URL_HOST );
		$host = preg_replace( '/^www\./i', '', (string) $host );

		return (string) apply_filters( 'wp_mail_from', 'wordpress@' . $host );
	}
}

if ( ! function_exists( 'kaamase_mail_helper_active' ) ) {
	/**
	 * Whether something is handling delivery properly.
	 *
	 * @since 1.0.0
	 * @return string Name, or an empty string.
	 */
	function kaamase_mail_helper_active() {

		$known = array(
			'WPMailSMTP\\Core'       => 'WP Mail SMTP',
			'FluentMail\\Application' => 'FluentSMTP',
			'Post_SMTP'              => 'Post SMTP',
			'PostmanOptions'         => 'Post SMTP',
			'EasyWPSMTP'             => 'Easy WP SMTP',
		);

		foreach ( $known as $class => $name ) {
			if ( class_exists( $class ) ) {
				return $name;
			}
		}

		if ( kaamase_smtp_ready() ) {
			return __( 'This plugin, through your own mailbox', 'kaamase-core' );
		}

		return has_action( 'phpmailer_init' ) ? __( 'Something is configuring the mailer', 'kaamase-core' ) : '';
	}
}

if ( ! function_exists( 'kaamase_mail_screen' ) ) {
	/**
	 * Render the screen.
	 *
	 * @since 1.0.0
	 * @return void
	 */
	function kaamase_mail_screen() {

		if ( ! current_user_can( 'manage_options' ) ) {
			return;
		}

		// phpcs:disable WordPress.Security.NonceVerification.Recommended -- Read only notice.
		$tried  = isset( $_GET['tried'] ) ? sanitize_key( wp_unslash( $_GET['tried'] ) ) : '';
		$reason = isset( $_GET['why'] ) ? sanitize_text_field( wp_unslash( $_GET['why'] ) ) : '';
		// phpcs:enable WordPress.Security.NonceVerification.Recommended

		$waiting = kaamase_mail_waiting();
		$helper  = kaamase_mail_helper_active();
		$log     = kaamase_mail_log();
		?>
		<div class="wrap">

			<h1><?php esc_html_e( 'Email check', 'kaamase-core' ); ?></h1>

			<?php if ( 'yes' === $tried ) : ?>
				<div class="notice notice-success">
					<p><?php esc_html_e( 'The server accepted it. That means it left here. Go and look in the inbox now, and in Spam and Promotions as well. If it is not in any of them within a few minutes, it is being dropped after it leaves.', 'kaamase-core' ); ?></p>
				</div>
			<?php elseif ( 'no' === $tried ) : ?>
				<div class="notice notice-error">
					<p><strong><?php esc_html_e( 'The server refused to send it.', 'kaamase-core' ); ?></strong></p>
					<p><?php echo esc_html( $reason ? $reason : __( 'No reason given.', 'kaamase-core' ) ); ?></p>
					<p><?php esc_html_e( 'This is the answer. Nobody is receiving anything, and no wording or button will change that. It needs a proper sending service configured before anything else is worth trying.', 'kaamase-core' ); ?></p>
				</div>
			<?php endif; ?>

			<h2><?php esc_html_e( 'The mailbox mail goes out through', 'kaamase-core' ); ?></h2>

			<p style="max-width:45em">
				<?php esc_html_e( 'Most hosts will not let a website hand mail straight to the machine it runs on. Sign in to a real mailbox on your own domain instead and it goes out properly, which is also what stops Gmail treating it as forged.', 'kaamase-core' ); ?>
			</p>

			<form method="post" action="options.php">

				<?php settings_fields( 'kaamase_smtp' ); ?>

				<table class="form-table" role="presentation">

					<tr>
						<th scope="row"><?php esc_html_e( 'Use it', 'kaamase-core' ); ?></th>
						<td>
							<label>
								<input type="checkbox" name="kaamase_smtp_on" value="1" <?php checked( (bool) get_option( 'kaamase_smtp_on', false ) ); ?>>
								<?php esc_html_e( 'Send all mail through this mailbox', 'kaamase-core' ); ?>
							</label>
						</td>
					</tr>

					<tr>
						<th scope="row"><label for="ka-smtp-user"><?php esc_html_e( 'Mailbox address', 'kaamase-core' ); ?></label></th>
						<td>
							<input class="regular-text" type="email" id="ka-smtp-user" name="kaamase_smtp_user"
								value="<?php echo esc_attr( (string) get_option( 'kaamase_smtp_user', '' ) ); ?>"
								placeholder="noreply@kaamase.com">
							<p class="description">
								<?php esc_html_e( 'A real mailbox you have created on your own domain. Everything will be sent from this address, so it should be one people could reply to or one that says plainly it is not read.', 'kaamase-core' ); ?>
							</p>
						</td>
					</tr>

					<tr>
						<th scope="row"><label for="ka-smtp-pass"><?php esc_html_e( 'Its password', 'kaamase-core' ); ?></label></th>
						<td>
							<input class="regular-text" type="password" id="ka-smtp-pass" name="kaamase_smtp_pass"
								value="<?php echo esc_attr( get_option( 'kaamase_smtp_pass', '' ) ? str_repeat( '*', 12 ) : '' ); ?>"
								autocomplete="new-password">
							<p class="description">
								<?php esc_html_e( 'The password of that mailbox, not your hosting password and not your WordPress password. Leave the dots alone if you are only changing something else on this screen.', 'kaamase-core' ); ?>
							</p>
						</td>
					</tr>

					<tr>
						<th scope="row"><label for="ka-smtp-host"><?php esc_html_e( 'Server', 'kaamase-core' ); ?></label></th>
						<td>
							<input class="regular-text" type="text" id="ka-smtp-host" name="kaamase_smtp_host"
								value="<?php echo esc_attr( (string) get_option( 'kaamase_smtp_host', '' ) ); ?>"
								placeholder="smtp.hostinger.com">
						</td>
					</tr>

					<tr>
						<th scope="row"><label for="ka-smtp-port"><?php esc_html_e( 'Port', 'kaamase-core' ); ?></label></th>
						<td>
							<input type="number" id="ka-smtp-port" name="kaamase_smtp_port" min="1" max="65535"
								value="<?php echo esc_attr( (string) get_option( 'kaamase_smtp_port', 465 ) ); ?>">

							<select name="kaamase_smtp_secure">
								<?php foreach ( array( 'ssl' => 'SSL', 'tls' => 'TLS', 'none' => __( 'None', 'kaamase-core' ) ) as $key => $label ) : ?>
									<option value="<?php echo esc_attr( $key ); ?>" <?php selected( (string) get_option( 'kaamase_smtp_secure', 'ssl' ), $key ); ?>>
										<?php echo esc_html( $label ); ?>
									</option>
								<?php endforeach; ?>
							</select>

							<p class="description">
								<?php esc_html_e( 'Port 465 with SSL is the usual pair. If that is refused, try 587 with TLS.', 'kaamase-core' ); ?>
							</p>
						</td>
					</tr>

					<tr>
						<th scope="row"><label for="ka-smtp-name"><?php esc_html_e( 'Name people see', 'kaamase-core' ); ?></label></th>
						<td>
							<input class="regular-text" type="text" id="ka-smtp-name" name="kaamase_smtp_name"
								value="<?php echo esc_attr( (string) get_option( 'kaamase_smtp_name', '' ) ); ?>"
								placeholder="Kaam Ase">
						</td>
					</tr>

				</table>

				<?php submit_button( __( 'Save the mailbox', 'kaamase-core' ) ); ?>

			</form>

			<h2><?php esc_html_e( 'Send one now', 'kaamase-core' ); ?></h2>

			<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">

				<input type="hidden" name="action" value="kaamase_mail_test">
				<?php wp_nonce_field( 'kaamase_mail_test' ); ?>

				<p>
					<input class="regular-text" type="email" name="to" required
						value="<?php echo esc_attr( wp_get_current_user()->user_email ); ?>">
					<button class="button button-primary" type="submit"><?php esc_html_e( 'Send a test', 'kaamase-core' ); ?></button>
				</p>

				<p class="description" style="max-width:45em">
					<?php esc_html_e( 'Use an address on Gmail, because that is what most people here use and it is the strictest. If this says refused, the problem is the server. If it says accepted and nothing arrives, the problem is that Gmail is throwing it away, which is a different fix.', 'kaamase-core' ); ?>
				</p>

			</form>

			<h2><?php esc_html_e( 'How things stand', 'kaamase-core' ); ?></h2>

			<table class="widefat striped" style="max-width:46em">
				<tbody>
					<tr>
						<th><?php esc_html_e( 'Accounts that never confirmed', 'kaamase-core' ); ?></th>
						<td><?php echo esc_html( number_format_i18n( $waiting['total'] ) ); ?></td>
					</tr>
					<tr>
						<th><?php esc_html_e( 'Of those, waiting more than three days', 'kaamase-core' ); ?></th>
						<td>
							<?php echo esc_html( number_format_i18n( $waiting['old'] ) ); ?>
							<p class="description"><?php esc_html_e( 'This is the number that matters. Somebody who joined an hour ago has not failed to confirm yet.', 'kaamase-core' ); ?></p>
						</td>
					</tr>
					<tr>
						<th><?php esc_html_e( 'Sending as', 'kaamase-core' ); ?></th>
						<td>
							<code><?php echo esc_html( kaamase_mail_sender() ); ?></code>
							<p class="description"><?php esc_html_e( 'If this is not an address at your own domain, Gmail has good reason to treat it as forged.', 'kaamase-core' ); ?></p>
						</td>
					</tr>
					<tr>
						<th><?php esc_html_e( 'Delivery handled by', 'kaamase-core' ); ?></th>
						<td>
							<?php
							echo $helper
								? esc_html( $helper )
								: esc_html__( 'Nothing. The site is handing mail straight to the server it runs on, which most hosts either refuse or send in a way Gmail distrusts.', 'kaamase-core' );
							?>
						</td>
					</tr>
				</tbody>
			</table>

			<h2><?php esc_html_e( 'Recent messages', 'kaamase-core' ); ?></h2>

			<?php if ( empty( $log ) ) : ?>

				<p><?php esc_html_e( 'Nothing recorded yet. Send a test above, or wait for the next person to sign up.', 'kaamase-core' ); ?></p>

			<?php else : ?>

				<table class="widefat striped">
					<thead>
						<tr>
							<th><?php esc_html_e( 'When', 'kaamase-core' ); ?></th>
							<th><?php esc_html_e( 'To', 'kaamase-core' ); ?></th>
							<th><?php esc_html_e( 'About', 'kaamase-core' ); ?></th>
							<th><?php esc_html_e( 'What happened', 'kaamase-core' ); ?></th>
						</tr>
					</thead>
					<tbody>
						<?php foreach ( $log as $row ) : ?>
							<tr>
								<td><?php echo esc_html( wp_date( get_option( 'date_format' ) . ' H:i', (int) $row['when'] ) ); ?></td>
								<td><?php echo esc_html( $row['to'] ); ?></td>
								<td><?php echo esc_html( $row['subject'] ); ?></td>
								<td>
									<?php if ( 0 === strpos( (string) $row['result'], 'refused' ) ) : ?>
										<strong style="color:#b32d2e"><?php echo esc_html( $row['result'] ); ?></strong>
									<?php else : ?>
										<?php esc_html_e( 'Accepted by the server', 'kaamase-core' ); ?>
									<?php endif; ?>
								</td>
							</tr>
						<?php endforeach; ?>
					</tbody>
				</table>

				<p>
					<a class="button" href="<?php echo esc_url( wp_nonce_url( admin_url( 'admin-post.php?action=kaamase_mail_clear' ), 'kaamase_mail_clear' ) ); ?>">
						<?php esc_html_e( 'Empty this list', 'kaamase-core' ); ?>
					</a>
				</p>

			<?php endif; ?>

			<p class="description" style="max-width:45em">
				<?php esc_html_e( 'Accepted means the server took the message. It does not mean anybody received it. The only proof of that is looking in a real inbox.', 'kaamase-core' ); ?>
			</p>

		</div>
		<?php
	}
}

if ( ! function_exists( 'kaamase_mail_test' ) ) {
	/**
	 * Try a real send and report exactly what came back.
	 *
	 * @since 1.0.0
	 * @return void
	 */
	function kaamase_mail_test() {

		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( esc_html__( 'You cannot do that.', 'kaamase-core' ) );
		}

		check_admin_referer( 'kaamase_mail_test' );

		// phpcs:ignore WordPress.Security.NonceVerification.Missing -- Checked above.
		$to = isset( $_POST['to'] ) ? sanitize_email( wp_unslash( $_POST['to'] ) ) : '';

		$back = admin_url( 'admin.php?page=kaamase-email' );

		if ( ! is_email( $to ) ) {
			wp_safe_redirect( add_query_arg( 'tried', 'bad', $back ) );
			exit;
		}

		$caught = '';

		$catch = static function ( $error ) use ( &$caught ) {
			$caught = is_wp_error( $error ) ? $error->get_error_message() : '';
		};

		add_action( 'wp_mail_failed', $catch, 1 );

		$sent = wp_mail(
			$to,
			__( 'Kaam Ase test message', 'kaamase-core' ),
			__( 'If you are reading this, mail from Kaam Ase reaches you. Nothing needs doing.', 'kaamase-core' )
		);

		remove_action( 'wp_mail_failed', $catch, 1 );

		wp_safe_redirect(
			add_query_arg(
				array(
					'tried' => $sent ? 'yes' : 'no',
					'why'   => rawurlencode( $caught ),
				),
				$back
			)
		);

		exit;
	}
}
add_action( 'admin_post_kaamase_mail_test', 'kaamase_mail_test' );

if ( ! function_exists( 'kaamase_mail_clear' ) ) {
	/**
	 * Empty the log.
	 *
	 * @since 1.0.0
	 * @return void
	 */
	function kaamase_mail_clear() {

		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( esc_html__( 'You cannot do that.', 'kaamase-core' ) );
		}

		check_admin_referer( 'kaamase_mail_clear' );

		delete_option( KAAMASE_MAIL_LOG_OPTION );

		wp_safe_redirect( admin_url( 'admin.php?page=kaamase-email' ) );
		exit;
	}
}
add_action( 'admin_post_kaamase_mail_clear', 'kaamase_mail_clear' );