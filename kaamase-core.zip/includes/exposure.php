<?php
/**
 * Fair exposure.
 *
 * Who sits at the top of a list of workers, and how that changes.
 *
 * The problem this replaces
 * -------------------------
 * queries.php rotates worker listings by post ID against today's date,
 * modulo 97. It rotates, which is the right instinct, but with thousands
 * of workers and only ninety seven positions roughly forty people share
 * each one, and inside a position the tie break is newest first. So an
 * older profile sits below a newer one in the same bucket every single
 * day. The buckets move. Who is at the top of a bucket never does.
 *
 * The app had it worse. Its listings set no order at all, so it fell to
 * the WordPress default of newest first, permanently. Since most of the
 * traffic is the app, most of the platform had no rotation whatsoever.
 *
 * Nothing anywhere measured who had actually been seen. A worker who had
 * never once reached a first page looked identical to the system to one
 * who reached it every day.
 *
 * What replaces it
 * ----------------
 * A profile records the day it last appeared on a first page. Listings
 * order by who has waited longest. That turns a shuffle into a queue and
 * gives you something you can promise out loud: no available worker sits
 * at the bottom forever.
 *
 * A profile that has never been shown sorts ahead of everybody, so a new
 * worker gets seen the day they join rather than waiting for a shuffle
 * to reach them.
 *
 * Why it does not move when you refresh
 * -------------------------------------
 * Being shown today counts as being at the front, not the back, until
 * midnight. Without that a page would reorder every time somebody
 * reloaded it: paging would show the same man on page one and page
 * three and skip another entirely, and an employer who saw a good
 * carpenter yesterday could never find him again. Employers are the
 * scarce side here. Nothing that makes the list feel unreliable is
 * worth a fairer shuffle.
 *
 * What this is not
 * ----------------
 * It is not ranking. Nobody is ranked above anybody on merit here, and
 * nothing about paying moves a profile up. A hiring platform that sells
 * position tells an employer that the worker who paid is the better
 * worker, and the employer finds out on the site that this is false.
 * The tick says who somebody is. It does not say where they sit.
 *
 * @package KaamaseCore
 * @version 1.0.0
 * @since   1.0.0
 */

defined( 'ABSPATH' ) || exit;


/** The day a profile last reached a first page, as Ymd. */
define( 'KAAMASE_SHOWN_KEY', KAAMASE_META_PREFIX . 'shown_on' );

/** How many of a page's results count as having been seen. */
define( 'KAAMASE_SHOWN_DEPTH', 20 );

/** Spreads the tie break across more positions than the old ninety seven. */
define( 'KAAMASE_SHOWN_PRIME', 9973 );


/* ==========================================================================
   1. TAKING OVER THE ORDERING
   ========================================================================== */

if ( ! function_exists( 'kaamase_exposure_take_over' ) ) {
	/**
	 * Replace the old rotation clause with this one.
	 *
	 * Done by unhooking rather than by editing queries.php, so that file
	 * stays exactly as it is and this one can be removed to put the old
	 * behaviour back.
	 *
	 * @since 1.0.0
	 * @return void
	 */
	function kaamase_exposure_take_over() {

		remove_filter( 'posts_orderby', 'kaamase_rotation_orderby', 10 );
	}
}
add_action( 'init', 'kaamase_exposure_take_over', 20 );

if ( ! function_exists( 'kaamase_exposure_rest_order' ) ) {
	/**
	 * Give the app the same ordering as the website.
	 *
	 * The app's listing endpoint passes no order, which left it on the
	 * WordPress default of newest first. Set here rather than in
	 * rest-api.php so that file is not touched.
	 *
	 * Jobs are left alone on purpose. Somebody opening the jobs list
	 * wants today's work at the top, and no amount of fairness to old
	 * listings is worth burying it.
	 *
	 * @since 1.0.0
	 * @param WP_Query $query The query.
	 * @return void
	 */
	function kaamase_exposure_rest_order( $query ) {

		if ( ! defined( 'REST_REQUEST' ) || ! REST_REQUEST ) {
			return;
		}

		$types = (array) $query->get( 'post_type' );

		if ( ! array_intersect( $types, array( 'kaamase_worker', 'kaamase_gang' ) ) ) {
			return;
		}

		if ( $query->get( 'orderby' ) || $query->get( 'meta_key' ) || $query->get( 's' ) ) {
			return;
		}

		$query->set( 'orderby', 'kaamase_rotate' );
	}
}
add_action( 'pre_get_posts', 'kaamase_exposure_rest_order', 25 );

if ( ! function_exists( 'kaamase_exposure_orderby' ) ) {
	/**
	 * Available first, then whoever has waited longest.
	 *
	 * Four rules, in order.
	 *
	 * Availability, because a worker who has marked themselves busy is
	 * no use to an employer today whatever else is true of them. A
	 * missing row counts as available, which is the same default the
	 * rest of the platform uses: the profile card says available now, so
	 * the listing has to agree with it.
	 *
	 * Then the waiting, which is the whole point of the file. Never
	 * shown counts as zero and sorts first. Shown today counts as minus
	 * one and also sorts first, which is what stops the page moving
	 * under somebody between one refresh and the next.
	 *
	 * Then a position that changes daily, to break ties between the many
	 * profiles that will share a date, and finally the newest profile,
	 * so the result is always deterministic.
	 *
	 * @since 1.0.0
	 * @param string   $orderby Existing clause.
	 * @param WP_Query $query   The query.
	 * @return string
	 */
	function kaamase_exposure_orderby( $orderby, $query ) {

		if ( 'kaamase_rotate' !== $query->get( 'orderby' ) ) {
			return $orderby;
		}

		global $wpdb;

		$today = absint( gmdate( 'Ymd' ) );
		$seed  = $today;

		return $wpdb->prepare(
			"CASE WHEN NOT EXISTS (
				SELECT 1 FROM {$wpdb->postmeta} ka_av
				WHERE ka_av.post_id = {$wpdb->posts}.ID
				AND ka_av.meta_key = %s
				AND ka_av.meta_value <> 'live'
			) THEN 0 ELSE 1 END ASC,
			CASE WHEN COALESCE( (
				SELECT ka_sh.meta_value + 0 FROM {$wpdb->postmeta} ka_sh
				WHERE ka_sh.post_id = {$wpdb->posts}.ID
				AND ka_sh.meta_key = %s
				LIMIT 1
			), 0 ) >= %d THEN -1 ELSE COALESCE( (
				SELECT ka_sh2.meta_value + 0 FROM {$wpdb->postmeta} ka_sh2
				WHERE ka_sh2.post_id = {$wpdb->posts}.ID
				AND ka_sh2.meta_key = %s
				LIMIT 1
			), 0 ) END ASC,
			MOD({$wpdb->posts}.ID * %d, %d) ASC,
			{$wpdb->posts}.post_date DESC",
			KAAMASE_META_PREFIX . 'availability',
			KAAMASE_SHOWN_KEY,
			$today,
			KAAMASE_SHOWN_KEY,
			$seed,
			KAAMASE_SHOWN_PRIME
		);
	}
}
add_filter( 'posts_orderby', 'kaamase_exposure_orderby', 10, 2 );


/* ==========================================================================
   2. RECORDING WHO WAS SEEN
   ========================================================================== */

if ( ! function_exists( 'kaamase_exposure_is_robot' ) ) {
	/**
	 * Whether this looks like a crawler rather than a person.
	 *
	 * Crawlers hit listing pages every day and would otherwise churn
	 * through the whole queue on their own, spending everybody's turn on
	 * nobody. Guessing from the user agent is not reliable, but it does
	 * not need to be: a crawler wrongly counted as a person costs one
	 * worker one day of position, which is a rounding error against
	 * getting the common case right.
	 *
	 * @since 1.0.0
	 * @return bool
	 */
	function kaamase_exposure_is_robot() {

		$agent = isset( $_SERVER['HTTP_USER_AGENT'] )
			? strtolower( sanitize_text_field( wp_unslash( $_SERVER['HTTP_USER_AGENT'] ) ) )
			: '';

		if ( '' === $agent ) {
			return true;
		}

		foreach ( array( 'bot', 'crawl', 'spider', 'slurp', 'facebookexternalhit', 'preview', 'headless' ) as $mark ) {
			if ( false !== strpos( $agent, $mark ) ) {
				return true;
			}
		}

		return false;
	}
}

if ( ! function_exists( 'kaamase_exposure_record' ) ) {
	/**
	 * Write today's date against the profiles on this first page.
	 *
	 * Three queries at most, and only on a first page. Anything deeper
	 * is somebody already looking hard, and counting page four as
	 * exposure would mean a profile nobody scrolled to had used up its
	 * turn.
	 *
	 * @since 1.0.0
	 * @param WP_Post[] $posts The results.
	 * @param WP_Query  $query The query.
	 * @return WP_Post[] The results, untouched.
	 */
	function kaamase_exposure_record( $posts, $query ) {

		if ( empty( $posts ) || is_admin() ) {
			return $posts;
		}

		if ( 'kaamase_rotate' !== $query->get( 'orderby' ) ) {
			return $posts;
		}

		if ( max( 1, (int) $query->get( 'paged' ) ) > 1 ) {
			return $posts;
		}

		if ( kaamase_exposure_is_robot() ) {
			return $posts;
		}

		$ids = array();

		foreach ( array_slice( $posts, 0, KAAMASE_SHOWN_DEPTH ) as $post ) {
			if ( isset( $post->ID ) ) {
				$ids[] = (int) $post->ID;
			}
		}

		if ( $ids ) {
			kaamase_exposure_mark( $ids );
		}

		return $posts;
	}
}
add_filter( 'the_posts', 'kaamase_exposure_record', 10, 2 );

if ( ! function_exists( 'kaamase_exposure_mark' ) ) {
	/**
	 * Set today's date on a set of profiles.
	 *
	 * Written straight to the meta table in bulk rather than one call
	 * per profile. Twenty separate update_post_meta calls on every
	 * listing view is sixty queries on shared hosting, for a value
	 * nobody reads until tomorrow.
	 *
	 * @since 1.0.0
	 * @param int[] $ids Profile IDs.
	 * @return void
	 */
	function kaamase_exposure_mark( $ids ) {

		global $wpdb;

		static $done = array();

		$ids = array_values( array_unique( array_map( 'absint', $ids ) ) );
		$ids = array_diff( $ids, $done );

		if ( empty( $ids ) ) {
			return;
		}

		$done  = array_merge( $done, $ids );
		$today = absint( gmdate( 'Ymd' ) );
		$slots = implode( ',', array_fill( 0, count( $ids ), '%d' ) );

		$have = $wpdb->get_col( // phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared, WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
			$wpdb->prepare(
				"SELECT post_id FROM {$wpdb->postmeta} WHERE meta_key = %s AND post_id IN ( {$slots} )", // phpcs:ignore WordPress.DB.PreparedSQLPlaceholders.UnfinishedPrepare
				array_merge( array( KAAMASE_SHOWN_KEY ), $ids )
			)
		);

		$have = array_map( 'absint', (array) $have );

		if ( $have ) {

			$slots = implode( ',', array_fill( 0, count( $have ), '%d' ) );

			$wpdb->query( // phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared, WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
				$wpdb->prepare(
					"UPDATE {$wpdb->postmeta} SET meta_value = %d
					WHERE meta_key = %s AND meta_value <> %d AND post_id IN ( {$slots} )", // phpcs:ignore WordPress.DB.PreparedSQLPlaceholders.UnfinishedPrepare
					array_merge( array( $today, KAAMASE_SHOWN_KEY, $today ), $have )
				)
			);
		}

		$missing = array_values( array_diff( $ids, $have ) );

		if ( $missing ) {

			$rows   = array();
			$values = array();

			foreach ( $missing as $id ) {
				$rows[]   = '( %d, %s, %d )';
				$values[] = $id;
				$values[] = KAAMASE_SHOWN_KEY;
				$values[] = $today;
			}

			$wpdb->query( // phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared, WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
				$wpdb->prepare(
					"INSERT INTO {$wpdb->postmeta} ( post_id, meta_key, meta_value ) VALUES " . implode( ',', $rows ), // phpcs:ignore WordPress.DB.PreparedSQLPlaceholders.UnfinishedPrepare
					$values
				)
			);
		}

		foreach ( $ids as $id ) {
			wp_cache_delete( $id, 'post_meta' );
		}
	}
}


/* ==========================================================================
   3. SEEING WHETHER IT IS WORKING

   A promise nobody can check is a slogan. These are the two numbers that
   say whether the queue is actually turning over, and they take one
   query each.
   ========================================================================== */

if ( ! function_exists( 'kaamase_exposure_stats' ) ) {
	/**
	 * How the queue is doing.
	 *
	 * @since 1.0.0
	 * @return array Counts and the longest wait in days.
	 */
	function kaamase_exposure_stats() {

		global $wpdb;

		$total = (int) $wpdb->get_var( // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
			$wpdb->prepare(
				"SELECT COUNT(*) FROM {$wpdb->posts}
				WHERE post_type = %s AND post_status = 'publish'",
				'kaamase_worker'
			)
		);

		$seen = (int) $wpdb->get_var( // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
			$wpdb->prepare(
				"SELECT COUNT(*) FROM {$wpdb->posts} p
				INNER JOIN {$wpdb->postmeta} m ON m.post_id = p.ID AND m.meta_key = %s
				WHERE p.post_type = %s AND p.post_status = 'publish'",
				KAAMASE_SHOWN_KEY,
				'kaamase_worker'
			)
		);

		$oldest = (string) $wpdb->get_var( // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
			$wpdb->prepare(
				"SELECT MIN(m.meta_value) FROM {$wpdb->posts} p
				INNER JOIN {$wpdb->postmeta} m ON m.post_id = p.ID AND m.meta_key = %s
				WHERE p.post_type = %s AND p.post_status = 'publish'",
				KAAMASE_SHOWN_KEY,
				'kaamase_worker'
			)
		);

		$waited = 0;

		if ( $oldest && 8 === strlen( $oldest ) ) {

			$then = strtotime( substr( $oldest, 0, 4 ) . '-' . substr( $oldest, 4, 2 ) . '-' . substr( $oldest, 6, 2 ) );

			if ( $then ) {
				$waited = (int) floor( ( time() - $then ) / DAY_IN_SECONDS );
			}
		}

		return array(
			'total'  => $total,
			'seen'   => $seen,
			'never'  => max( 0, $total - $seen ),
			'waited' => $waited,
		);
	}
}

if ( ! function_exists( 'kaamase_exposure_menu' ) ) {
	/**
	 * Add the screen.
	 *
	 * @since 1.0.0
	 * @return void
	 */
	function kaamase_exposure_menu() {

		add_submenu_page(
			'kaamase',
			__( 'Who is being seen', 'kaamase-core' ),
			__( 'Who is being seen', 'kaamase-core' ),
			'manage_options',
			'kaamase-exposure',
			'kaamase_exposure_screen'
		);
	}
}
add_action( 'admin_menu', 'kaamase_exposure_menu', 24 );

if ( ! function_exists( 'kaamase_exposure_screen' ) ) {
	/**
	 * Render the screen.
	 *
	 * @since 1.0.0
	 * @return void
	 */
	function kaamase_exposure_screen() {

		if ( ! current_user_can( 'manage_options' ) ) {
			return;
		}

		$stats = kaamase_exposure_stats();
		?>
		<div class="wrap">

			<h1><?php esc_html_e( 'Who is being seen', 'kaamase-core' ); ?></h1>

			<p style="max-width:45em">
				<?php esc_html_e( 'Worker listings put whoever has waited longest at the top. These numbers say whether that is actually turning over. If nobody has waited more than a few days, it is working.', 'kaamase-core' ); ?>
			</p>

			<table class="widefat striped" style="max-width:38em">
				<tbody>
					<tr>
						<th><?php esc_html_e( 'Worker profiles', 'kaamase-core' ); ?></th>
						<td><?php echo esc_html( number_format_i18n( $stats['total'] ) ); ?></td>
					</tr>
					<tr>
						<th><?php esc_html_e( 'Reached a first page at least once', 'kaamase-core' ); ?></th>
						<td><?php echo esc_html( number_format_i18n( $stats['seen'] ) ); ?></td>
					</tr>
					<tr>
						<th><?php esc_html_e( 'Never yet reached one', 'kaamase-core' ); ?></th>
						<td>
							<?php echo esc_html( number_format_i18n( $stats['never'] ) ); ?>
							<p class="description">
								<?php esc_html_e( 'These sort ahead of everybody, so they are next in line rather than forgotten.', 'kaamase-core' ); ?>
							</p>
						</td>
					</tr>
					<tr>
						<th><?php esc_html_e( 'Longest anybody has waited', 'kaamase-core' ); ?></th>
						<td>
							<?php
							echo esc_html(
								$stats['waited']
									? sprintf(
										/* translators: %s: a number of days */
										_n( '%s day', '%s days', $stats['waited'], 'kaamase-core' ),
										number_format_i18n( $stats['waited'] )
									)
									: __( 'Nothing recorded yet', 'kaamase-core' )
							);
							?>
							<p class="description">
								<?php esc_html_e( 'Counted among the workers who have been seen before. It should stay small. If it climbs week after week, there are more workers than the listings can cycle through and the trade and district filters are doing the real work.', 'kaamase-core' ); ?>
							</p>
						</td>
					</tr>
				</tbody>
			</table>

			<p class="description" style="max-width:45em">
				<?php esc_html_e( 'Nothing here is affected by paying. Position is turn taking, not ranking, and no plan moves anybody up.', 'kaamase-core' ); ?>
			</p>

		</div>
		<?php
	}
}