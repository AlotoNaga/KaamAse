<?php
/**
 * Adding the working side to an account.
 *
 * The mirror of hiring-request.php. That file lets a worker add hiring;
 * this one lets an employer add working, so neither side of the account
 * is a door that only opens one way.
 *
 * Why this exists
 * ---------------
 * Registration asks whether somebody is looking for work or looking to
 * hire, and until now that answer was permanent in one direction. A
 * worker could add hiring in a tap. An employer could not add working at
 * all, so the two routes through the same platform ended up with
 * different amounts of it available, by accident rather than by choice.
 *
 * That split was also wrong about the place. Here a mason subcontracts,
 * a carpenter takes on helpers, a shop owner works with his hands and
 * hires for the rest. Worker and employer are two things a person does,
 * often in the same week, not two kinds of person. An account should
 * hold both because people do.
 *
 * What it does not change
 * -----------------------
 * The two sides stay separate profiles, and that is deliberate. Ratings
 * earned as a worker and ratings earned as an employer are answers to
 * different questions, and a good mason is not automatically somebody
 * who pays on time. Keeping them apart is what lets both mean something.
 *
 * @package KaamaseCore
 * @version 1.0.0
 * @since   1.3.0
 */

defined( 'ABSPATH' ) || exit;


/** Set when the person added the working side themselves. */
define( 'KAAMASE_WORKING_SELF_KEY', '_kaamase_working_self' );

/** When it was added. */
define( 'KAAMASE_WORKING_TIME_KEY', '_kaamase_working_time' );


/* ==========================================================================
   1. STATE
   ========================================================================== */

if ( ! function_exists( 'kaamase_has_worker_side' ) ) {
	/**
	 * Whether this account has a worker profile it can be found by.
	 *
	 * Asked of the profile rather than the role, because the profile is
	 * the thing an employer actually finds. An account holding the role
	 * with nothing filled in is not listed anywhere, and telling that
	 * person they already have a worker profile would send them looking
	 * for something that is not there.
	 *
	 * @since 1.3.0
	 * @param int $user_id Optional. Defaults to the current user.
	 * @return bool
	 */
	function kaamase_has_worker_side( $user_id = 0 ) {

		$user_id = $user_id ? (int) $user_id : get_current_user_id();

		if ( ! $user_id ) {
			return false;
		}

		return (bool) kaamase_get_user_profile( $user_id, 'kaamase_worker' );
	}
}

if ( ! function_exists( 'kaamase_has_hiring_side' ) ) {
	/**
	 * Whether this account can post jobs.
	 *
	 * The capability, not the profile, because posting is a thing you
	 * are allowed to do rather than a page somebody visits.
	 *
	 * @since 1.3.0
	 * @param int $user_id Optional. Defaults to the current user.
	 * @return bool
	 */
	function kaamase_has_hiring_side( $user_id = 0 ) {

		$user_id = $user_id ? (int) $user_id : get_current_user_id();

		return $user_id && user_can( $user_id, 'create_kaamase_jobs' );
	}
}


/* ==========================================================================
   2. GRANTING

   add_role, never set_role, for the same reason as the hiring side: one
   adds working to an account, the other quietly replaces whatever the
   account already was and takes its capabilities with it.
   ========================================================================== */

if ( ! function_exists( 'kaamase_grant_working' ) ) {
	/**
	 * Add the working side to an account.
	 *
	 * @since 1.3.0
	 * @param int $user_id User to add it to.
	 * @return bool True when the account now has a worker profile.
	 */
	function kaamase_grant_working( $user_id ) {

		$user = get_userdata( (int) $user_id );

		if ( ! $user ) {
			return false;
		}

		if ( ! in_array( 'kaamase_worker', (array) $user->roles, true ) ) {
			$user->add_role( 'kaamase_worker' );
		}

		$profile = kaamase_ensure_worker_profile( (int) $user_id );

		update_user_meta( $user_id, KAAMASE_WORKING_TIME_KEY, time() );
		update_user_meta( $user_id, KAAMASE_WORKING_SELF_KEY, 1 );

		/**
		 * Fires after the working side is added to an account.
		 *
		 * @since 1.3.0
		 * @param int $user_id User ID.
		 * @param int $profile Worker profile ID.
		 */
		do_action( 'kaamase_working_granted', (int) $user_id, (int) $profile );

		return (bool) $profile;
	}
}

if ( ! function_exists( 'kaamase_ensure_worker_profile' ) ) {
	/**
	 * Make sure there is a worker profile to be found by.
	 *
	 * Draft, matching what registration does, so nothing half filled
	 * appears in the workers list. It publishes when they save it, or
	 * on email confirmation, exactly like a profile made at signup.
	 *
	 * @since 1.3.0
	 * @param int $user_id User ID.
	 * @return int Profile post ID, or 0 on failure.
	 */
	function kaamase_ensure_worker_profile( $user_id ) {

		$existing = kaamase_get_user_profile( (int) $user_id, 'kaamase_worker' );

		if ( $existing ) {
			return (int) $existing;
		}

		$user = get_userdata( (int) $user_id );

		if ( ! $user ) {
			return 0;
		}

		$post_id = wp_insert_post(
			array(
				'post_type'   => 'kaamase_worker',
				'post_title'  => $user->display_name,
				'post_status' => 'draft',
				'post_author' => (int) $user_id,
			),
			true
		);

		if ( is_wp_error( $post_id ) ) {
			return 0;
		}

		/*
		 * The phone and district come across from whichever profile they
		 * already have, so nobody is handed an empty form asking for
		 * details they gave when they registered.
		 *
		 * kaamase_field, not kaamase_get_field. The latter does not
		 * exist, and calling it behind function_exists is how the
		 * employer side of this silently created profiles with no phone
		 * number on them for weeks.
		 */
		$source = (int) get_user_meta( $user_id, 'kaamase_profile_id', true );

		if ( ! $source ) {
			$source = (int) kaamase_get_user_profile( (int) $user_id, 'kaamase_employer' );
		}

		if ( $source && $source !== (int) $post_id && function_exists( 'kaamase_field' ) ) {

			$phone    = (string) kaamase_field( $source, 'phone', '' );
			$district = (string) kaamase_field( $source, 'district', '' );

			if ( '' !== trim( $phone ) ) {
				kaamase_save_field( $post_id, 'phone', $phone );
			}

			if ( '' !== trim( $district ) ) {
				kaamase_save_field( $post_id, 'district', $district );
				wp_set_object_terms( $post_id, $district, 'kaamase_district' );
			}
		}

		return (int) $post_id;
	}
}


/* ==========================================================================
   3. WHAT THE APP IS TOLD

   Both sides in one place, so a screen can show what an account has and
   what it could add without asking twice.
   ========================================================================== */

if ( ! function_exists( 'kaamase_shape_me_sides' ) ) {
	/**
	 * Add both sides of the account to the me object.
	 *
	 * @since 1.3.0
	 * @param array $me      The account.
	 * @param int   $user_id User ID.
	 * @return array
	 */
	function kaamase_shape_me_sides( $me, $user_id ) {

		$me['has_worker_side']  = kaamase_has_worker_side( (int) $user_id );
		$me['has_hiring_side']  = kaamase_has_hiring_side( (int) $user_id );
		$me['worker_profile_id'] = (int) kaamase_get_user_profile( (int) $user_id, 'kaamase_worker' );

		return $me;
	}
}
add_filter( 'kaamase_shape_me', 'kaamase_shape_me_sides', 10, 2 );


/* ==========================================================================
   4. THE APP
   ========================================================================== */

if ( ! function_exists( 'kaamase_register_working_route' ) ) {
	/**
	 * POST /me/working
	 *
	 * @since 1.3.0
	 * @return void
	 */
	function kaamase_register_working_route() {

		if ( ! defined( 'KAAMASE_REST_NS' ) ) {
			return;
		}

		register_rest_route(
			KAAMASE_REST_NS,
			'/me/working',
			array(
				'methods'             => 'POST',
				'callback'            => 'kaamase_rest_add_working',
				'permission_callback' => 'kaamase_rest_require_login',
			)
		);
	}
}
add_action( 'rest_api_init', 'kaamase_register_working_route', 20 );

if ( ! function_exists( 'kaamase_rest_add_working' ) ) {
	/**
	 * Add the working side to the calling account.
	 *
	 * Returns the refreshed account, so the screen can change over
	 * without a second request on a connection that may not have one to
	 * spare.
	 *
	 * @since 1.3.0
	 * @return WP_REST_Response|WP_Error
	 */
	function kaamase_rest_add_working() {

		$user_id = get_current_user_id();

		if ( kaamase_has_worker_side( $user_id ) ) {
			return rest_ensure_response( kaamase_shape_me( $user_id ) );
		}

		if ( ! kaamase_grant_working( $user_id ) ) {
			return new WP_Error(
				'kaamase_working_failed',
				__( 'That did not work. Please try again.', 'kaamase-core' ),
				array( 'status' => 500 )
			);
		}

		return rest_ensure_response( kaamase_shape_me( $user_id ) );
	}
}


/* ==========================================================================
   5. THE WEBSITE
   ========================================================================== */

if ( ! function_exists( 'kaamase_handle_working_request' ) ) {
	/**
	 * Add the working side from a form post.
	 *
	 * @since 1.3.0
	 * @return void
	 */
	function kaamase_handle_working_request() {

		$back = kaamase_page_url( 'dashboard' );

		if ( ! is_user_logged_in() ) {
			wp_safe_redirect( $back );
			exit;
		}

		if ( ! isset( $_POST['kaamase_working_nonce'] )
			|| ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['kaamase_working_nonce'] ) ), 'kaamase_add_working' ) ) {
			wp_safe_redirect( $back );
			exit;
		}

		$user_id = get_current_user_id();

		if ( kaamase_has_worker_side( $user_id ) ) {
			wp_safe_redirect( $back );
			exit;
		}

		kaamase_grant_working( $user_id );

		/*
		 * Back to the dashboard, where the profile form lives.
		 *
		 * There is no separate edit page to send them to, and a blank
		 * worker profile nobody fills in is worse than none: it is a
		 * draft that never publishes and a person who thinks they are
		 * listed when they are not.
		 */
		wp_safe_redirect( add_query_arg( 'added', 'working', $back ) );
		exit;
	}
}
add_action( 'admin_post_kaamase_add_working', 'kaamase_handle_working_request' );

if ( ! function_exists( 'kaamase_working_offer' ) ) {
	/**
	 * The offer to add the working side, for the dashboard.
	 *
	 * @since 1.3.0
	 * @return string Markup, or an empty string when they already have it.
	 */
	function kaamase_working_offer() {

		if ( ! is_user_logged_in() || kaamase_has_worker_side() ) {
			return '';
		}

		return sprintf(
			'<div class="ka-card ka-stack ka-mt-6"><h3>%1$s</h3><p class="ka-small ka-soft">%2$s</p>'
			. '<form method="post" action="%3$s">%4$s'
			. '<input type="hidden" name="action" value="kaamase_add_working">'
			. '<button type="submit" class="ka-btn ka-btn--outline">%5$s</button></form></div>',
			esc_html__( 'Do you take work yourself?', 'kaamase-core' ),
			esc_html__( 'Plenty of people here hire for one job and work on another. Add a worker profile to this same account and employers can find you too. It is free, and your login and your job posts stay exactly as they are.', 'kaamase-core' ),
			esc_url( admin_url( 'admin-post.php' ) ),
			wp_nonce_field( 'kaamase_add_working', 'kaamase_working_nonce', true, false ),
			esc_html__( 'I also look for work', 'kaamase-core' )
		);
	}
}

if ( ! function_exists( 'kaamase_working_dashboard_section' ) ) {
	/**
	 * Show the offer on the dashboard.
	 *
	 * @since 1.3.0
	 * @param int $user_id Who is looking.
	 * @return void
	 */
	function kaamase_working_dashboard_section( $user_id ) {

		unset( $user_id );

		echo kaamase_working_offer(); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
	}
}
add_action( 'kaamase_dashboard_sections', 'kaamase_working_dashboard_section', 40 );