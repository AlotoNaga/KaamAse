<?php
/**
 * Who somebody has worked with.
 *
 * The missing link between confirming a hire and being allowed to rate.
 *
 * What was wrong
 * --------------
 * kaamase_pending_ratings() in hires.php opens like this:
 *
 *     if ( ! function_exists( 'kaamase_worked_with' ) ) {
 *         return array();
 *     }
 *
 * That function was never written. So the guard fired every time and
 * pending ratings was an empty array for everybody, always. Nothing
 * errored and nothing was logged, because as far as the code was
 * concerned it had simply found nobody.
 *
 * The effect ran the length of the platform. Answering "yes I hired
 * them" recorded the hire correctly and unlocked rating correctly, and
 * then no screen anywhere could tell you who you were now able to rate.
 * The dashboard prompt never appeared. The app's /ratings/pending
 * endpoint returned an empty list. A person who did exactly what was
 * asked of them saw the question vanish and nothing take its place.
 *
 * This is the second time a function guarded by function_exists turned
 * out never to have been written, and the guard is why both took so
 * long to find: it converts a fatal error, which anybody would notice
 * within a minute, into a wrong answer that looks like real data.
 *
 * Where the answers come from
 * ---------------------------
 * Both directions, from records that already exist rather than a new
 * store to keep in step.
 *
 * An employer rating a worker: the hire questions held against their own
 * account, the ones answered yes. That is the same record the dashboard
 * and the app read, so it cannot drift from what the person was asked.
 *
 * A worker rating an employer: the hires written onto their own profile
 * by kaamase_record_hire, which name the employer.
 *
 * @package KaamaseCore
 * @version 1.0.0
 * @since   1.4.0
 */

defined( 'ABSPATH' ) || exit;


if ( ! function_exists( 'kaamase_worked_with' ) ) {
	/**
	 * Everybody this account has a confirmed hire with.
	 *
	 * @since 1.4.0
	 * @param int $user_id User ID.
	 * @return array[] Entries with post_id and time, most recent first.
	 */
	function kaamase_worked_with( $user_id ) {

		$user_id = absint( $user_id );

		if ( ! $user_id ) {
			return array();
		}

		$out = array();

		/*
		 * Workers this person hired.
		 *
		 * Read from the hire questions rather than by searching every
		 * worker profile for a matching hire. The answer is already
		 * written against this account, so this is one meta read instead
		 * of a scan that gets slower as the platform grows.
		 */
		if ( function_exists( 'kaamase_get_hire_questions' ) ) {

			foreach ( kaamase_get_hire_questions( $user_id ) as $post_id => $entry ) {

				if ( ! is_array( $entry ) || 'hired' !== ( $entry['state'] ?? '' ) ) {
					continue;
				}

				$out[ (int) $post_id ] = array(
					'post_id' => (int) $post_id,
					'time'    => absint( $entry['answered'] ?? $entry['time'] ?? 0 ),
				);
			}
		}

		/*
		 * Employers this person worked for.
		 *
		 * Their own worker profile carries the hires, each naming the
		 * employer as a user. The rating goes on that employer's
		 * profile, so the user has to be turned back into one.
		 */
		$worker = function_exists( 'kaamase_get_user_profile' )
			? kaamase_get_user_profile( $user_id, 'kaamase_worker' )
			: 0;

		if ( $worker && function_exists( 'kaamase_meta_array' ) ) {

			$hires = kaamase_meta_array( get_post_meta( $worker, KAAMASE_META_PREFIX . 'hires', true ) );

			foreach ( (array) $hires as $hire ) {

				$employer_user = absint( $hire['employer'] ?? 0 );

				if ( ! $employer_user || $employer_user === $user_id ) {
					continue;
				}

				$employer_profile = (int) kaamase_get_user_profile( $employer_user, 'kaamase_employer' );

				if ( ! $employer_profile ) {
					continue;
				}

				$out[ $employer_profile ] = array(
					'post_id' => $employer_profile,
					'time'    => absint( $hire['time'] ?? 0 ),
				);
			}
		}

		// Most recent first, because that is the one still fresh enough to rate honestly.
		usort(
			$out,
			static function ( $a, $b ) {
				return $b['time'] <=> $a['time'];
			}
		);

		/**
		 * Filter the people an account has worked with.
		 *
		 * @since 1.4.0
		 * @param array[] $out     Entries with post_id and time.
		 * @param int     $user_id User ID.
		 */
		return (array) apply_filters( 'kaamase_worked_with', $out, $user_id );
	}
}