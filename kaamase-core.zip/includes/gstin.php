<?php
/**
 * Business details on file.
 *
 * A mark shown on the hiring side of an account that has given a
 * structurally valid GST number.
 *
 * How much this is worth here
 * ---------------------------
 * Not much on its own, and that is worth saying plainly rather than
 * discovering later. Most hiring on this platform is a household or a
 * small builder taking on a mason for a house. They have no GST
 * registration and never will. The few accounts that do have one are
 * mostly not the people using this to hire day labour.
 *
 * So this is kept because it costs nothing and it is real when it is
 * there, not because it is the trust signal. The signal that works here
 * is what workers said about somebody and how many people they have
 * actually hired, which is in standing.php. This is one line in that
 * block, shown when true and absent otherwise.
 *
 * Why this is free
 * ----------------
 * The original plan was to sell this as a verified badge. It is better
 * given away, and the reason is worth writing down because the money
 * argument points the other way.
 *
 * A trust mark that can be bought means the person paid. A worker
 * reading it will believe it means somebody checked. The gap between
 * those two is carried entirely by the worker who takes the job, and
 * this platform's whole claim is that it does not put people in that
 * position. Selling the mark would earn a few hundred rupees an account
 * and cost the sentence the platform uses to protect people.
 *
 * So the mark is a fact about an account, free to anybody who supplies
 * the number, and the paid plan sells capability instead: more lookups,
 * more urgent slots, jobs seen sooner. Nobody is misled and nothing that
 * matters for safety is behind a payment.
 *
 * What the mark actually claims
 * -----------------------------
 * Exactly what it can prove, which is less than people assume. The last
 * character of a GSTIN is a Luhn mod 36 check digit over the first
 * fourteen, so this catches typos and numbers somebody invented. It
 * confirms the number is well formed and carries a real PAN inside it.
 *
 * It does not confirm the registration is active, or that the business
 * trades, or that the person entering it owns it. Confirming any of
 * that needs a live lookup against the GST portal. The wording
 * everywhere therefore says details are on file, never that anybody has
 * been verified, because a mark that overclaims is worse than no mark:
 * it spends trust the platform has not earned.
 *
 * @package KaamaseCore
 * @version 1.0.0
 * @since   1.3.0
 */

defined( 'ABSPATH' ) || exit;


/* ==========================================================================
   1. THE NUMBER

   Offline, deliberately. A validation that depends on somebody else's
   API is a validation that stops working on the day their API does, and
   the arithmetic here has not changed since GST was introduced.
   ========================================================================== */

if ( ! function_exists( 'kaamase_gstin_is_valid' ) ) {
	/**
	 * Whether a GST number is structurally sound.
	 *
	 * @since 1.3.0
	 * @param string $gstin The number, in any case, with or without spaces.
	 * @return bool
	 */
	function kaamase_gstin_is_valid( $gstin ) {

		$gstin = strtoupper( preg_replace( '/[^A-Za-z0-9]/', '', (string) $gstin ) );

		if ( 15 !== strlen( $gstin ) ) {
			return false;
		}

		/*
		 * Shape first, because it is cheap and it is what catches the
		 * common mistake of pasting a PAN or a registration number in
		 * the wrong box.
		 *
		 * Two digits of state code, then a PAN, then the entity number,
		 * then the letter Z, then the check character.
		 */
		if ( ! preg_match( '/^[0-9]{2}[A-Z]{5}[0-9]{4}[A-Z]{1}[0-9A-Z]{1}Z[0-9A-Z]{1}$/', $gstin ) ) {
			return false;
		}

		// State codes run from 01. Anything outside the range is a typo.
		$state = (int) substr( $gstin, 0, 2 );

		if ( $state < 1 || $state > 38 ) {
			return false;
		}

		return kaamase_gstin_checksum( substr( $gstin, 0, 14 ) ) === substr( $gstin, 14, 1 );
	}
}

if ( ! function_exists( 'kaamase_gstin_checksum' ) ) {
	/**
	 * The check character for the first fourteen of a GSTIN.
	 *
	 * Luhn mod 36 over the alphabet 0 to 9 then A to Z. Each character
	 * is weighted alternately by one and two counting from the left,
	 * each product is folded back into the alphabet, and the check
	 * character is whatever makes the total a multiple of 36.
	 *
	 * @since 1.3.0
	 * @param string $body First fourteen characters.
	 * @return string One character, or an empty string if the body is wrong.
	 */
	function kaamase_gstin_checksum( $body ) {

		$alphabet = '0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ';
		$base     = strlen( $alphabet );
		$body     = strtoupper( (string) $body );

		if ( 14 !== strlen( $body ) ) {
			return '';
		}

		$total = 0;

		for ( $i = 0; $i < 14; $i++ ) {

			$value = strpos( $alphabet, $body[ $i ] );

			if ( false === $value ) {
				return '';
			}

			$factor  = ( 0 === $i % 2 ) ? 1 : 2;
			$product = $value * $factor;

			// Fold the product back into a single value in the alphabet.
			$total += (int) floor( $product / $base ) + ( $product % $base );
		}

		$check = ( $base - ( $total % $base ) ) % $base;

		return $alphabet[ $check ];
	}
}

if ( ! function_exists( 'kaamase_gstin_state' ) ) {
	/**
	 * The state a GSTIN was registered in.
	 *
	 * Only Nagaland is named, because that is the only one this platform
	 * needs to tell apart. Everything else is somewhere else, which is
	 * worth knowing but not worth a table of thirty eight names.
	 *
	 * @since 1.3.0
	 * @param string $gstin The number.
	 * @return string A short label, or an empty string.
	 */
	function kaamase_gstin_state( $gstin ) {

		$gstin = strtoupper( preg_replace( '/[^A-Za-z0-9]/', '', (string) $gstin ) );

		if ( strlen( $gstin ) < 2 ) {
			return '';
		}

		return '13' === substr( $gstin, 0, 2 )
			? __( 'Nagaland', 'kaamase-core' )
			: __( 'outside Nagaland', 'kaamase-core' );
	}
}


/* ==========================================================================
   2. WHO HAS ONE
   ========================================================================== */

if ( ! function_exists( 'kaamase_business_on_file' ) ) {
	/**
	 * Whether this account has a sound GST number against its hiring side.
	 *
	 * Read from the employer profile, never the worker profile, and that
	 * is the whole point rather than an implementation detail. The mark
	 * says something about somebody as a person who hires. Putting it on
	 * a worker card would make it a thing that ranks one labourer above
	 * another for having paperwork, which is the opposite of what this
	 * platform is for.
	 *
	 * @since 1.3.0
	 * @param int $user_id Optional. Defaults to the current user.
	 * @return bool
	 */
	function kaamase_business_on_file( $user_id = 0 ) {

		$user_id = $user_id ? (int) $user_id : get_current_user_id();

		if ( ! $user_id ) {
			return false;
		}

		$employer = kaamase_get_user_profile( $user_id, 'kaamase_employer' );

		if ( ! $employer ) {
			return false;
		}

		return kaamase_gstin_is_valid( (string) kaamase_field( $employer, 'gst', '' ) );
	}
}

if ( ! function_exists( 'kaamase_business_mark_label' ) ) {
	/**
	 * What the mark says.
	 *
	 * Deliberately dull. Every stronger word available here would claim
	 * more than the check can support.
	 *
	 * @since 1.3.0
	 * @return string
	 */
	function kaamase_business_mark_label() {

		/**
		 * Filter the label on the business mark.
		 *
		 * @since 1.3.0
		 * @param string $label The label.
		 */
		return (string) apply_filters(
			'kaamase_business_mark_label',
			__( 'GST on file', 'kaamase-core' )
		);
	}
}


/* ==========================================================================
   3. SAVING IT

   Validated at the point it is entered, so a wrong number is a sentence
   the person can act on rather than a mark that silently never appears.
   ========================================================================== */

if ( ! function_exists( 'kaamase_validate_gst_on_save' ) ) {
	/**
	 * Refuse a GST number that cannot be right.
	 *
	 * @since 1.3.0
	 * @param string[] $errors Errors so far.
	 * @param array    $data   Submitted profile data.
	 * @return string[]
	 */
	function kaamase_validate_gst_on_save( $errors, $data ) {

		// Guard, because the filter passes a user id this check ignores.

		$gst = isset( $data['gst'] ) ? trim( (string) $data['gst'] ) : '';

		// Optional. Nobody is made to give one.
		if ( '' === $gst ) {
			return $errors;
		}

		if ( ! kaamase_gstin_is_valid( $gst ) ) {
			$errors[] = __( 'That GST number does not look right. It is 15 characters, and the last one is a check character, so a single wrong letter makes the whole number fail. Copy it from your registration certificate. You can also leave it blank.', 'kaamase-core' );
		}

		return $errors;
	}
}
add_filter( 'kaamase_profile_errors', 'kaamase_validate_gst_on_save', 10, 2 );


/* ==========================================================================
   4. SHOWING IT

   On the hiring side only: the employer profile, and the jobs they post.
   ========================================================================== */

if ( ! function_exists( 'kaamase_shape_me_business' ) ) {
	/**
	 * Tell the app whether this account has business details on file.
	 *
	 * @since 1.3.0
	 * @param array $me      The account.
	 * @param int   $user_id User ID.
	 * @return array
	 */
	function kaamase_shape_me_business( $me, $user_id ) {

		$me['business_on_file'] = kaamase_business_on_file( (int) $user_id );
		$me['business_label']   = kaamase_business_mark_label();

		return $me;
	}
}
add_filter( 'kaamase_shape_me', 'kaamase_shape_me_business', 10, 2 );

if ( ! function_exists( 'kaamase_shape_job_business' ) ) {
	/**
	 * Put the mark on a job, so a worker sees it where it matters.
	 *
	 * A worker deciding whether to answer a stranger's advertisement is
	 * the person this is for. It is worth very little on the employer's
	 * own page, which is not where the decision gets made.
	 *
	 * @since 1.3.0
	 * @param array   $shaped The job as sent to the app.
	 * @param WP_Post $post   The job.
	 * @return array
	 */
	function kaamase_shape_job_business( $shaped, $post ) {

		if ( ! is_array( $shaped ) || ! $post instanceof WP_Post ) {
			return $shaped;
		}

		$shaped['business_on_file'] = kaamase_business_on_file( (int) $post->post_author );
		$shaped['business_label']   = kaamase_business_mark_label();

		return $shaped;
	}
}
add_filter( 'kaamase_shape_job', 'kaamase_shape_job_business', 10, 2 );


/* ==========================================================================
   5. IN THE ADMIN

   So the number can be read without opening the profile, and so a
   number that fails is visible rather than silently doing nothing.
   ========================================================================== */

if ( ! function_exists( 'kaamase_employer_gst_column' ) ) {
	/**
	 * Add the GST column to the employers list.
	 *
	 * @since 1.3.0
	 * @param array $columns Existing columns.
	 * @return array
	 */
	function kaamase_employer_gst_column( $columns ) {

		$columns['kaamase_gst'] = __( 'GST', 'kaamase-core' );

		return $columns;
	}
}
add_filter( 'manage_kaamase_employer_posts_columns', 'kaamase_employer_gst_column' );

if ( ! function_exists( 'kaamase_employer_gst_column_value' ) ) {
	/**
	 * Fill the GST column.
	 *
	 * @since 1.3.0
	 * @param string $column  Column key.
	 * @param int    $post_id Employer profile ID.
	 * @return void
	 */
	function kaamase_employer_gst_column_value( $column, $post_id ) {

		if ( 'kaamase_gst' !== $column ) {
			return;
		}

		$gst = function_exists( 'kaamase_field' ) ? (string) kaamase_field( $post_id, 'gst', '' ) : '';

		if ( '' === trim( $gst ) ) {
			echo '&mdash;';

			return;
		}

		if ( ! kaamase_gstin_is_valid( $gst ) ) {
			printf(
				'<span style="color:#b32d2e">%s</span><br><code>%s</code>',
				esc_html__( 'Does not check out', 'kaamase-core' ),
				esc_html( $gst )
			);

			return;
		}

		printf(
			'<code>%1$s</code><br><span class="description">%2$s</span>',
			esc_html( strtoupper( $gst ) ),
			esc_html( kaamase_gstin_state( $gst ) )
		);
	}
}
add_action( 'manage_kaamase_employer_posts_custom_column', 'kaamase_employer_gst_column_value', 10, 2 );