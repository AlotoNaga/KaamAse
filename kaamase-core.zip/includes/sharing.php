<?php
/**
 * Share cards.
 *
 * The picture, headline and line of text that appear when somebody
 * pastes a link into WhatsApp, Facebook or anywhere else.
 *
 * Why this file exists
 * --------------------
 * The site had none of these tags at all. A job pasted into a WhatsApp
 * group showed a bare blue link, and a bare link in a group of two
 * hundred workers is a link almost nobody taps.
 *
 * That matters more here than on most sites. Sharing into groups is not
 * a nice extra for this platform, it is the main way a job in Nagaland
 * actually reaches the people who could do it. The job page can be
 * perfect and it will still lose to a screenshot somebody posted
 * instead, unless the link carries its own picture.
 *
 * The fallback is the point
 * -------------------------
 * A job with no picture must not share as a blank. It falls back to the
 * site logo, so every link that leaves this platform carries the Kaam
 * Ase mark. Over a year of group chats that is worth more than any
 * single job post.
 *
 * Standing aside
 * --------------
 * If a search plugin is running, it already writes these tags and two
 * sets in one page is worse than either. This file checks for the common
 * ones and writes nothing when it finds them.
 *
 * @package KaamaseCore
 * @version 1.0.0
 * @since   1.0.0
 */

defined( 'ABSPATH' ) || exit;


/* ==========================================================================
   1. WHETHER TO WRITE ANYTHING
   ========================================================================== */

if ( ! function_exists( 'kaamase_share_tags_wanted' ) ) {
	/**
	 * Whether this site needs us to write share tags.
	 *
	 * @since 1.0.0
	 * @return bool
	 */
	function kaamase_share_tags_wanted() {

		$taken = defined( 'WPSEO_VERSION' )
			|| defined( 'RANK_MATH_VERSION' )
			|| defined( 'SEOPRESS_VERSION' )
			|| defined( 'AIOSEO_VERSION' )
			|| class_exists( 'WPSEO_Options' );

		/**
		 * Filter whether Kaam Ase writes the share tags.
		 *
		 * @since 1.0.0
		 * @param bool $wanted Whether to write them.
		 */
		return (bool) apply_filters( 'kaamase_share_tags', ! $taken );
	}
}


/* ==========================================================================
   2. THE PICTURE
   ========================================================================== */

if ( ! function_exists( 'kaamase_share_fallback_image' ) ) {
	/**
	 * The picture to use when the page has none of its own.
	 *
	 * The logo first, then the site icon. Both are already set on most
	 * sites, which means this needs no new setting to configure and no
	 * screen to forget to fill in.
	 *
	 * @since 1.0.0
	 * @return string URL, or an empty string.
	 */
	function kaamase_share_fallback_image() {

		$logo = (int) get_theme_mod( 'custom_logo' );

		if ( $logo ) {

			$src = wp_get_attachment_image_src( $logo, 'full' );

			if ( ! empty( $src[0] ) ) {
				return (string) $src[0];
			}
		}

		$icon = (int) get_option( 'site_icon' );

		if ( $icon ) {

			$src = wp_get_attachment_image_src( $icon, 'full' );

			if ( ! empty( $src[0] ) ) {
				return (string) $src[0];
			}
		}

		/**
		 * Filter the picture used when a page has none.
		 *
		 * @since 1.0.0
		 * @param string $url Image URL.
		 */
		return (string) apply_filters( 'kaamase_share_fallback_image', '' );
	}
}

if ( ! function_exists( 'kaamase_share_image' ) ) {
	/**
	 * The picture for one page.
	 *
	 * @since 1.0.0
	 * @param int $post_id Post ID, or 0 for a page with no post behind it.
	 * @return array Width, height and URL. Width and height may be 0.
	 */
	function kaamase_share_image( $post_id ) {

		$post_id = (int) $post_id;

		if ( $post_id && has_post_thumbnail( $post_id ) ) {

			$id = get_post_thumbnail_id( $post_id );

			foreach ( array( 'kaamase-wide', 'large', 'full' ) as $size ) {

				$src = wp_get_attachment_image_src( $id, $size );

				if ( ! empty( $src[0] ) && (int) $src[1] >= 400 ) {
					return array(
						'url'    => (string) $src[0],
						'width'  => (int) $src[1],
						'height' => (int) $src[2],
					);
				}
			}
		}

		return array(
			'url'    => kaamase_share_fallback_image(),
			'width'  => 0,
			'height' => 0,
		);
	}
}


/* ==========================================================================
   3. THE WORDS
   ========================================================================== */

if ( ! function_exists( 'kaamase_share_description' ) ) {
	/**
	 * The line of text under the headline.
	 *
	 * For a job this is built rather than taken from the description,
	 * because the facts a worker decides on are the trade, the place and
	 * the rate, and those are rarely the first words an employer types.
	 *
	 * @since 1.0.0
	 * @param int $post_id Post ID.
	 * @return string
	 */
	function kaamase_share_description( $post_id ) {

		$post = get_post( $post_id );

		if ( $post && 'kaamase_job' === $post->post_type && function_exists( 'kaamase_read_field' ) ) {

			$bits = array();

			$town     = (string) kaamase_read_field( $post_id, 'town' );
			$district = function_exists( 'kaamase_district_name' )
				? (string) kaamase_district_name( (string) kaamase_read_field( $post_id, 'district' ) )
				: '';

			$where = $town && $district ? $town . ', ' . $district : ( $town ? $town : $district );

			if ( $where ) {
				$bits[] = $where;
			}

			$pay  = absint( kaamase_read_field( $post_id, 'pay_amount' ) );
			$unit = (string) kaamase_read_field( $post_id, 'pay_unit' );

			if ( $pay ) {

				$units = array(
					'day'   => __( 'Rupees %s a day', 'kaamase-core' ),
					'month' => __( 'Rupees %s a month', 'kaamase-core' ),
					'hour'  => __( 'Rupees %s an hour', 'kaamase-core' ),
					'job'   => __( 'Rupees %s for the job', 'kaamase-core' ),
				);

				/* translators: %s: amount in rupees */
				$pattern = isset( $units[ $unit ] ) ? $units[ $unit ] : __( 'Rupees %s', 'kaamase-core' );

				$bits[] = sprintf( $pattern, number_format_i18n( $pay ) );
			}

			$text = wp_strip_all_tags( (string) $post->post_content );

			if ( $text ) {
				$bits[] = wp_trim_words( $text, 20, '' );
			}

			if ( $bits ) {
				return implode( '. ', $bits );
			}
		}

		if ( $post ) {

			$text = $post->post_excerpt ? $post->post_excerpt : $post->post_content;
			$text = wp_strip_all_tags( strip_shortcodes( (string) $text ) );

			if ( $text ) {
				return wp_trim_words( $text, 30, '' );
			}
		}

		return (string) get_bloginfo( 'description' );
	}
}


/* ==========================================================================
   4. WRITING THEM
   ========================================================================== */

if ( ! function_exists( 'kaamase_share_tag' ) ) {
	/**
	 * One meta tag.
	 *
	 * @since 1.0.0
	 * @param string $attribute property or name.
	 * @param string $key       Tag key.
	 * @param string $value     Tag value.
	 * @return void
	 */
	function kaamase_share_tag( $attribute, $key, $value ) {

		if ( '' === trim( (string) $value ) ) {
			return;
		}

		printf(
			'<meta %1$s="%2$s" content="%3$s">' . "\n",
			esc_attr( $attribute ),
			esc_attr( $key ),
			esc_attr( $value )
		);
	}
}

if ( ! function_exists( 'kaamase_print_share_tags' ) ) {
	/**
	 * Write the share tags into the head.
	 *
	 * @since 1.0.0
	 * @return void
	 */
	function kaamase_print_share_tags() {

		if ( ! kaamase_share_tags_wanted() ) {
			return;
		}

		$post_id = 0;
		$title   = '';
		$url     = '';

		if ( is_singular() ) {

			$post_id = (int) get_queried_object_id();
			$title   = wp_strip_all_tags( get_the_title( $post_id ) );
			$url     = (string) get_permalink( $post_id );

		} elseif ( is_front_page() || is_home() ) {

			$title = wp_strip_all_tags( (string) get_bloginfo( 'name' ) );
			$url   = (string) home_url( '/' );

		} else {

			return;
		}

		$image = kaamase_share_image( $post_id );

		echo "\n<!-- Kaam Ase share card -->\n";

		kaamase_share_tag( 'property', 'og:site_name', (string) get_bloginfo( 'name' ) );
		kaamase_share_tag( 'property', 'og:type', $post_id ? 'article' : 'website' );
		kaamase_share_tag( 'property', 'og:title', $title );
		kaamase_share_tag( 'property', 'og:description', kaamase_share_description( $post_id ) );
		kaamase_share_tag( 'property', 'og:url', $url );
		kaamase_share_tag( 'property', 'og:locale', (string) get_locale() );

		if ( $image['url'] ) {

			kaamase_share_tag( 'property', 'og:image', $image['url'] );

			if ( $image['width'] && $image['height'] ) {
				kaamase_share_tag( 'property', 'og:image:width', (string) $image['width'] );
				kaamase_share_tag( 'property', 'og:image:height', (string) $image['height'] );
			}
		}

		/*
		 * The large card is only claimed when the picture is really
		 * wide enough for one. A summary_large_image tag on a small
		 * logo renders as a stretched blur, which looks worse than the
		 * small card it replaced.
		 */
		kaamase_share_tag(
			'name',
			'twitter:card',
			( $image['url'] && $image['width'] >= 600 ) ? 'summary_large_image' : 'summary'
		);

		kaamase_share_tag( 'name', 'twitter:title', $title );
		kaamase_share_tag( 'name', 'twitter:description', kaamase_share_description( $post_id ) );
		kaamase_share_tag( 'name', 'twitter:image', $image['url'] );

		echo "<!-- /Kaam Ase share card -->\n\n";
	}
}
add_action( 'wp_head', 'kaamase_print_share_tags', 5 );