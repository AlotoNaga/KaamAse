<?php
/**
 * Settings.
 *
 * Deliberately short. There are five settings and four of them exist
 * because leaving them hardcoded would mean editing PHP to change a
 * phone number, which is not something a person running a business
 * should have to do.
 *
 * The fifth is the data deletion switch, and it is the reason this file
 * has a danger section with a confirmation field rather than a checkbox.
 * See uninstall.php for why deletion is opt in.
 *
 * What is NOT here
 * ----------------
 * The daily contact limit, the rating threshold, the retention
 * timetable, the wage floor and the trade list are all filterable in
 * code and none of them are on this screen. Every one of those is a
 * decision with a reasoned default behind it, and putting a text box
 * next to it invites somebody to change it on a bad afternoon without
 * knowing what it protects. If one genuinely needs changing, it should
 * take a conversation, not a click.
 *
 * @package KaamaseCore
 * @version 1.0.0
 * @since   1.0.0
 */

defined( 'ABSPATH' ) || exit;


/* ==========================================================================
   1. MENU
   ========================================================================== */

if ( ! function_exists( 'kaamase_settings_menu' ) ) {
	/**
	 * Add the settings page under the Kaam Ase menu.
	 *
	 * @since 1.0.0
	 * @return void
	 */
	function kaamase_settings_menu() {

		add_submenu_page(
			'kaamase',
			__( 'Settings', 'kaamase-core' ),
			__( 'Settings', 'kaamase-core' ),
			'manage_options',
			'kaamase-settings',
			'kaamase_settings_page'
		);
	}
}
add_action( 'admin_menu', 'kaamase_settings_menu', 20 );


/* ==========================================================================
   2. REGISTRATION
   ========================================================================== */

if ( ! function_exists( 'kaamase_register_settings' ) ) {
	/**
	 * Register the settings.
	 *
	 * @since 1.0.0
	 * @return void
	 */
	function kaamase_register_settings() {

		register_setting(
			'kaamase_settings',
			'kaamase_report_email',
			array(
				'type'              => 'string',
				'sanitize_callback' => 'sanitize_email',
				'default'           => get_option( 'admin_email' ),
			)
		);

		register_setting(
			'kaamase_settings',
			'kaamase_help_phone',
			array(
				'type'              => 'string',
				'sanitize_callback' => 'kaamase_sanitize_phone',
				'default'           => '',
			)
		);

		register_setting(
			'kaamase_settings',
			'kaamase_emergency_extra',
			array(
				'type'              => 'string',
				'sanitize_callback' => 'sanitize_textarea_field',
				'default'           => '',
			)
		);

		register_setting(
			'kaamase_settings',
			'kaamase_flag_email',
			array(
				'type'              => 'boolean',
				'sanitize_callback' => 'rest_sanitize_boolean',
				'default'           => true,
			)
		);
	}
}
add_action( 'admin_init', 'kaamase_register_settings' );


/* ==========================================================================
   3. THE PAGE
   ========================================================================== */

if ( ! function_exists( 'kaamase_settings_page' ) ) {
	/**
	 * Render the settings page.
	 *
	 * @since 1.0.0
	 * @return void
	 */
	function kaamase_settings_page() {

		if ( ! current_user_can( 'manage_options' ) ) {
			return;
		}
		?>
		<div class="wrap">

			<h1><?php esc_html_e( 'Kaam Ase settings', 'kaamase-core' ); ?></h1>

			<form method="post" action="options.php">

				<?php settings_fields( 'kaamase_settings' ); ?>

				<table class="form-table" role="presentation">

					<tr>
						<th scope="row">
							<label for="kaamase_report_email"><?php esc_html_e( 'Send reports to', 'kaamase-core' ); ?></label>
						</th>
						<td>
							<input class="regular-text" type="email" id="kaamase_report_email" name="kaamase_report_email"
								value="<?php echo esc_attr( get_option( 'kaamase_report_email', get_option( 'admin_email' ) ) ); ?>">
							<p class="description">
								<?php esc_html_e( 'Where wage complaints and safety reports are emailed. Use an address a person actually opens, not a general company inbox nobody reads on a Saturday.', 'kaamase-core' ); ?>
							</p>
						</td>
					</tr>

					<tr>
						<th scope="row">
							<label for="kaamase_help_phone"><?php esc_html_e( 'Help phone number', 'kaamase-core' ); ?></label>
						</th>
						<td>
							<input class="regular-text" type="tel" id="kaamase_help_phone" name="kaamase_help_phone"
								value="<?php echo esc_attr( get_option( 'kaamase_help_phone', '' ) ); ?>">
							<p class="description">
								<?php esc_html_e( 'Shown to people who cannot use the website. Many workers will phone rather than fill in a form, and a platform with no number to call looks like one that does not want to be reached.', 'kaamase-core' ); ?>
							</p>
						</td>
					</tr>

					<tr>
						<th scope="row">
							<label for="kaamase_emergency_extra"><?php esc_html_e( 'Extra emergency numbers', 'kaamase-core' ); ?></label>
						</th>
						<td>
							<textarea class="large-text code" rows="4" id="kaamase_emergency_extra" name="kaamase_emergency_extra"><?php echo esc_textarea( get_option( 'kaamase_emergency_extra', '' ) ); ?></textarea>
							<p class="description">
								<?php esc_html_e( 'One per line, as label then a comma then the number. For example: Dimapur police station, 03862123456', 'kaamase-core' ); ?>
							</p>
							<p class="description">
								<strong><?php esc_html_e( 'Dial every number you put here before you save it.', 'kaamase-core' ); ?></strong>
								<?php esc_html_e( 'A helpline printed on a safety page that rings out is worse than no helpline at all.', 'kaamase-core' ); ?>
							</p>
						</td>
					</tr>

					<tr>
						<th scope="row"><?php esc_html_e( 'Phone app notifications', 'kaamase-core' ); ?></th>
						<td>
							<label>
								<input type="checkbox" name="kaamase_push_enabled" value="1"
									<?php checked( get_option( 'kaamase_push_enabled', false ) ); ?>>
								<?php esc_html_e( 'Send push notifications to the Kaam Ase app', 'kaamase-core' ); ?>
							</label>
							<p class="description">
								<?php esc_html_e( 'Three things only: somebody looked up your number, your profile went live, and did you hire them. Nothing else, because an app that notifies about every new listing gets muted within a week and then cannot tell anybody the one thing that mattered.', 'kaamase-core' ); ?>
							</p>
							<p class="description">
								<strong><?php esc_html_e( 'A phone number is never put in a notification.', 'kaamase-core' ); ?></strong>
								<?php esc_html_e( 'They pass through Expo and sit readable on a locked screen.', 'kaamase-core' ); ?>
							</p>
						</td>
					</tr>

					<tr>
						<th scope="row"><?php esc_html_e( 'Flag alerts', 'kaamase-core' ); ?></th>
						<td>
							<label>
								<input type="checkbox" name="kaamase_flag_email" value="1"
									<?php checked( get_option( 'kaamase_flag_email', true ) ); ?>>
								<?php esc_html_e( 'Email me when somebody collects three flags', 'kaamase-core' ); ?>
							</label>
							<p class="description">
								<?php esc_html_e( 'Three separate workers saying the same employer did not pay is a pattern. This is the alert that lets you phone them before it becomes a public argument.', 'kaamase-core' ); ?>
							</p>
						</td>
					</tr>

				</table>

				<?php submit_button(); ?>

			</form>

			<hr style="margin:40px 0;">

			<?php kaamase_danger_zone(); ?>

		</div>
		<?php
	}
}

if ( ! function_exists( 'kaamase_danger_zone' ) ) {
	/**
	 * The data deletion switch.
	 *
	 * Separated, styled red, and requires typing rather than ticking.
	 * What this switch decides is whether deleting the plugin also
	 * destroys every worker profile on the platform, and that deserves
	 * more friction than a checkbox next to a mailing address.
	 *
	 * @since 1.0.0
	 * @return void
	 */
	function kaamase_danger_zone() {

		$armed = (bool) get_option( 'kaamase_delete_data_on_uninstall' );
		?>
		<div style="border:1px solid #c0392b;border-radius:6px;padding:16px 20px;max-width:720px;background:#fff;">

			<h2 style="margin-top:0;color:#c0392b;">
				<?php esc_html_e( 'Deleting the plugin', 'kaamase-core' ); ?>
			</h2>

			<p>
				<?php esc_html_e( 'By default, deleting this plugin leaves every worker profile, job, rating and report in the database. Reinstalling brings it all back. That is on purpose: a plugin gets deleted for many reasons, and most of them are not a decision to destroy several hundred people\'s listings.', 'kaamase-core' ); ?>
			</p>

			<?php if ( $armed ) : ?>

				<p style="background:#fbe9e7;border-left:4px solid #c0392b;padding:12px;">
					<strong><?php esc_html_e( 'Data removal is currently switched ON.', 'kaamase-core' ); ?></strong><br>
					<?php esc_html_e( 'If this plugin is deleted, every profile, job, rating, report and photograph goes with it and cannot be recovered.', 'kaamase-core' ); ?>
				</p>

				<form method="post" action="">
					<?php wp_nonce_field( 'kaamase_danger', 'kaamase_danger_nonce' ); ?>
					<input type="hidden" name="kaamase_danger_action" value="disarm">
					<?php submit_button( __( 'Switch data removal back off', 'kaamase-core' ), 'secondary', 'submit', false ); ?>
				</form>

			<?php else : ?>

				<p>
					<?php esc_html_e( 'Switch this on only if you are finished with Kaam Ase and want everything gone when the plugin is deleted.', 'kaamase-core' ); ?>
				</p>

				<form method="post" action="">
					<?php wp_nonce_field( 'kaamase_danger', 'kaamase_danger_nonce' ); ?>
					<input type="hidden" name="kaamase_danger_action" value="arm">

					<p>
						<label for="kaamase_danger_confirm">
							<?php
							printf(
								/* translators: %s: the word that must be typed */
								esc_html__( 'Type %s to switch it on', 'kaamase-core' ),
								'<code>' . esc_html_x( 'DELETE EVERYTHING', 'confirmation phrase for wiping all platform data', 'kaamase-core' ) . '</code>'
							);
							?>
						</label><br>
						<input class="regular-text" type="text" id="kaamase_danger_confirm" name="kaamase_danger_confirm" autocomplete="off">
					</p>

					<?php submit_button( __( 'Switch data removal on', 'kaamase-core' ), 'delete', 'submit', false ); ?>
				</form>

			<?php endif; ?>

			<p class="description" style="margin-top:16px;">
				<?php esc_html_e( 'Take a database backup before you touch this, and check that the backup restores. A backup nobody has tested is not a backup.', 'kaamase-core' ); ?>
			</p>

		</div>
		<?php
	}
}

if ( ! function_exists( 'kaamase_handle_danger_zone' ) ) {
	/**
	 * Arm or disarm data removal.
	 *
	 * @since 1.0.0
	 * @return void
	 */
	function kaamase_handle_danger_zone() {

		// phpcs:ignore WordPress.Security.NonceVerification.Missing
		if ( empty( $_POST['kaamase_danger_action'] ) || ! current_user_can( 'manage_options' ) ) {
			return;
		}

		if (
			empty( $_POST['kaamase_danger_nonce'] )
			|| ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['kaamase_danger_nonce'] ) ), 'kaamase_danger' )
		) {
			return;
		}

		// phpcs:ignore WordPress.Security.NonceVerification.Missing
		$action = sanitize_key( wp_unslash( $_POST['kaamase_danger_action'] ) );

		if ( 'disarm' === $action ) {
			delete_option( 'kaamase_delete_data_on_uninstall' );
			add_settings_error( 'kaamase', 'disarmed', __( 'Data removal switched off. Your data is safe if the plugin is deleted.', 'kaamase-core' ), 'success' );
			return;
		}

		// phpcs:ignore WordPress.Security.NonceVerification.Missing
		$typed  = isset( $_POST['kaamase_danger_confirm'] ) ? strtoupper( trim( sanitize_text_field( wp_unslash( $_POST['kaamase_danger_confirm'] ) ) ) ) : '';
		$phrase = strtoupper( _x( 'DELETE EVERYTHING', 'confirmation phrase for wiping all platform data', 'kaamase-core' ) );

		if ( $typed !== $phrase ) {
			add_settings_error( 'kaamase', 'mistyped', __( 'Type the phrase exactly. Nothing has been changed.', 'kaamase-core' ), 'error' );
			return;
		}

		update_option( 'kaamase_delete_data_on_uninstall', 1 );
		add_settings_error( 'kaamase', 'armed', __( 'Data removal is now switched on. Deleting the plugin will destroy everything.', 'kaamase-core' ), 'warning' );
	}
}
add_action( 'load-kaamase_page_kaamase-settings', 'kaamase_handle_danger_zone' );

/**
 * Show the settings messages.
 *
 * @since 1.0.0
 * @return void
 */
function kaamase_settings_notices() {

	$screen = get_current_screen();

	if ( ! $screen || false === strpos( $screen->id, 'kaamase-settings' ) ) {
		return;
	}

	settings_errors( 'kaamase' );
}
add_action( 'admin_notices', 'kaamase_settings_notices' );


/* ==========================================================================
   4. USING THE SETTINGS
   ========================================================================== */

/**
 * Send reports to the configured address.
 *
 * @since 1.0.0
 * @param string $address Default address.
 * @return string Configured address.
 */
function kaamase_use_report_email( $address ) {

	$configured = get_option( 'kaamase_report_email' );

	return is_email( $configured ) ? $configured : $address;
}
add_filter( 'kaamase_report_email', 'kaamase_use_report_email' );

/**
 * Add the configured emergency numbers to the built in ones.
 *
 * @since 1.0.0
 * @param array[] $numbers Existing numbers.
 * @return array[] Filtered numbers.
 */
function kaamase_use_extra_emergency_numbers( $numbers ) {

	$raw = (string) get_option( 'kaamase_emergency_extra', '' );

	if ( '' === trim( $raw ) ) {
		return $numbers;
	}

	foreach ( preg_split( '/\r\n|\r|\n/', $raw ) as $line ) {

		$parts = array_map( 'trim', explode( ',', $line, 2 ) );

		if ( count( $parts ) < 2 || '' === $parts[0] || '' === $parts[1] ) {
			continue;
		}

		$numbers[] = array(
			'label'  => sanitize_text_field( $parts[0] ),
			'number' => preg_replace( '/[^0-9+]/', '', $parts[1] ),
		);
	}

	return $numbers;
}
add_filter( 'kaamase_emergency_numbers', 'kaamase_use_extra_emergency_numbers' );

/**
 * Email when somebody collects three flags.
 *
 * @since 1.0.0
 * @param int    $post_id Profile flagged.
 * @param string $key     Question that was failed.
 * @param int    $count   How many times.
 * @return void
 */
function kaamase_email_flag_threshold( $post_id, $key, $count ) {

	if ( ! get_option( 'kaamase_flag_email', true ) ) {
		return;
	}

	$to = apply_filters( 'kaamase_report_email', get_option( 'admin_email' ) );

	$labels = array();

	foreach ( array( 'worker', 'employer' ) as $about ) {
		foreach ( kaamase_rating_questions( $about ) as $question_key => $question ) {
			$labels[ $question_key ] = rtrim( $question['label'], '?' );
		}
	}

	wp_mail(
		$to,
		sprintf(
			/* translators: %s: name on the flagged profile */
			__( 'Pattern on Kaam Ase: %s', 'kaamase-core' ),
			get_the_title( $post_id )
		),
		implode(
			"\n\n",
			array(
				sprintf(
					/* translators: 1: number of times, 2: the thing people said */
					__( '%1$d different people have now said: %2$s', 'kaamase-core' ),
					absint( $count ),
					isset( $labels[ $key ] ) ? $labels[ $key ] : $key
				),
				__( 'Three people saying the same thing about the same person is a pattern, not a bad day. Phone them before it turns into a public argument.', 'kaamase-core' ),
				admin_url( 'post.php?post=' . absint( $post_id ) . '&action=edit' ),
			)
		)
	);
}
add_action( 'kaamase_flag_threshold', 'kaamase_email_flag_threshold', 10, 3 );
