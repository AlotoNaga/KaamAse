<?php
/**
 * User uploaded media.
 *
 * Photographs that came from a worker or an employer, rather than from
 * somebody writing a page.
 *
 * Two problems, one cause
 * -----------------------
 * Every profile photograph is a WordPress attachment, which means it is
 * treated exactly like an image an editor uploaded for an article. That
 * is convenient, because it means metadata stripping, resizing and
 * deletion all work without a custom uploader. It also has two costs
 * that grow with the platform rather than staying still.
 *
 * The first is weight. A profile photograph is only ever shown as a
 * small round avatar, but WordPress generates every registered size for
 * it, including the 480 and 960 pixel sizes that exist for job photos
 * and page images. Four thousand workers is four thousand pairs of files
 * that are created, backed up, and never once requested.
 *
 * The second is the library itself. A media library holding four
 * thousand selfies is not a library anybody can find a page image in.
 * That is not a disk problem, it is a working problem: the person
 * running the site opens Media, and the tool is useless to them.
 *
 * What this does not do
 * ---------------------
 * It does not delete anything, and it does not move files out of the
 * uploads folder. Both upload paths already replace the previous
 * photograph rather than leaving it behind, so there is nothing
 * accumulating to clear up. Hiding is a filter on a query. Every photo
 * is still there, still owned by its profile, and still one dropdown
 * away.
 *
 * @package KaamaseCore
 * @version 1.0.0
 * @since   1.0.0
 */

defined( 'ABSPATH' ) || exit;


/* ==========================================================================
   1. WHAT COUNTS AS A USER PHOTO

   Decided by the attachment's parent rather than by a flag written at
   upload time. media_handle_upload sets the parent to the profile or job
   it belongs to, so this is already true of every photograph uploaded
   before this file existed. A flag would only have been true of the ones
   uploaded after it.
   ========================================================================== */

if ( ! function_exists( 'kaamase_avatar_parent_types' ) ) {
	/**
	 * Post types whose featured image is only ever shown as an avatar.
	 *
	 * @since 1.0.0
	 * @return string[]
	 */
	function kaamase_avatar_parent_types() {
		return array( 'kaamase_worker', 'kaamase_gang', 'kaamase_employer' );
	}
}

if ( ! function_exists( 'kaamase_user_media_parent_types' ) ) {
	/**
	 * Post types whose images came from a member rather than an editor.
	 *
	 * @since 1.0.0
	 * @return string[]
	 */
	function kaamase_user_media_parent_types() {
		return array_merge( kaamase_avatar_parent_types(), array( 'kaamase_job' ) );
	}
}

if ( ! function_exists( 'kaamase_attachment_parent_type' ) ) {
	/**
	 * The post type an attachment hangs from.
	 *
	 * @since 1.0.0
	 * @param int $attachment_id Attachment ID.
	 * @return string Post type, or an empty string when unattached.
	 */
	function kaamase_attachment_parent_type( $attachment_id ) {

		$parent = (int) wp_get_post_parent_id( $attachment_id );

		if ( ! $parent ) {
			return '';
		}

		return (string) get_post_type( $parent );
	}
}


/* ==========================================================================
   2. SIZES

   A profile photograph needs the two avatar sizes and nothing else. A
   job photograph needs the card and wide sizes and has no use for an
   avatar crop.

   WordPress also generates thumbnail, medium and large for everything.
   Those are kept, because they are what the media modal and the block
   editor fall back to, and an attachment with no standard size behaves
   oddly in places that are hard to predict.
   ========================================================================== */

if ( ! function_exists( 'kaamase_limit_user_image_sizes' ) ) {
	/**
	 * Skip generating sizes an uploaded photograph will never be shown at.
	 *
	 * @since 1.0.0
	 * @param array $sizes         Sizes about to be generated.
	 * @param array $metadata      Attachment metadata. Unused.
	 * @param int   $attachment_id Attachment ID.
	 * @return array Filtered sizes.
	 */
	function kaamase_limit_user_image_sizes( $sizes, $metadata = array(), $attachment_id = 0 ) {

		unset( $metadata );

		if ( ! $attachment_id ) {
			return $sizes;
		}

		$parent_type = kaamase_attachment_parent_type( $attachment_id );

		if ( '' === $parent_type ) {
			return $sizes;
		}

		if ( in_array( $parent_type, kaamase_avatar_parent_types(), true ) ) {
			unset( $sizes['kaamase-card'], $sizes['kaamase-wide'] );

			return $sizes;
		}

		if ( 'kaamase_job' === $parent_type ) {
			unset( $sizes['kaamase-avatar'], $sizes['kaamase-avatar-lg'] );
		}

		return $sizes;
	}
}
add_filter( 'intermediate_image_sizes_advanced', 'kaamase_limit_user_image_sizes', 20, 3 );


/* ==========================================================================
   3. KEEPING THE LIBRARY USABLE

   Filtered at the query, on two screens only: the Media page and the
   picker that opens when inserting an image. Everywhere else, including
   the whole front end and every profile query, sees every attachment
   exactly as before.
   ========================================================================== */

if ( ! function_exists( 'kaamase_media_filter_value' ) ) {
	/**
	 * Which set of media the person has asked to see.
	 *
	 * @since 1.0.0
	 * @return string One of site, members or all.
	 */
	function kaamase_media_filter_value() {

		// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Read only view filter.
		$value = isset( $_GET['kaamase_media'] ) ? sanitize_key( wp_unslash( $_GET['kaamase_media'] ) ) : '';

		return in_array( $value, array( 'members', 'all' ), true ) ? $value : 'site';
	}
}

if ( ! function_exists( 'kaamase_is_media_library_query' ) ) {
	/**
	 * True on the Media screen and in the media picker, nowhere else.
	 *
	 * @since 1.0.0
	 * @param WP_Query $query The query being run.
	 * @return bool
	 */
	function kaamase_is_media_library_query( $query ) {

		if ( ! is_admin() || ! $query->is_main_query() ) {

			// The picker runs through ajax, where there is no main query.
			if ( ! wp_doing_ajax() ) {
				return false;
			}
		}

		if ( 'attachment' !== $query->get( 'post_type' ) ) {
			return false;
		}

		if ( wp_doing_ajax() ) {
			// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Checked by core before the query runs.
			$action = isset( $_REQUEST['action'] ) ? sanitize_key( wp_unslash( $_REQUEST['action'] ) ) : '';

			return 'query-attachments' === $action;
		}

		$screen = function_exists( 'get_current_screen' ) ? get_current_screen() : null;

		return $screen instanceof WP_Screen && 'upload' === $screen->id;
	}
}

if ( ! function_exists( 'kaamase_filter_media_library' ) ) {
	/**
	 * Separate member photographs from the site's own images.
	 *
	 * Done with a join on the parent rather than a meta lookup, so it is
	 * correct for photographs uploaded before this file was added.
	 *
	 * @since 1.0.0
	 * @param array    $clauses Query clauses.
	 * @param WP_Query $query   The query being run.
	 * @return array Filtered clauses.
	 */
	function kaamase_filter_media_library( $clauses, $query ) {

		global $wpdb;

		if ( ! kaamase_is_media_library_query( $query ) ) {
			return $clauses;
		}

		$view = kaamase_media_filter_value();

		if ( 'all' === $view ) {
			return $clauses;
		}

		$types = kaamase_user_media_parent_types();
		$list  = "'" . implode( "','", array_map( 'esc_sql', $types ) ) . "'";

		$clauses['join'] .= " LEFT JOIN {$wpdb->posts} AS kaamase_owner"
			. " ON kaamase_owner.ID = {$wpdb->posts}.post_parent ";

		if ( 'members' === $view ) {
			$clauses['where'] .= " AND kaamase_owner.post_type IN ({$list}) ";

			return $clauses;
		}

		$clauses['where'] .= " AND ( kaamase_owner.ID IS NULL"
			. " OR kaamase_owner.post_type NOT IN ({$list}) ) ";

		return $clauses;
	}
}
add_filter( 'posts_clauses', 'kaamase_filter_media_library', 10, 2 );


/* ==========================================================================
   4. THE WAY BACK

   Hidden by default is only reasonable if finding them again is obvious.
   A report about a photograph is one of the things this platform has to
   be able to act on, so the person handling it needs to reach the photo
   without going through the database.
   ========================================================================== */

if ( ! function_exists( 'kaamase_media_view_dropdown' ) ) {
	/**
	 * Add the view chooser above the Media list.
	 *
	 * @since 1.0.0
	 * @param string $post_type Post type of the screen.
	 * @return void
	 */
	function kaamase_media_view_dropdown( $post_type ) {

		if ( 'attachment' !== $post_type ) {
			return;
		}

		$current = kaamase_media_filter_value();

		$options = array(
			'site'    => __( 'Site images', 'kaamase-core' ),
			'members' => __( 'Member photos', 'kaamase-core' ),
			'all'     => __( 'Everything', 'kaamase-core' ),
		);

		echo '<label class="screen-reader-text" for="kaamase_media">'
			. esc_html__( 'Which images to show', 'kaamase-core' )
			. '</label>';

		echo '<select name="kaamase_media" id="kaamase_media">';

		foreach ( $options as $value => $label ) {
			printf(
				'<option value="%1$s"%2$s>%3$s</option>',
				esc_attr( $value ),
				selected( $current, $value, false ),
				esc_html( $label )
			);
		}

		echo '</select>';
	}
}
add_action( 'restrict_manage_posts', 'kaamase_media_view_dropdown' );

if ( ! function_exists( 'kaamase_media_screen_note' ) ) {
	/**
	 * Say what is being hidden, once, on the Media screen.
	 *
	 * A filter that silently removes rows is how somebody concludes their
	 * uploads have vanished.
	 *
	 * @since 1.0.0
	 * @return void
	 */
	function kaamase_media_screen_note() {

		$screen = get_current_screen();

		if ( ! $screen instanceof WP_Screen || 'upload' !== $screen->id ) {
			return;
		}

		if ( 'site' !== kaamase_media_filter_value() ) {
			return;
		}

		echo '<div class="notice notice-info"><p>'
			. esc_html__( 'Photos uploaded by workers and employers are hidden here so this stays a library of the site\'s own images. Use the dropdown above to see them.', 'kaamase-core' )
			. '</p></div>';
	}
}
add_action( 'admin_notices', 'kaamase_media_screen_note' );