<?php
/**
 * What the plan actually gives you.
 *
 * Two fixes to the same problem: somebody hits a limit, is told they can
 * pay, and is given nothing they can act on.
 *
 * The link that was not a link
 * ----------------------------
 * The payment plugin appends the address of the plans page to the end of
 * the message. It has to send plain text, because that same sentence is
 * also returned through the API to the app, where markup would show up
 * as literal angle brackets. So on the website the address printed as
 * text nobody could tap.
 *
 * That is fixed here rather than there: the sentence stays plain, and
 * the website turns it into a button at the point where it is being
 * drawn on a page.
 *
 * The pitch that pitched nothing
 * ------------------------------
 * The plans page listed what a plan grants by reading the meters
 * straight out: plus one thousand contact lookups a day. True, and
 * meaningless. It does not say what a lookup is, it does not say what
 * the free account gets, and it never mentions the thing people are
 * actually buying, which is the tick.
 *
 * The replacement says the tick first, then gives the real numbers with
 * the free number beside them so the difference is visible. No claim of
 * unlimited anything. The numbers come from the live settings, so this
 * page cannot drift away from what the platform actually enforces, and
 * changing a limit on the Limits screen changes the sales copy at the
 * same moment.
 *
 * Nothing in the payment plugin is edited. The plans shortcode is
 * wrapped rather than replaced, and if its markup ever changes the
 * original output is returned untouched.
 *
 * @package KaamaseCore
 * @version 1.2.0
 * @since   1.0.0
 */

defined( 'ABSPATH' ) || exit;


/* ==========================================================================
   1. NOT SELLING TO SOMEBODY WHO ALREADY BOUGHT

   A limit is a limit. The cap on the paid plan is high enough that
   nobody reaches it by hiring, but somebody will, and when they do the
   platform was telling them they could pay to fix it. They already had.

   The core message assumes anybody hitting a wall is a candidate for
   upgrading, and the payment plugin appends the plans page to it for
   anybody signed in. Neither asks whether this person is already on the
   plan. Asked here, once, and the answer changes the sentence rather
   than hiding it: they still need to know why they were stopped.

   The same corrected sentence goes to the app, so both say the same
   thing to the same person.
   ========================================================================== */

if ( ! function_exists( 'kaamase_plan_pitch_already_paid' ) ) {
	/**
	 * Say what happened, without offering to sell anything.
	 *
	 * @since 1.1.0
	 * @param string $message The message so far.
	 * @param string $key     Meter key.
	 * @return string
	 */
	function kaamase_plan_pitch_already_paid( $message, $key ) {

		if ( ! function_exists( 'kaamase_pay_is_active' ) || ! kaamase_pay_is_active( get_current_user_id() ) ) {
			return $message;
		}

		$said = array(
			'contact_reveals' => __( 'You have used today\'s contact lookups. That cap is on every account including yours, and it is there to stop numbers being harvested. It starts again after midnight.', 'kaamase-core' ),
			'urgent_jobs'     => __( 'You have as many urgent jobs running as one account can have at once. Close one and you can mark another.', 'kaamase-core' ),
			'jobs_per_day'    => __( 'You have posted all the jobs one account can post in a day. It starts again after midnight.', 'kaamase-core' ),
			'job_photos'      => __( 'This job has all the pictures one job can carry. Remove one to put a different one up.', 'kaamase-core' ),
		);

		return $said[ $key ] ?? $message;
	}
}
add_filter( 'kaamase_limit_reached_message', 'kaamase_plan_pitch_already_paid', 20, 2 );


/* ==========================================================================
   2. MAKING THE ADDRESS TAPPABLE
   ========================================================================== */

if ( ! function_exists( 'kaamase_plan_pitch_name' ) ) {
	/**
	 * The plan name, when there is exactly one on sale.
	 *
	 * Naming it reads better than saying the plan, and falling back the
	 * moment a second plan exists keeps it from ever being wrong.
	 *
	 * @since 1.0.0
	 * @return string
	 */
	function kaamase_plan_pitch_name() {

		if ( ! function_exists( 'kaamase_pay_active_plans' ) ) {
			return '';
		}

		$plans = kaamase_pay_active_plans();

		if ( 1 !== count( $plans ) ) {
			return '';
		}

		$plan = reset( $plans );

		return isset( $plan['name'] ) ? (string) $plan['name'] : '';
	}
}

if ( ! function_exists( 'kaamase_plan_pitch_link' ) ) {
	/**
	 * Turn the trailing address into a button.
	 *
	 * Matched against the exact sentence the payment plugin builds, so
	 * a miss changes nothing and the page renders as it does today.
	 *
	 * @since 1.0.0
	 * @param string $content Page content.
	 * @return string
	 */
	function kaamase_plan_pitch_link( $content ) {

		if ( is_admin() || ! function_exists( 'kaamase_pay_plans_url' ) ) {
			return $content;
		}

		$page = kaamase_pay_plans_url();

		if ( ! $page || false === strpos( $content, $page ) ) {
			return $content;
		}

		$tail = ' ' . sprintf(
			/* translators: %s: link to the plans page. Must match the payment plugin exactly. */
			__( 'See what is available: %s', 'kaamase-pay' ),
			$page
		);

		$needle = esc_html( $tail ) . '</p>';

		if ( false === strpos( $content, $needle ) ) {
			return $content;
		}

		$name = kaamase_plan_pitch_name();

		$label = $name
			? sprintf(
				/* translators: %s: the plan name */
				__( 'See what %s gives you', 'kaamase-core' ),
				$name
			)
			: __( 'See what you get', 'kaamase-core' );

		$button = sprintf(
			'<a class="ka-btn ka-btn--action ka-btn--sm ka-mt-4" href="%1$s">%2$s</a>',
			esc_url( $page ),
			esc_html( $label )
		);

		return str_replace( $needle, '</p>' . $button, $content );
	}
}
add_filter( 'the_content', 'kaamase_plan_pitch_link', 6 );


/* ==========================================================================
   3. WHAT A PLAN GIVES, IN WORDS
   ========================================================================== */

if ( ! function_exists( 'kaamase_plan_pitch_lines' ) ) {
	/**
	 * The benefit list for one plan.
	 *
	 * Every number is read live rather than written down here. The free
	 * allowance comes from the Limits screen and the extra comes from
	 * the plan record, so the sentence on the sales page is arithmetic
	 * on the same two values the platform enforces. A page that promises
	 * something the code does not give is worse than no page.
	 *
	 * @since 1.0.0
	 * @param array $plan The plan record.
	 * @return string[] Lines of markup.
	 */
	function kaamase_plan_pitch_lines( $plan ) {

		$lines = array();

		foreach ( kaamase_plan_pitch_parts( $plan ) as $part ) {
			$lines[] = '<li><strong>' . esc_html( $part['title'] ) . '</strong> ' . esc_html( $part['body'] ) . '</li>';
		}

		return $lines;
	}
}

if ( ! function_exists( 'kaamase_plan_pitch_parts' ) ) {
	/**
	 * The benefit list as plain title and body pairs.
	 *
	 * Separated from the markup so the app can be handed the same
	 * sentences through the API. Two copies of sales text drift apart
	 * within a month, and the one that drifts is always the one nobody
	 * remembers is there.
	 *
	 * @since 1.0.0
	 * @param array $plan The plan record.
	 * @return array[] Each with title and body.
	 */
	function kaamase_plan_pitch_parts( $plan ) {

		$meters = function_exists( 'kaamase_meters' ) ? kaamase_meters() : array();
		$grants = (array) ( $plan['grants'] ?? array() );

		/*
		 * The tick goes first, because it is the only thing on this
		 * list a person cannot get by waiting until tomorrow, and
		 * because it is the reason an employer is believed by somebody
		 * deciding whether to answer an unknown number.
		 *
		 * Worded as a call that has to happen rather than as something
		 * paying hands over, because that is how it works. Paying puts
		 * somebody in the queue to be rung. The mark goes on after the
		 * conversation.
		 */
		$parts = array(
			array(
				'title' => __( 'A tick on your profile.', 'kaamase-core' ),
				'body'  => __( 'We ring you and speak to you. Once we have, the mark goes on your profile and stays there. A worker looking at an unknown number can see that somebody at Kaam Ase has checked who you are, which is the difference between a call answered and a call ignored.', 'kaamase-core' ),
			),
		);

		foreach ( $grants as $key => $extra ) {

			$extra = (int) $extra;

			if ( $extra < 1 || ! isset( $meters[ $key ] ) ) {
				continue;
			}

			$free  = function_exists( 'kaamase_free_allowance' ) ? (int) kaamase_free_allowance( $key ) : (int) $meters[ $key ]['free'];
			$total = $free + $extra;

			$parts[] = kaamase_plan_pitch_line( $key, $meters[ $key ], $free, $total );
		}

		return $parts;
	}
}

if ( ! function_exists( 'kaamase_plan_pitch_line' ) ) {
	/**
	 * One benefit, written for the meter it came from.
	 *
	 * @since 1.0.0
	 * @param string $key   Meter key.
	 * @param array  $meter Meter definition.
	 * @param int    $free  What a free account gets.
	 * @param int    $total What this plan gets.
	 * @return array Title and body.
	 */
	function kaamase_plan_pitch_line( $key, $meter, $free, $total ) {

		$free_n  = number_format_i18n( $free );
		$total_n = number_format_i18n( $total );

		switch ( $key ) {

			case 'contact_reveals':
				$title = __( 'Numbers whenever you need them.', 'kaamase-core' );
				$body  = sprintf(
					/* translators: 1: free lookups a day, 2: lookups a day on this plan */
					__( 'A free account can get the phone number of %1$s workers in a day. On this plan it is %2$s. If you are ringing round twenty masons to find four who are free on Thursday, you will not be stopped halfway.', 'kaamase-core' ),
					$free_n,
					$total_n
				);
				break;

			case 'urgent_jobs':
				$title = __( 'Mark work urgent as often as you need.', 'kaamase-core' );
				$body  = sprintf(
					/* translators: 1: free urgent jobs, 2: urgent jobs on this plan */
					__( 'A free account runs %1$s urgent job at a time and has to wait for it to close before marking another. On this plan you can run %2$s at once, so a week with several jobs starting tomorrow is not a problem.', 'kaamase-core' ),
					$free_n,
					$total_n
				);
				break;

			case 'jobs_per_day':
				$title = __( 'Post as much work as you have.', 'kaamase-core' );
				$body  = sprintf(
					/* translators: 1: free jobs a day, 2: jobs a day on this plan */
					__( 'A free account posts %1$s jobs in a day. On this plan it is %2$s.', 'kaamase-core' ),
					$free_n,
					$total_n
				);
				break;

			case 'job_photos':
				$title = __( 'More pictures on a job.', 'kaamase-core' );
				$body  = sprintf(
					/* translators: 1: free photos, 2: photos on this plan */
					__( 'A free account puts %1$s picture on a job. On this plan it is %2$s. A photo of the site gets a job answered far more often than words alone.', 'kaamase-core' ),
					$free_n,
					$total_n
				);
				break;

			default:
				$title = (string) $meter['label'] . '.';
				$body  = sprintf(
					/* translators: 1: free amount, 2: amount on this plan */
					__( '%1$s on a free account, %2$s on this plan.', 'kaamase-core' ),
					$free_n,
					$total_n
				);
				break;
		}

		return array(
			'title' => $title,
			'body'  => $body,
		);
	}
}


/* ==========================================================================
   4. PUTTING IT ON THE PLANS PAGE
   ========================================================================== */

if ( ! function_exists( 'kaamase_plan_pitch_shortcode' ) ) {
	/**
	 * The plans page, with the mechanical list swapped for the real one.
	 *
	 * Every safety check here exists so that a change in the payment
	 * plugin's markup makes this do nothing at all rather than produce a
	 * page with the wrong plan's benefits under the wrong price. The
	 * counts have to line up exactly before anything is replaced.
	 *
	 * @since 1.0.0
	 * @return string Markup.
	 */
	function kaamase_plan_pitch_shortcode() {

		$html = (string) kaamase_pay_plans_shortcode();

		if ( ! function_exists( 'kaamase_pay_active_plans' ) ) {
			return $html;
		}

		$blocks = array();

		foreach ( kaamase_pay_active_plans() as $plan ) {

			$has_grant = false;

			foreach ( (array) ( $plan['grants'] ?? array() ) as $amount ) {
				if ( (int) $amount > 0 ) {
					$has_grant = true;
					break;
				}
			}

			if ( ! $has_grant ) {
				continue;
			}

			$lines = kaamase_plan_pitch_lines( $plan );

			if ( empty( $lines ) ) {
				continue;
			}

			$blocks[] = '<p class="kp-plan__gives-title"><strong>'
				. esc_html__( 'What you get', 'kaamase-core' )
				. '</strong></p><ul class="kp-plan__gives kp-plan__gives--said">'
				. implode( '', $lines )
				. '</ul>';
		}

		if ( empty( $blocks ) ) {
			return $html;
		}

		$found = preg_match_all( '#<ul class="kp-plan__gives">.*?</ul>#s', $html, $matches );

		if ( $found !== count( $blocks ) ) {
			return $html;
		}

		$at = 0;

		$html = preg_replace_callback(
			'#<ul class="kp-plan__gives">.*?</ul>#s',
			static function () use ( $blocks, &$at ) {
				return $blocks[ $at++ ];
			},
			$html
		);

		return kaamase_plan_pitch_styles() . $html;
	}
}

if ( ! function_exists( 'kaamase_plan_pitch_styles' ) ) {
	/**
	 * Enough styling to make a list of sentences readable.
	 *
	 * @since 1.0.0
	 * @return string
	 */
	function kaamase_plan_pitch_styles() {

		return '<style id="kaamase-plan-pitch">'
			. '.kp-plan__gives--said{list-style:none;margin:0 0 1rem;padding:0}'
			. '.kp-plan__gives--said li{padding:.5rem 0;line-height:1.5}'
			. '.kp-plan__gives-title{margin:0 0 .25rem}'
			. '</style>';
	}
}

if ( ! function_exists( 'kaamase_plan_pitch_take_over' ) ) {
	/**
	 * Wrap the plans shortcode.
	 *
	 * @since 1.0.0
	 * @return void
	 */
	function kaamase_plan_pitch_take_over() {

		if ( ! function_exists( 'kaamase_pay_plans_shortcode' ) || ! shortcode_exists( 'kaamase_plans' ) ) {
			return;
		}

		remove_shortcode( 'kaamase_plans' );
		add_shortcode( 'kaamase_plans', 'kaamase_plan_pitch_shortcode' );
	}
}
add_action( 'init', 'kaamase_plan_pitch_take_over', 20 );


/* ==========================================================================
   5. THE SAME SENTENCES FOR THE APP

   Sent with the account so the app renders what the website says rather
   than carrying its own copy of the numbers. Change a limit on the
   Limits screen and both move together.
   ========================================================================== */

if ( ! function_exists( 'kaamase_plan_pitch_offer_me' ) ) {
	/**
	 * Send the name of the plan that is on sale.
	 *
	 * Separate from me.plan.name, which is the plan this account is
	 * holding and is deliberately an empty string when it holds none.
	 * That is correct for what it describes and useless for a button
	 * that has to say Get something, on a screen that by definition only
	 * appears to somebody with no plan.
	 *
	 * Without this the app has to carry the plan name written into it as
	 * a fallback, which works exactly until the plan is renamed, and
	 * then goes on saying the old name with nothing to show anybody it
	 * is wrong.
	 *
	 * Empty when nothing is on sale, so a button with nothing to sell
	 * can be hidden rather than guessed at.
	 *
	 * @since 1.2.0
	 * @param array $me      The account object.
	 * @param int   $user_id User ID.
	 * @return array
	 */
	function kaamase_plan_pitch_offer_me( $me, $user_id ) {

		unset( $user_id );

		if ( ! function_exists( 'kaamase_pay_active_plans' ) ) {
			return $me;
		}

		$plans = kaamase_pay_active_plans();

		if ( empty( $plans ) ) {

			$me['plan_offer'] = array(
				'id'   => '',
				'name' => '',
			);

			return $me;
		}

		$id   = (string) key( $plans );
		$plan = reset( $plans );

		$me['plan_offer'] = array(
			'id'   => $id,
			'name' => isset( $plan['name'] ) ? (string) $plan['name'] : '',
		);

		return $me;
	}
}
add_filter( 'kaamase_shape_me', 'kaamase_plan_pitch_offer_me', 21, 2 );

if ( ! function_exists( 'kaamase_plan_pitch_shape_me' ) ) {
	/**
	 * Add the benefit list to the account object.
	 *
	 * @since 1.0.0
	 * @param array $me      The account object.
	 * @param int   $user_id User ID.
	 * @return array
	 */
	function kaamase_plan_pitch_shape_me( $me, $user_id ) {

		unset( $user_id );

		if ( ! function_exists( 'kaamase_pay_active_plans' ) ) {
			return $me;
		}

		$plans = kaamase_pay_active_plans();

		if ( empty( $plans ) ) {
			return $me;
		}

		$plan = reset( $plans );

		$me['plan_pitch'] = array_values( kaamase_plan_pitch_parts( $plan ) );

		return $me;
	}
}
add_filter( 'kaamase_shape_me', 'kaamase_plan_pitch_shape_me', 22, 2 );