<?php
/**
 * Posted for somebody else.
 *
 * A job that Kaam Ase puts up on behalf of an employer who is not on the
 * platform, carrying that employer's name and that employer's number.
 *
 * Why this exists
 * ---------------
 * A hiring platform with workers and no jobs is not a hiring platform.
 * Early on the workers arrive first, because they have more reason to
 * look, and they arrive to an empty jobs page and do not come back. The
 * jobs exist: they are sitting in local groups and on message boards,
 * written by people who have never heard of this site.
 *
 * So the owner copies one across. The rule that makes it honest is the
 * number: it is the employer's, never ours. A worker who taps call
 * reaches the person actually hiring, and Kaam Ase is out of the way. We
 * are not a middleman on these, we are a noticeboard, and the wording on
 * the job says so.
 *
 * What this file will not do
 * --------------------------
 * It will not invent jobs. Nothing here generates or scrapes anything.
 * It is a form somebody fills in by hand, having read the original and
 * spoken to the employer. A job that turns out to be nonsense costs a
 * worker a day's wages and a bus fare, which is the whole reason the
 * screening queue exists for everybody else.
 *
 * It also does not link the job to any employer profile. The name shows,
 * the ratings do not, because there is nobody here to rate.
 *
 * @package KaamaseCore
 * @version 1.1.0
 * @since   1.0.0
 */

defined( 'ABSPATH' ) || exit;


/* ==========================================================================
   1. THE TWO EXTRA FIELDS
   ========================================================================== */

if ( ! function_exists( 'kaamase_posted_for_fields' ) ) {
	/**
	 * Register the fields that mark a job as posted for somebody.
	 *
	 * Done through the schema filter so fields.php stays the one place
	 * that knows what a field is, and this file only says what it needs.
	 *
	 * @since 1.0.0
	 * @param array[] $schema Field definitions keyed by post type.
	 * @return array[]
	 */
	function kaamase_posted_for_fields( $schema ) {

		if ( ! isset( $schema['kaamase_job'] ) ) {
			return $schema;
		}

		$schema['kaamase_job']['posted_for'] = array(
			'type'    => 'bool',
			'default' => false,
			'label'   => __( 'Posted for an outside employer', 'kaamase-core' ),
		);

		$schema['kaamase_job']['posted_source'] = array(
			'type'    => 'string',
			'private' => true,
			'label'   => __( 'Where this job came from', 'kaamase-core' ),
		);

		return $schema;
	}
}
add_filter( 'kaamase_field_schema', 'kaamase_posted_for_fields' );

if ( ! function_exists( 'kaamase_job_is_posted_for' ) ) {
	/**
	 * Whether this job was put up on somebody else's behalf.
	 *
	 * @since 1.0.0
	 * @param int $job_id Job ID.
	 * @return bool
	 */
	function kaamase_job_is_posted_for( $job_id ) {

		return (bool) kaamase_read_field( (int) $job_id, 'posted_for' );
	}
}


/* ==========================================================================
   2. SAYING SO, ON THE JOB PAGE AND IN THE APP
   ========================================================================== */

if ( ! function_exists( 'kaamase_posted_for_notice' ) ) {
	/**
	 * Put a line above the job saying who it belongs to.
	 *
	 * A worker deciding whether to ring is entitled to know that the
	 * person answering did not write this and is not us. Leaving it
	 * unsaid would be the platform quietly taking credit for somebody
	 * else's hiring, which is the one thing that would make copying
	 * these across dishonest.
	 *
	 * @since 1.0.0
	 * @param string $content The job description.
	 * @return string
	 */
	function kaamase_posted_for_notice( $content ) {

		if ( ! is_singular( 'kaamase_job' ) || ! in_the_loop() || ! is_main_query() ) {
			return $content;
		}

		$job_id = get_the_ID();

		if ( ! kaamase_job_is_posted_for( $job_id ) ) {
			return $content;
		}

		$name = (string) kaamase_read_field( $job_id, 'employer_name' );

		$notice = sprintf(
			'<p class="ka-hint"><strong>%1$s</strong> %2$s</p>',
			esc_html__( 'Shared by Kaam Ase.', 'kaamase-core' ),
			esc_html(
				$name
					? sprintf(
						/* translators: %s: the employer's name */
						__( '%s is hiring, not us. The number on this job is theirs, so you speak to them directly.', 'kaamase-core' ),
						$name
					)
					: __( 'The number on this job belongs to the employer, not to us. You speak to them directly.', 'kaamase-core' )
			)
		);

		return $notice . $content;
	}
}
add_filter( 'the_content', 'kaamase_posted_for_notice' );

if ( ! function_exists( 'kaamase_posted_for_shape' ) ) {
	/**
	 * Tell the app about it too.
	 *
	 * @since 1.0.0
	 * @param array   $out  Shaped job.
	 * @param WP_Post $post The job.
	 * @return array
	 */
	function kaamase_posted_for_shape( $out, $post ) {

		$out['posted_for'] = kaamase_job_is_posted_for( $post->ID );

		return $out;
	}
}
add_filter( 'kaamase_shape_job', 'kaamase_posted_for_shape', 16, 2 );


/* ==========================================================================
   3. THE SCREEN
   ========================================================================== */

if ( ! function_exists( 'kaamase_posted_for_menu' ) ) {
	/**
	 * Add the screen under Kaam Ase.
	 *
	 * @since 1.0.0
	 * @return void
	 */
	function kaamase_posted_for_menu() {

		add_submenu_page(
			'kaamase',
			__( 'Post a job for somebody', 'kaamase-core' ),
			__( 'Post for somebody', 'kaamase-core' ),
			'edit_others_kaamase_jobs',
			'kaamase-post-for',
			'kaamase_posted_for_page'
		);
	}
}
add_action( 'admin_menu', 'kaamase_posted_for_menu', 22 );

if ( ! function_exists( 'kaamase_posted_for_page' ) ) {
	/**
	 * Render the form.
	 *
	 * @since 1.0.0
	 * @return void
	 */
	function kaamase_posted_for_page() {

		if ( ! current_user_can( 'edit_others_kaamase_jobs' ) ) {
			return;
		}

		$errors = get_transient( 'kaamase_post_for_' . get_current_user_id() );

		delete_transient( 'kaamase_post_for_' . get_current_user_id() );

		// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Read only notice.
		$posted = isset( $_GET['posted'] ) ? absint( $_GET['posted'] ) : 0;
		?>
		<div class="wrap">

			<h1><?php esc_html_e( 'Post a job for somebody', 'kaamase-core' ); ?></h1>

			<?php if ( $posted ) : ?>
				<div class="notice notice-success is-dismissible">
					<p>
						<?php esc_html_e( 'The job is up.', 'kaamase-core' ); ?>
						<a href="<?php echo esc_url( (string) get_permalink( $posted ) ); ?>" target="_blank" rel="noopener">
							<?php esc_html_e( 'Open it', 'kaamase-core' ); ?>
						</a>
					</p>
				</div>
			<?php endif; ?>

			<?php if ( ! empty( $errors ) && is_array( $errors ) ) : ?>
				<div class="notice notice-error">
					<?php foreach ( $errors as $error ) : ?>
						<p><?php echo esc_html( $error ); ?></p>
					<?php endforeach; ?>
				</div>
			<?php endif; ?>

			<p style="max-width:45em">
				<?php esc_html_e( 'For jobs you have seen elsewhere and checked yourself. The job goes up under Kaam Ase with the employer\'s name on it, and workers get the employer\'s number, never yours. Ring the employer first and make sure the job is real and that they are happy to be listed.', 'kaamase-core' ); ?>
			</p>

			<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" enctype="multipart/form-data">

				<input type="hidden" name="action" value="kaamase_post_for">
				<?php wp_nonce_field( 'kaamase_post_for' ); ?>

				<h2><?php esc_html_e( 'Who is hiring', 'kaamase-core' ); ?></h2>

				<table class="form-table" role="presentation">

					<tr>
						<th scope="row">
							<label for="kaamase-pf-name"><?php esc_html_e( 'Their name', 'kaamase-core' ); ?></label>
						</th>
						<td>
							<input class="regular-text" type="text" id="kaamase-pf-name" name="kaamase_employer_name" required
								placeholder="<?php esc_attr_e( 'The person or firm hiring', 'kaamase-core' ); ?>">
							<p class="description"><?php esc_html_e( 'This shows on the job as who is hiring.', 'kaamase-core' ); ?></p>
						</td>
					</tr>

					<tr>
						<th scope="row">
							<label for="kaamase-pf-phone"><?php esc_html_e( 'Their number', 'kaamase-core' ); ?></label>
						</th>
						<td>
							<input class="regular-text" type="tel" id="kaamase-pf-phone" name="kaamase_contact_phone" required
								maxlength="15" placeholder="<?php esc_attr_e( '10 digits', 'kaamase-core' ); ?>">
							<p class="description"><?php esc_html_e( 'What a worker gets when they ask for contact details. Never shown openly on the page.', 'kaamase-core' ); ?></p>
						</td>
					</tr>

					<tr>
						<th scope="row">
							<label for="kaamase-pf-source"><?php esc_html_e( 'Where you saw it', 'kaamase-core' ); ?></label>
						</th>
						<td>
							<input class="large-text" type="text" id="kaamase-pf-source" name="kaamase_source"
								placeholder="<?php esc_attr_e( 'Group name, link, or who told you. Only you see this.', 'kaamase-core' ); ?>">
						</td>
					</tr>

				</table>

				<h2><?php esc_html_e( 'The job', 'kaamase-core' ); ?></h2>

				<table class="form-table" role="presentation">

					<tr>
						<th scope="row">
							<label for="kaamase-pf-trade"><?php esc_html_e( 'Trade', 'kaamase-core' ); ?></label>
						</th>
						<td>
							<select id="kaamase-pf-trade" name="kaamase_trade" required>
								<option value=""><?php esc_html_e( 'Choose the trade', 'kaamase-core' ); ?></option>
								<?php foreach ( kaamase_trade_choices() as $group => $trades ) : ?>
									<optgroup label="<?php echo esc_attr( $group ); ?>">
										<?php foreach ( $trades as $slug => $name ) : ?>
											<option value="<?php echo esc_attr( $slug ); ?>"><?php echo esc_html( $name ); ?></option>
										<?php endforeach; ?>
									</optgroup>
								<?php endforeach; ?>
							</select>
						</td>
					</tr>

					<tr>
						<th scope="row">
							<label for="kaamase-pf-district"><?php esc_html_e( 'District', 'kaamase-core' ); ?></label>
						</th>
						<td>
							<select id="kaamase-pf-district" name="kaamase_district" required>
								<option value=""><?php esc_html_e( 'Choose the district', 'kaamase-core' ); ?></option>
								<?php foreach ( kaamase_district_choices() as $slug => $name ) : ?>
									<option value="<?php echo esc_attr( $slug ); ?>"><?php echo esc_html( $name ); ?></option>
								<?php endforeach; ?>
							</select>
						</td>
					</tr>

					<tr>
						<th scope="row">
							<label for="kaamase-pf-town"><?php esc_html_e( 'Town or village', 'kaamase-core' ); ?></label>
						</th>
						<td>
							<input class="regular-text" type="text" id="kaamase-pf-town" name="kaamase_town">
						</td>
					</tr>

					<tr>
						<th scope="row">
							<label for="kaamase-pf-pay"><?php esc_html_e( 'Pay', 'kaamase-core' ); ?></label>
						</th>
						<td>
							<input type="number" id="kaamase-pf-pay" name="kaamase_pay_amount" min="1" step="1" required
								placeholder="<?php esc_attr_e( 'Rupees', 'kaamase-core' ); ?>">
							<select name="kaamase_pay_unit">
								<option value="day"><?php esc_html_e( 'per day', 'kaamase-core' ); ?></option>
								<option value="month"><?php esc_html_e( 'per month', 'kaamase-core' ); ?></option>
								<option value="job"><?php esc_html_e( 'for the whole job', 'kaamase-core' ); ?></option>
								<option value="hour"><?php esc_html_e( 'per hour', 'kaamase-core' ); ?></option>
							</select>
							<p class="description">
								<?php esc_html_e( 'If the original says negotiable, ask the employer for a figure when you ring. A job with no rate gets almost no answers.', 'kaamase-core' ); ?>
							</p>
						</td>
					</tr>

					<tr>
						<th scope="row">
							<label for="kaamase-pf-count"><?php esc_html_e( 'How many workers', 'kaamase-core' ); ?></label>
						</th>
						<td>
							<input type="number" id="kaamase-pf-count" name="kaamase_workers_needed" min="1" max="200" value="1" required>
						</td>
					</tr>

					<tr>
						<th scope="row">
							<label for="kaamase-pf-title"><?php esc_html_e( 'Title', 'kaamase-core' ); ?></label>
						</th>
						<td>
							<input class="large-text" type="text" id="kaamase-pf-title" name="kaamase_title"
								placeholder="<?php esc_attr_e( 'Leave blank and one is written for you', 'kaamase-core' ); ?>">
						</td>
					</tr>

					<tr>
						<th scope="row">
							<label for="kaamase-pf-description"><?php esc_html_e( 'Details', 'kaamase-core' ); ?></label>
						</th>
						<td>
							<textarea class="large-text" id="kaamase-pf-description" name="kaamase_description" rows="6"
								placeholder="<?php esc_attr_e( 'What the work is, in your own words.', 'kaamase-core' ); ?>"></textarea>
						</td>
					</tr>

					<?php if ( function_exists( 'kaamase_job_photo_limit' ) ) : ?>
						<tr>
							<th scope="row">
								<label for="kaamase-pf-photos"><?php esc_html_e( 'Pictures', 'kaamase-core' ); ?></label>
							</th>
							<td>
								<input type="file" id="kaamase-pf-photos" name="kaamase_photos[]" multiple
									accept="<?php echo esc_attr( kaamase_job_photo_accept() ); ?>">
								<p class="description">
									<?php
									echo esc_html(
										sprintf(
											/* translators: %s: how many pictures may be added */
											__( 'Up to %s. A screenshot of the original post is not a picture of the work, so use a photo of the site or the shop where you can get one.', 'kaamase-core' ),
											number_format_i18n( kaamase_job_photo_limit() )
										)
									);
									?>
								</p>
							</td>
						</tr>
					<?php endif; ?>

					<tr>
						<th scope="row">
							<label for="kaamase-pf-start"><?php esc_html_e( 'Start date', 'kaamase-core' ); ?></label>
						</th>
						<td>
							<input type="date" id="kaamase-pf-start" name="kaamase_start_date">
						</td>
					</tr>

					<tr>
						<th scope="row">
							<label for="kaamase-pf-duration"><?php esc_html_e( 'How long the work lasts', 'kaamase-core' ); ?></label>
						</th>
						<td>
							<input class="regular-text" type="text" id="kaamase-pf-duration" name="kaamase_duration"
								placeholder="<?php esc_attr_e( 'Two weeks, one month, ongoing', 'kaamase-core' ); ?>">
						</td>
					</tr>

					<tr>
						<th scope="row"><?php esc_html_e( 'Extras', 'kaamase-core' ); ?></th>
						<td>
							<label><input type="checkbox" name="kaamase_urgent" value="1"> <?php esc_html_e( 'Urgent, needed today or tomorrow', 'kaamase-core' ); ?></label><br>
							<label><input type="checkbox" name="kaamase_food" value="1"> <?php esc_html_e( 'Food provided', 'kaamase-core' ); ?></label><br>
							<label><input type="checkbox" name="kaamase_stay" value="1"> <?php esc_html_e( 'Stay provided', 'kaamase-core' ); ?></label><br>
							<label><input type="checkbox" name="kaamase_transport" value="1"> <?php esc_html_e( 'Transport provided', 'kaamase-core' ); ?></label>
						</td>
					</tr>

				</table>

				<?php submit_button( __( 'Put this job up', 'kaamase-core' ) ); ?>

			</form>

		</div>
		<?php
	}
}


/* ==========================================================================
   4. HANDLING THE FORM
   ========================================================================== */

if ( ! function_exists( 'kaamase_posted_for_handle' ) ) {
	/**
	 * Save the job, then put the employer's name and number on it.
	 *
	 * The save goes through kaamase_save_job() like every other job, so
	 * the wage floor, the phone check and the screening queue all still
	 * apply. Only afterwards is the ownership rewritten, because the
	 * fields that say who is hiring are filled from the author's own
	 * profile and the author here is staff.
	 *
	 * @since 1.0.0
	 * @return void
	 */
	function kaamase_posted_for_handle() {

		if ( ! current_user_can( 'edit_others_kaamase_jobs' ) ) {
			wp_die( esc_html__( 'You cannot do that.', 'kaamase-core' ) );
		}

		check_admin_referer( 'kaamase_post_for' );

		$user_id = get_current_user_id();
		$back    = admin_url( 'admin.php?page=kaamase-post-for' );

		// phpcs:disable WordPress.Security.NonceVerification.Missing -- Checked above.
		$name   = isset( $_POST['kaamase_employer_name'] ) ? sanitize_text_field( wp_unslash( $_POST['kaamase_employer_name'] ) ) : '';
		$phone  = isset( $_POST['kaamase_contact_phone'] ) ? sanitize_text_field( wp_unslash( $_POST['kaamase_contact_phone'] ) ) : '';
		$source = isset( $_POST['kaamase_source'] ) ? sanitize_text_field( wp_unslash( $_POST['kaamase_source'] ) ) : '';

		$values = array(
			'title'              => isset( $_POST['kaamase_title'] ) ? sanitize_text_field( wp_unslash( $_POST['kaamase_title'] ) ) : '',
			'description'        => isset( $_POST['kaamase_description'] ) ? sanitize_textarea_field( wp_unslash( $_POST['kaamase_description'] ) ) : '',
			'trade'              => isset( $_POST['kaamase_trade'] ) ? kaamase_match_trade( sanitize_text_field( wp_unslash( $_POST['kaamase_trade'] ) ) ) : '',
			'district'           => isset( $_POST['kaamase_district'] ) ? kaamase_match_district( sanitize_text_field( wp_unslash( $_POST['kaamase_district'] ) ) ) : '',
			'town'               => isset( $_POST['kaamase_town'] ) ? sanitize_text_field( wp_unslash( $_POST['kaamase_town'] ) ) : '',
			'pay_amount'         => isset( $_POST['kaamase_pay_amount'] ) ? absint( $_POST['kaamase_pay_amount'] ) : 0,
			'pay_unit'           => isset( $_POST['kaamase_pay_unit'] ) ? sanitize_key( wp_unslash( $_POST['kaamase_pay_unit'] ) ) : 'day',
			'workers_needed'     => isset( $_POST['kaamase_workers_needed'] ) ? absint( $_POST['kaamase_workers_needed'] ) : 1,
			'start_date'         => isset( $_POST['kaamase_start_date'] ) ? sanitize_text_field( wp_unslash( $_POST['kaamase_start_date'] ) ) : '',
			'duration'           => isset( $_POST['kaamase_duration'] ) ? sanitize_text_field( wp_unslash( $_POST['kaamase_duration'] ) ) : '',
			'urgent'             => ! empty( $_POST['kaamase_urgent'] ),
			'food_provided'      => ! empty( $_POST['kaamase_food'] ),
			'stay_provided'      => ! empty( $_POST['kaamase_stay'] ),
			'transport_provided' => ! empty( $_POST['kaamase_transport'] ),
			'contact_phone'      => $phone,
		);
		// phpcs:enable WordPress.Security.NonceVerification.Missing

		$errors = array();

		if ( '' === trim( $name ) ) {
			$errors[] = __( 'Put the name of the person or firm hiring.', 'kaamase-core' );
		}

		if ( '' === kaamase_sanitize_phone( $phone ) ) {
			$errors[] = __( 'Put their number. Ten digits starting with 6, 7, 8 or 9. Without it this job is no use to anybody.', 'kaamase-core' );
		}

		if ( $errors ) {
			set_transient( 'kaamase_post_for_' . $user_id, $errors, 15 * MINUTE_IN_SECONDS );
			wp_safe_redirect( $back );
			exit;
		}

		/*
		 * Staff accounts made in wp-admin never went through the email
		 * confirmation, so they have no verified stamp and their jobs
		 * would save as drafts and never appear. Stamping it here is
		 * the same statement the confirmation link makes, about an
		 * account that can already edit everybody else's jobs.
		 */
		if ( function_exists( 'kaamase_user_is_verified' ) && ! kaamase_user_is_verified( $user_id ) ) {
			update_user_meta( $user_id, 'kaamase_verified_at', time() );
		}

		$result = kaamase_save_job( $values, $user_id, 0 );

		if ( is_wp_error( $result ) ) {

			$data = $result->get_error_data();

			set_transient(
				'kaamase_post_for_' . $user_id,
				isset( $data['messages'] ) ? (array) $data['messages'] : array( $result->get_error_message() ),
				15 * MINUTE_IN_SECONDS
			);

			wp_safe_redirect( $back );
			exit;
		}

		$job_id = (int) $result;

		/*
		 * Rewrite who is hiring.
		 *
		 * kaamase_save_job() filled these from the author, which on this
		 * screen is staff. The name becomes the employer's and the link
		 * to any profile is removed, so the job page shows their name
		 * with no ratings attached to it, because there is no account
		 * here to have earned any.
		 */
		kaamase_save_field( $job_id, 'employer_name', $name );
		kaamase_save_field( $job_id, 'posted_for', true );
		kaamase_save_field( $job_id, 'posted_source', $source );

		delete_post_meta( $job_id, KAAMASE_META_PREFIX . 'employer_id' );

		/*
		 * Staff posts do not sit in the screening queue. Whoever filled
		 * this form has already read the original and rung the employer,
		 * which is more checking than the queue does.
		 */
		if ( in_array( get_post_status( $job_id ), array( 'draft', 'pending' ), true ) ) {
			wp_update_post(
				array(
					'ID'          => $job_id,
					'post_status' => 'publish',
				)
			);
		}

		wp_safe_redirect( add_query_arg( 'posted', $job_id, $back ) );
		exit;
	}
}
add_action( 'admin_post_kaamase_post_for', 'kaamase_posted_for_handle' );