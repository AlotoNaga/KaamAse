<?php
/**
 * Hires.
 *
 * The missing link between looking somebody up and rating them.
 *
 * What was wrong
 * --------------
 * ratings.php is built on kaamase_record_hire(). kaamase_can_rate()
 * refuses anybody with no hire behind them, which is correct and is what
 * stops the ratings being worthless inside a week. But nothing anywhere
 * in the plugin ever called kaamase_record_hire(), so no hire existed,
 * so kaamase_hire_exists_between() was false for every pair of people on
 * the platform, so nobody could ever rate anybody.
 *
 * The whole trust system, which is the reason this platform is worth
 * using rather than a WhatsApp group, was unreachable. The rating form
 * rendered for nobody. The flags never rose. The show up rate on the
 * admin dashboard could only ever read zero.
 *
 * This file supplies the missing step.
 *
 * How a hire gets recorded
 * ------------------------
 * Hiring here happens on the phone and at the work site. A platform that
 * only knew about hires it processed itself would know about almost
 * none of them, so this asks afterwards instead.
 *
 * When an employer reveals a worker's number, that reveal is already
 * logged. Two days later the dashboard asks one question about it: did
 * you hire them. Yes records the hire and opens rating for both sides.
 * No closes the question and never asks again.
 *
 * Two days rather than immediately, because the answer on the same
 * afternoon is usually "I do not know yet". Two days rather than two
 * weeks, because after two weeks nobody remembers which of the four
 * masons they rang actually turned up.
 *
 * Why it is a question on the dashboard and not an email
 * -----------------------------------------------------
 * An email asking somebody to click a link to confirm a hire gets
 * ignored. The dashboard is where an employer already goes to post their
 * next job, and answering is two taps on a screen they were opening
 * anyway.
 *
 * @package KaamaseCore
 * @version 1.2.0
 * @since   1.2.0
 */

defined( 'ABSPATH' ) || exit;


/* ==========================================================================
   1. TIMING
   ========================================================================== */

if ( ! function_exists( 'kaamase_hire_question_delay' ) ) {
	/**
	 * How long to wait before asking whether a hire happened.
	 *
	 * @since 1.2.0
	 * @return int Seconds.
	 */
	function kaamase_hire_question_delay() {

		/**
		 * Filter the delay before the hire question is asked.
		 *
		 * @since 1.2.0
		 * @param int $delay Seconds.
		 */
		return absint( apply_filters( 'kaamase_hire_question_delay', 2 * DAY_IN_SECONDS ) );
	}
}

if ( ! function_exists( 'kaamase_hire_question_window' ) ) {
	/**
	 * How long a question stays worth asking.
	 *
	 * After this it is dropped unanswered. Somebody who cannot remember
	 * whether they hired a man five weeks ago will guess, and a guessed
	 * hire produces a rating about work that may never have happened.
	 *
	 * @since 1.2.0
	 * @return int Seconds.
	 */
	function kaamase_hire_question_window() {

		/**
		 * Filter how long a hire question survives.
		 *
		 * @since 1.2.0
		 * @param int $window Seconds.
		 */
		return absint( apply_filters( 'kaamase_hire_question_window', 30 * DAY_IN_SECONDS ) );
	}
}


/* ==========================================================================
   2. THE QUEUE

   Held in user meta on the person who did the looking up. Small, bounded,
   and it disappears with the account.
   ========================================================================== */

if ( ! function_exists( 'kaamase_get_hire_questions' ) ) {
	/**
	 * Every hire question held against a user.
	 *
	 * @since 1.2.0
	 * @param int $user_id User ID.
	 * @return array[] Questions keyed by profile ID.
	 */
	function kaamase_get_hire_questions( $user_id ) {

		$stored = get_user_meta( absint( $user_id ), 'kaamase_hire_questions', true );

		return is_array( $stored ) ? $stored : array();
	}
}

if ( ! function_exists( 'kaamase_save_hire_questions' ) ) {
	/**
	 * Store the queue, newest first and capped.
	 *
	 * @since 1.2.0
	 * @param int   $user_id   User ID.
	 * @param array $questions Questions keyed by profile ID.
	 * @return void
	 */
	function kaamase_save_hire_questions( $user_id, $questions ) {

		// A busy contractor reveals a lot of numbers. Keep the recent ones.
		if ( count( $questions ) > 60 ) {

			uasort(
				$questions,
				static function ( $a, $b ) {
					return absint( $b['time'] ) <=> absint( $a['time'] );
				}
			);

			$questions = array_slice( $questions, 0, 60, true );
		}

		update_user_meta( absint( $user_id ), 'kaamase_hire_questions', $questions );
	}
}

if ( ! function_exists( 'kaamase_queue_hire_question' ) ) {
	/**
	 * Note that this reveal is worth asking about later.
	 *
	 * Hooked onto the reveal itself, so the question exists as a side
	 * effect of something the employer already chose to do. Nobody has to
	 * remember to start the process.
	 *
	 * @since 1.2.0
	 * @param int $post_id Profile that was revealed.
	 * @param int $user_id User who revealed it.
	 * @return void
	 */
	function kaamase_queue_hire_question( $post_id, $user_id ) {

		$post = get_post( $post_id );

		if ( ! $post ) {
			return;
		}

		/*
		 * Only about people offering labour. A worker who looked up an
		 * employer's number is not the one doing the hiring, and asking
		 * them whether they hired the employer would be nonsense.
		 */
		if ( ! in_array( $post->post_type, array( 'kaamase_worker', 'kaamase_gang' ), true ) ) {
			return;
		}

		$questions = kaamase_get_hire_questions( $user_id );
		$post_id   = absint( $post_id );

		// Already asked and answered. Do not reopen it.
		if ( isset( $questions[ $post_id ] ) && 'pending' !== $questions[ $post_id ]['state'] ) {
			return;
		}

		// Already queued. Leave the original timestamp so the clock does
		// not restart every time they look at the number again.
		if ( isset( $questions[ $post_id ] ) ) {
			return;
		}

		$questions[ $post_id ] = array(
			'time'  => time(),
			'state' => 'pending',
		);

		kaamase_save_hire_questions( $user_id, $questions );
	}
}
add_action( 'kaamase_contact_revealed', 'kaamase_queue_hire_question', 10, 2 );

if ( ! function_exists( 'kaamase_due_hire_questions' ) ) {
	/**
	 * Questions that are ready to be asked.
	 *
	 * Old enough to have an answer, young enough to be remembered, and
	 * still pointing at a profile that exists.
	 *
	 * @since 1.2.0
	 * @param int $user_id User ID.
	 * @return array[] Entries with post_id and time, oldest first.
	 */
	function kaamase_due_hire_questions( $user_id ) {

		$questions = kaamase_get_hire_questions( $user_id );

		if ( empty( $questions ) ) {
			return array();
		}

		$delay  = kaamase_hire_question_delay();
		$window = kaamase_hire_question_window();
		$now    = time();
		$due    = array();

		foreach ( $questions as $post_id => $entry ) {

			if ( 'pending' !== $entry['state'] ) {
				continue;
			}

			$age = $now - absint( $entry['time'] );

			if ( $age < $delay || $age > $window ) {
				continue;
			}

			$post = get_post( $post_id );

			if ( ! $post || 'publish' !== $post->post_status ) {
				continue;
			}

			$due[] = array(
				'post_id' => (int) $post_id,
				'time'    => absint( $entry['time'] ),
			);
		}

		usort(
			$due,
			static function ( $a, $b ) {
				return $a['time'] <=> $b['time'];
			}
		);

		return $due;
	}
}


/* ==========================================================================
   3. ASKING
   ========================================================================== */

if ( ! function_exists( 'kaamase_hire_questions_section' ) ) {
	/**
	 * Render the hire questions on the dashboard.
	 *
	 * Three at a time. A list of eleven questions reads as homework and
	 * gets skipped, and the answer to the oldest is the one most at risk
	 * of being forgotten.
	 *
	 * @since 1.2.0
	 * @param int    $user_id User ID.
	 * @param int    $profile Profile post ID.
	 * @param string $type    worker or employer.
	 * @return void
	 */
	function kaamase_hire_questions_section( $user_id, $profile, $type ) {

		unset( $profile, $type );

		$due = kaamase_due_hire_questions( $user_id );

		if ( empty( $due ) ) {
			return;
		}

		$due = array_slice( $due, 0, 3 );
		?>
		<section class="ka-card ka-card--pad-lg ka-mt-6">

			<h2><?php esc_html_e( 'Did you hire them?', 'kaamase-core' ); ?></h2>

			<p class="ka-small ka-soft ka-mt-4">
				<?php esc_html_e( 'You looked up these numbers recently. Telling us what happened is what lets you and them rate each other, and it is the only reason the ratings on this site mean anything.', 'kaamase-core' ); ?>
			</p>

			<ul class="ka-stack ka-mt-6">
				<?php foreach ( $due as $entry ) : ?>
					<li class="ka-card ka-card--flat">
						<div class="ka-cluster ka-cluster--between">

							<div class="ka-cluster">
								<?php echo kaamase_avatar( $entry['post_id'], 'kaamase-avatar', 'ka-avatar--sm' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>

								<div>
									<a href="<?php echo esc_url( get_permalink( $entry['post_id'] ) ); ?>">
										<strong><?php echo esc_html( get_the_title( $entry['post_id'] ) ); ?></strong>
									</a>
									<p class="ka-small ka-mute">
										<?php
										printf(
											/* translators: %s: how long ago */
											esc_html__( 'You looked them up %s ago', 'kaamase-core' ),
											esc_html( human_time_diff( $entry['time'], time() ) )
										);
										?>
									</p>
								</div>
							</div>

							<form method="post" action="" class="ka-cluster">
								<?php wp_nonce_field( 'kaamase_hire_answer', 'kaamase_hire_nonce' ); ?>
								<input type="hidden" name="kaamase_action" value="hire_answer">
								<input type="hidden" name="kaamase_hire_profile" value="<?php echo esc_attr( $entry['post_id'] ); ?>">

								<button class="ka-btn ka-btn--action ka-btn--sm" type="submit"
									name="kaamase_hired" value="1">
									<?php esc_html_e( 'Yes, I hired them', 'kaamase-core' ); ?>
								</button>

								<button class="ka-btn ka-btn--ghost ka-btn--sm" type="submit"
									name="kaamase_hired" value="0">
									<?php esc_html_e( 'No', 'kaamase-core' ); ?>
								</button>
							</form>

						</div>
					</li>
				<?php endforeach; ?>
			</ul>

		</section>
		<?php
	}
}
add_action( 'kaamase_dashboard_prompts', 'kaamase_hire_questions_section', 10, 3 );

if ( ! function_exists( 'kaamase_handle_hire_answer' ) ) {
	/**
	 * Record the answer to a hire question.
	 *
	 * @since 1.2.0
	 * @return void
	 */
	function kaamase_handle_hire_answer() {

		// phpcs:ignore WordPress.Security.NonceVerification.Missing
		if ( empty( $_POST['kaamase_action'] ) || 'hire_answer' !== $_POST['kaamase_action'] ) {
			return;
		}

		if (
			! is_user_logged_in()
			|| empty( $_POST['kaamase_hire_nonce'] )
			|| ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['kaamase_hire_nonce'] ) ), 'kaamase_hire_answer' )
		) {
			return;
		}

		// phpcs:disable WordPress.Security.NonceVerification.Missing
		$post_id = isset( $_POST['kaamase_hire_profile'] ) ? absint( $_POST['kaamase_hire_profile'] ) : 0;
		$hired   = isset( $_POST['kaamase_hired'] ) && '1' === (string) wp_unslash( $_POST['kaamase_hired'] );
		// phpcs:enable WordPress.Security.NonceVerification.Missing

		$user_id   = get_current_user_id();
		$questions = kaamase_get_hire_questions( $user_id );

		/*
		 * Only a question this user was actually asked can be answered.
		 * Without this check anybody could post an arbitrary profile ID
		 * and manufacture a hire, which is the same as manufacturing the
		 * right to rate a stranger.
		 */
		if ( ! $post_id || ! isset( $questions[ $post_id ] ) || 'pending' !== $questions[ $post_id ]['state'] ) {
			wp_safe_redirect( kaamase_page_url( 'dashboard' ) );
			exit;
		}

		$questions[ $post_id ]['state']    = $hired ? 'hired' : 'no';
		$questions[ $post_id ]['answered'] = time();

		kaamase_save_hire_questions( $user_id, $questions );

		if ( $hired ) {
			kaamase_record_hire( $post_id, $user_id );
		}

		wp_safe_redirect(
			add_query_arg( 'saved', $hired ? 'hired' : 'nothired', kaamase_page_url( 'dashboard' ) )
		);
		exit;
	}
}
add_action( 'template_redirect', 'kaamase_handle_hire_answer' );


/* ==========================================================================
   4. THE RATING PROMPT

   A hire on its own does nothing. It has to turn into a rating, and the
   moment to ask is while the work is still recent.
   ========================================================================== */

if ( ! function_exists( 'kaamase_pending_ratings' ) ) {
	/**
	 * People this user has worked with and not yet rated.
	 *
	 * @since 1.2.0
	 * @param int $user_id User ID.
	 * @return int[] Profile IDs, most recent first.
	 */
	function kaamase_pending_ratings( $user_id ) {

		if ( ! function_exists( 'kaamase_worked_with' ) ) {
			return array();
		}

		$out = array();

		foreach ( kaamase_worked_with( $user_id ) as $entry ) {

			$post_id = absint( $entry['post_id'] );
			$post    = get_post( $post_id );

			if ( ! $post || 'publish' !== $post->post_status ) {
				continue;
			}

			if ( kaamase_has_rated( $post_id, $user_id ) ) {
				continue;
			}

			$out[] = $post_id;
		}

		return $out;
	}
}

if ( ! function_exists( 'kaamase_rating_prompt_section' ) ) {
	/**
	 * Ask for a rating on work that has already been confirmed.
	 *
	 * States plainly that neither side sees the other's answer until both
	 * are in, because the first thing anybody worries about is whether
	 * being honest will cost them.
	 *
	 * @since 1.2.0
	 * @param int    $user_id User ID.
	 * @param int    $profile Profile post ID.
	 * @param string $type    worker or employer.
	 * @return void
	 */
	function kaamase_rating_prompt_section( $user_id, $profile, $type ) {

		unset( $profile );

		$pending = array_slice( kaamase_pending_ratings( $user_id ), 0, 3 );

		if ( empty( $pending ) ) {
			return;
		}
		?>
		<section class="ka-card ka-card--pad-lg ka-mt-6">

			<h2><?php esc_html_e( 'How did it go?', 'kaamase-core' ); ?></h2>

			<p class="ka-small ka-soft ka-mt-4">
				<?php
				echo 'employer' === $type
					? esc_html__( 'You worked with these people. A few yes or no questions each. Neither of you sees the other\'s answers until you have both written one, so you cannot be punished for being honest.', 'kaamase-core' )
					: esc_html__( 'You did work for these people. A few yes or no questions each, including whether you were paid what was agreed. Neither side sees the other\'s answers until you have both written one.', 'kaamase-core' );
				?>
			</p>

			<ul class="ka-stack ka-mt-6">
				<?php foreach ( $pending as $post_id ) : ?>
					<li class="ka-card ka-card--flat">
						<div class="ka-cluster ka-cluster--between">

							<div class="ka-cluster">
								<?php echo kaamase_avatar( $post_id, 'kaamase-avatar', 'ka-avatar--sm' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
								<strong><?php echo esc_html( get_the_title( $post_id ) ); ?></strong>
							</div>

							<a class="ka-btn ka-btn--primary ka-btn--sm" href="<?php echo esc_url( get_permalink( $post_id ) ); ?>#ka-rate">
								<?php esc_html_e( 'Rate them', 'kaamase-core' ); ?>
							</a>

						</div>
					</li>
				<?php endforeach; ?>
			</ul>

		</section>
		<?php
	}
}
add_action( 'kaamase_dashboard_prompts', 'kaamase_rating_prompt_section', 20, 3 );


/* ==========================================================================
   5. CLOSING A FILLED JOB

   The other half of keeping listings honest. Expiry closes a job that
   nobody answered. This closes one that worked.
   ========================================================================== */

if ( ! function_exists( 'kaamase_handle_fill_job' ) ) {
	/**
	 * Mark a job as filled and close it.
	 *
	 * @since 1.2.0
	 * @return void
	 */
	function kaamase_handle_fill_job() {

		// phpcs:ignore WordPress.Security.NonceVerification.Missing
		if ( empty( $_POST['kaamase_action'] ) || 'fill_job' !== $_POST['kaamase_action'] ) {
			return;
		}

		if (
			! is_user_logged_in()
			|| empty( $_POST['kaamase_fill_nonce'] )
			|| ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['kaamase_fill_nonce'] ) ), 'kaamase_fill_job' )
		) {
			return;
		}

		// phpcs:ignore WordPress.Security.NonceVerification.Missing
		$job_id = isset( $_POST['kaamase_job'] ) ? absint( $_POST['kaamase_job'] ) : 0;

		if ( ! $job_id || ! current_user_can( 'edit_post', $job_id ) ) {
			return;
		}

		$post = get_post( $job_id );

		if ( ! $post || 'kaamase_job' !== $post->post_type ) {
			return;
		}

		kaamase_save_field( $job_id, 'job_status', 'filled' );

		wp_update_post(
			array(
				'ID'          => $job_id,
				'post_status' => 'kaamase_closed',
			)
		);

		/**
		 * Fires when an employer closes a job because it is filled.
		 *
		 * @since 1.2.0
		 * @param int $job_id Job ID.
		 */
		do_action( 'kaamase_job_filled', $job_id );

		wp_safe_redirect( add_query_arg( 'saved', 'filled', kaamase_page_url( 'dashboard' ) ) );
		exit;
	}
}
add_action( 'template_redirect', 'kaamase_handle_fill_job' );


/* ==========================================================================
   6. HOUSEKEEPING
   ========================================================================== */

if ( ! function_exists( 'kaamase_expire_hire_questions' ) ) {
	/**
	 * Drop questions nobody answered in time.
	 *
	 * Runs daily. Keeps the meta small and stops the dashboard offering a
	 * question about work from four months ago.
	 *
	 * @since 1.2.0
	 * @return void
	 */
	function kaamase_expire_hire_questions() {

		$users = get_users(
			array(
				'meta_key' => 'kaamase_hire_questions', // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_key
				'number'   => 100,
				'fields'   => array( 'ID' ),
			)
		);

		$cutoff = time() - kaamase_hire_question_window();

		foreach ( $users as $row ) {

			$questions = kaamase_get_hire_questions( $row->ID );
			$kept      = array();

			foreach ( $questions as $post_id => $entry ) {

				// Answered questions are kept, so the same one is never asked twice.
				if ( 'pending' !== $entry['state'] ) {
					$kept[ $post_id ] = $entry;
					continue;
				}

				if ( absint( $entry['time'] ) > $cutoff ) {
					$kept[ $post_id ] = $entry;
				}
			}

			if ( count( $kept ) !== count( $questions ) ) {
				kaamase_save_hire_questions( $row->ID, $kept );
			}
		}
	}
}
add_action( 'kaamase_daily', 'kaamase_expire_hire_questions' );
